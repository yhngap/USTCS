#include "PA1.h"

/***********************************************************************
 * TODO 1: Reveal the specified cell.
 * - If the cell is already revealed, do nothing.
 * - If the cell has a mine, display it and set mine_exploded.
 * - If the cell is not a mine, update num_safe_reveals_left in
 *   game_stats[3], and display the number of neighbor mines.
 * - If there are no neighboring mines, unflag and reveal all neighbors.
 * Note: Be careful not to multi-count when updating game_stats[3].
 ***********************************************************************/
void reveal(int row, int col) {

}

/***********************************************************************
 * TODO 2: Toggle the flagging of the specified cell.
 * - If the specified cell is hidden, flag it, and vice versa.
 * - Update num_flags_left in game_stats[2].
 * - Update num_incorrect_flags in game_stats[4].
 ***********************************************************************/
void flag(int row, int col) {

}

/***********************************************************************
 * TODO 3: Determine hidden cells to reveal and to flag, considering
 * only one constraint at a time.
 * - If the number of flagged cells surrounding a constraint is equal to
 *   the constraint, then reveal all surrounding unflagged hidden cells.
 * - If the number of hidden + flagged cells surrounding a constraint is equal to
 *   the constraint, then flag all surrounding unflagged hidden cells.
 * - Return whether or not these two rules are successful in
 *   determining at least one cell to reveal or to flag.
 ***********************************************************************/
bool local_solver(int cells_to_reveal[MAX_CELLS][2], int cells_to_flag[MAX_CELLS][2], int num_cells[2]) {
	return false;
}

/***********************************************************************
 * TODO 4: Record all unflagged hidden cells and classify each as
 * either constrained or unconstrained.
 * - If an unflagged hidden cell has a neighboring constraint, record
 *   it as constrained.
 * - If an unflagged hidden cell has no neighboring constraints, record
 *   it as unconstrained.
 ***********************************************************************/
void classify_hidden_cells(int constrained_cells[MAX_CELLS][2], int unconstrained_cells[MAX_CELLS][2], int num_cells[2]) {

}

/***********************************************************************
 * TODO 5: Check whether or not all neighboring constraints of the
 * specified cell can still be satisfied.
 * - Return true if there exists a possible configuration of mines
 *   which agrees with all neighboring constraints, without considering
 *   the total number of mines in the grid. Otherwise, return false.
 *
 * Usage: enumerate_possibilities() will test-set the specified cell as
 * FLAGGED/SAFE, and then call this function to check for validity.
 * Hint: For each of the specified cell (A)'s neighbors (N1 - N8), if Ni
 * is revealed with a number, count Ni's neighboring hidden and flagged
 * cells (one of them is A itself) and check if it is still solvable.
 ***********************************************************************/
bool has_satisfiable_neighbor_constraints(int row, int col) {
	return false;
}

/***********************************************************************
 * TODO 6: Validate and record the current configuration of the
 * constrained cells.
 * - Check if the number of flags used in the current configuration of
 *   the constrained cells is within the lower and upper bounds.
 * - If within, record the SAFE/FLAGGED states of the constrained cells,
 *   and update the lowest and the highest number of flags used across
 *   all recorded configurations so far.
 ***********************************************************************/
void record_possibility(int constrained_cells[MAX_CELLS][2], int num_constrained_cells, int num_flags_bounds_used[4], int num_safe_config_records[MAX_CELLS], int num_flagged_config_records[MAX_CELLS]) {

}

/***********************************************************************
 * TODO 7: Enumerate, validate, and record all possible configurations
 * of the constrained cells.
 * - Enumerate through all possibilities of the constrained cells by
 *   setting them one-by-one to FLAGGED/SAFE in the grid, then checking
 *   for validity. Use index to keep track of progress.
 * - Stop and backtrack from the exploration of a configuration, if
 *   setting the current constrained cell as FLAGGED/SAFE causes it to
 *   have unsatisfiable neighbor constraints.
 * - If the exploration of a configuration reaches the end, (i.e. all
 *   constrained cells successfully set to FLAGGED/SAFE while satisfying
 *   all neighboring constraints), validate the number of flags used and
 *   record this configuration of the constrained cells.
 * - Remember to reset the constrained cells back to HIDDEN in the grid
 *   when finished with a configuration.
 *
 * Warning: This function potentially has exponential runtime, as the
 * number of possible configurations is 2^num_constrained if not
 * checking validity via satisfiable neighbor constraints.
 * Note: Good usage of recursion will greatly reduce the amount of
 * coding required to implement this function (The TA solution is
 * shorter than this TODO comment block).
 *
 * Hint: You may draw a "binary branching tree graph" to help you
 * visualize all the configurations as well as the recursion pathways.
 * Example enumeration with 4 constrained cells (2^4 = 16 configurations):
 * START ----> SAFE -----> SAFE -----> SAFE -----> SAFE
 *         |           |           |           |
 *         |           |           |           --> FLAGGED
 *         |           |           |
 *         |           |           --> FLAGGED --> SAFE
 *         |           |                       |
 *         |           |                       --> FLAGGED
 *         |           |
 *         |           --> FLAGGED --> SAFE -----> SAFE
 *         |                       |           |
 *         |                       |           --> FLAGGED
 *         |                       |
 *         |                       --> FLAGGED --> SAFE
 *         |                                   |
 *         |                                   --> FLAGGED
 *         |
 *         --> FLAGGED --> SAFE -----> SAFE -----> SAFE
 *                     |           |           |
 *                     |           |           --> FLAGGED
 *                     |           |
 *                     |           --> FLAGGED --> SAFE
 *                     |                       |
 *                     |                       --> FLAGGED
 *                     |
 *                     --> FLAGGED --> SAFE -----> SAFE
 *                                 |           |
 *                                 |           --> FLAGGED
 *                                 |
 *                                 --> FLAGGED --> SAFE
 *                                             |
 *                                             --> FLAGGED
 ***********************************************************************/
void enumerate_possibilities(int constrained_cells[MAX_CELLS][2], int index, int num_constrained_cells, int num_flags_bounds_used[4], int num_safe_config_records[MAX_CELLS], int num_flagged_config_records[MAX_CELLS]) {

}

/***********************************************************************
 * TODO 8: Determine which constrained cells must be revealed or flagged.
 * - If a constrained cell has always been recorded as SAFE, reveal it.
 * - If a constrained cell has always been recorded as FLAGGED, flag it.
 ***********************************************************************/
void handle_constrained_cells(int constrained_cells[MAX_CELLS][2], int num_constrained_cells, int num_safe_config_records[MAX_CELLS], int num_flagged_config_records[MAX_CELLS], int cells_to_reveal[MAX_CELLS][2], int cells_to_flag[MAX_CELLS][2], int num_cells[2]) {

}

/***********************************************************************
 * TODO 9: Determine if all unconstrained cells must be revealed or flagged.
 * - If the number of flags used in all configurations of the
 *   constrained cells is always equal to the upper bound, then all
 *   unconstrained cells must be revealed.
 * - If the number of flags used in all configurations of the
 *   constrained cells is always equal to the lower bound, then all
 *   unconstrained cells must be flagged.
 ***********************************************************************/
void handle_unconstrained_cells(int unconstrained_cells[MAX_CELLS][2], int num_unconstrained_cells, int num_flags_bounds_used[4], int cells_to_reveal[MAX_CELLS][2], int cells_to_flag[MAX_CELLS][2], int num_cells[2]) {

}

/***********************************************************************
 * TODO 10: Determine hidden cells to reveal and to flag, considering
 * all constraints simultaneously.
 * - Record all unflagged hidden cells and classify each as either
 *   constrained or unconstrained.
 * - Calculate the upper and lower bounds on the number of flags used
 *   in the configurations of the constrained cells. Upper bound assumes
 *   all unconstrained cells are safe, while lower bound assumes all
 *   unconstrained cells are mines.
 * - Enumerate and record all possible configurations of the constrained
 *   cells and number of flags used.
 * - Determine which constrained cells must be revealed or flagged.
 * - Determine if all unconstrained cells must be revealed or flagged.
 * - Return whether or not this strategy is successful in determining
 *   at least one cell to reveal or to flag.
 ***********************************************************************/
bool global_solver(int cells_to_reveal[MAX_CELLS][2], int cells_to_flag[MAX_CELLS][2], int num_cells[2]) {
	return false;
}
