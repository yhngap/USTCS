#include <fstream>

#include <QFileDialog>
#include <QDebug>
#include <QGraphicsPixmapItem>
#include <QMessageBox>

#include "gamewindow.h"
#include "ui_gamewindow.h"

#include "clickableview.h"

using namespace std;

GameWindow::GameWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::GameWindow)
{
    ui->setupUi(this);

    // Link the scene with the view
    ui->graphicsView->setScene(&scene);
    ui->graphicsView->show();

    // connect the signal of the click event in the upper panel and the handler in this class
    connect(ui->graphicsView, &ClickableView::mouseClicked, this, &GameWindow::map_clicked);

    // hide buttons that should not be pressed now
    ui->actionPlayers->setVisible(false);
    ui->actionStart->setVisible(false);
    ui->actionHeal->setVisible(false);
}

GameWindow::~GameWindow()
{
    delete ui;
    for (int i=0; i<num_players; i++) delete players[i];
    delete[] players;
}


void GameWindow::on_actionMap_triggered()
{
    // The handler after the Map button is pressed
    QString filename = QFileDialog::getOpenFileName(this, tr("Open Map File"), ".", tr("Text Files (*.txt)"));
    qDebug() << filename;  // You can use qDebug() for debug info
    if (filename == "") return;
    // TODO: load map to game logic control and render the UI
    // useful docs: https://doc.qt.io/qt-5/qstring.html#fromStdString
}

void GameWindow::on_actionPlayers_triggered()
{
    // The handler after the Players button is pressed
    // TODO: load player and unit file and render the UI
}

void load_players_and_units(const string& filename) {
    // Old function from PA3, should be useless, just for reference. 
	ifstream players_and_units_file(filename);

	players_and_units_file >> num_players;
	players = new Player*[num_players];

	for (int p = 0; p < num_players; p += 1) {
		string name;
		int num_units;
		players_and_units_file >> name >> num_units;
		//cout << name << " " << num_units << endl;
		Unit** units = new Unit*[num_units];

		for (int u = 0; u < num_units; u += 1) {
			char id;
			string unit_type_string;
			int row, col;
			players_and_units_file >> id >> unit_type_string >> row >> col;
			//cout << id << " " << unit_type_string << " " << row << " " << col << endl;

			Unit* unit = nullptr;
			if (unit_type_string == "Swordsman") {
				unit = new Swordsman{id, row, col};
			} else if (unit_type_string == "Pikeman") {
				unit = new Pikeman{id, row, col};
			} else if (unit_type_string == "Knight") {
				unit = new Knight{id, row, col};
			} else if (unit_type_string == "Archer") {
				unit = new Archer{id, row, col};
			}
			units[u] = unit;
			//cout << unit->to_string() << endl;
			game_map.update_terrain_map(row, col, GameMap::TerrainState::OCCUPIED);
		}
		players[p] = new Player{name, num_units, units};
	}
}

void GameWindow::load_players_and_units(const string& filename) {
    // TODO: load units into the game logic control and update the tree list in th lower panel
    // useful docs: https://doc.qt.io/qt-5/qtreewidget.html
    // https://doc.qt.io/qt-5/qtreewidgetitem.html
}

int GameWindow::next_player() {
    // TODO: switch to the next valid player
}

void GameWindow::get_player_unit_by_pos(int row, int col, int &player_out, int &unit_out) {
    // TODO: get the pointer to the player and unit by position
}

void GameWindow::on_actionStart_triggered()
{
    // The handler after the Start button is pressed
    // TODO: start the game
}

void GameWindow::on_treeWidget_itemPressed(QTreeWidgetItem *item, int column)
{
    // The handler after the item in the list is pressed
    // TODO: you can also click the item in the list to select units
    // useful docs: https://doc.qt.io/qt-5/qtreewidget.html#indexOfTopLevelItem
    // https://doc.qt.io/qt-5/qtreewidgetitem.html#indexOfChild
    // https://doc.qt.io/qt-5/qtreewidgetitem.html#parent
    // https://doc.qt.io/qt-5/qtreewidgetitem.html#treeWidget
}

void GameWindow::map_clicked(int row, int col) {
    // TODO: Actual handler of the clicking
    // HINT: Do different operation based on the stage and change the stage accordingly. This is the most different part from the console UI. 
    if (active_player_id != -1) {
        if (unit_wait_command != -1) {
            switch (command_stage) {
            case 0: { // normal
                break;
            }
            case 1: { // move
                break;
            }
            case 2: { //attack
                break;
            }};
        } else {
            switch (command_stage) {
            case 0: { // normal
                break;
            }
            case 1: { // move
                break;
            }
            case 2: { //attack
                break;
            }};
        }
    }
}

bool GameWindow::is_game_over() const {
    int num_players_remaining = 0;
    for (int i = 0; i < num_players; i += 1) {
        if (players[i]->has_units_alive()) { num_players_remaining += 1; }
        if (num_players_remaining > 1) { return false; }
    }
    return true;
}

void GameWindow::on_actionHeal_triggered()
{
    // The handler after the Heal button is pressed
    // TODO: implement the heal feature
}
