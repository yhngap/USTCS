#include "GameEngine.h"
int main() {
	GameEngine{}.run_game();
	return 0;
}
