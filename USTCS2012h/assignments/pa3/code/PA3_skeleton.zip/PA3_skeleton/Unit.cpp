#include <iomanip>
using std::setw;
#include <sstream>
using std::stringstream;
#include <cmath>
using std::abs;
using std::round;

#include "Unit.h"

string Unit::to_string_base() const {
	stringstream ss;
	ss << "[" << id << "]  ";
	ss << "H:" << setw(2) << health << "  ";
	ss << "A:" << setw(2) << attack << "  ";
	ss << "D:" << setw(2) << defense << "  ";
	ss << "AR:" << setw(2) << attack_range << "  ";
	ss << "MR:" << setw(2) << movement_range << "  ";
	ss << "row:" << setw(2) << position_row << "  ";
	ss << "col:" << setw(2) << position_col << "  ";
	if (is_alive()) {
		if (is_ready()) { ss << "READY  "; }
		else { ss << "DONE   "; }
	} else { ss << "DEAD   "; }
	return ss.str();
}
