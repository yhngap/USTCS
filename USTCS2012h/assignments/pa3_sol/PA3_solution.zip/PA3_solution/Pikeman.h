#ifndef PIKEMAN_H_
#define PIKEMAN_H_

#include "Unit.h"

class Pikeman : public Unit {
public:
	Pikeman(char id, int row, int col);
	virtual ~Pikeman();
	virtual void receive_damage_affinity(double raw_damage, UnitType attacker_unit_type) override;
	virtual string to_string() const override;
};

#endif /* PIKEMAN_H_ */
