#ifndef ARCHER_H_
#define ARCHER_H_

#include "Unit.h"

class Archer : public Unit {
public:
	Archer(char id, int row, int col);
	virtual ~Archer();
	virtual void receive_damage_affinity(double raw_damage, UnitType attacker_unit_type) override;
	virtual string to_string() const override;
};

#endif /* ARCHER_H_ */
