#ifndef UNITDERIVEDGTEST_H_
#define UNITDERIVEDGTEST_H_

#include <cmath>
using std::round;

#include "Unit.h"

class UnitDerivedGTest : public Unit {
public:
	UnitDerivedGTest(char id, UnitType unit_type, int health, int attack, int defense, int attack_range, int movement_range, int row, int col, bool ready_state)
		: Unit{id, unit_type, attack, defense, attack_range, movement_range, row, col} {
		this->health = health;
		this->ready_state = ready_state;
	}

	virtual ~UnitDerivedGTest() {}

	virtual void receive_damage_affinity(double raw_damage, UnitType attacker_unit_type) override {
		health -= round(raw_damage);
		if (health < 0) { health = 0; }
	}

	virtual string to_string() const override { return (to_string_base() + "UnitDerivedGTest"); }
};

#endif /* UNITDERIVEDGTEST_H_ */
