#include <string>
using std::string;
#include <cmath>
using std::round;

#include "gtest/gtest.h"

#include "GameEngine.h"
#include "GameMap.h"
#include "Player.h"
#include "Unit.h"
#include "Swordsman.h"
#include "Pikeman.h"
#include "Knight.h"
#include "Archer.h"

#include "UnitDerivedGTest.h"



/********************
 * GameEngine Tests *
 ********************/

class GameEngineTest : public ::testing::Test {
protected:
	GameEngineTest() { game_engine.game_map.load_terrain_map("GameMap.txt"); }
	GameEngine game_engine;
};

TEST_F(GameEngineTest, IsGameOverTwoPlayers) {
	game_engine.load_players_and_units("PlayersAndUnits.txt");
	EXPECT_FALSE(game_engine.is_game_over());
}

TEST_F(GameEngineTest, IsGameOverOnePlayer) {
	game_engine.load_players_and_units("PlayersAndUnitsOne.txt");
	EXPECT_TRUE(game_engine.is_game_over());
}

TEST_F(GameEngineTest, IsGameOverZeroPlayers) {
	game_engine.load_players_and_units("PlayersAndUnitsZero.txt");
	EXPECT_TRUE(game_engine.is_game_over());
}



/*****************
 * GameMap Tests *
 *****************/

class GameMapTest : public ::testing::Test {
protected:
	GameMapTest() { game_map.load_terrain_map("GameMap.txt"); }
	GameMap game_map;
};

TEST_F(GameMapTest, UpdateTerrainMapEmptyToOccupied) {
	game_map.update_terrain_map(5, 5, GameMap::TerrainState::OCCUPIED);
	EXPECT_EQ(game_map.terrain_map[5 * 30 + 5], GameMap::TerrainState::OCCUPIED);
}

TEST_F(GameMapTest, UpdateTerrainMapOccupiedToEmpty) {
	game_map.terrain_map[5 * 30 + 5] = GameMap::TerrainState::OCCUPIED;
	game_map.update_terrain_map(5, 5, GameMap::TerrainState::EMPTY);
	EXPECT_EQ(game_map.terrain_map[5 * 30 + 5], GameMap::TerrainState::EMPTY);
}

TEST_F(GameMapTest, IsValidPath) {
	EXPECT_TRUE(game_map.is_valid_path(1, 1, 1, 1, 10));
}

TEST_F(GameMapTest, IsValidPathOutOfBounds) {
	EXPECT_FALSE(game_map.is_valid_path(1, 1, -2, -2, 10));
}

TEST_F(GameMapTest, IsValidPathTerrainBlocked) {
	EXPECT_FALSE(game_map.is_valid_path(8, 8, 0, 2, 10));
}

TEST_F(GameMapTest, IsValidPathTerrainOccupied) {
	game_map.terrain_map[5 * 30 + 5] = GameMap::TerrainState::OCCUPIED;
	EXPECT_FALSE(game_map.is_valid_path(4, 4, 1, 1, 10));
}

TEST_F(GameMapTest, IsValidPathOutOfMovementRange) {
	EXPECT_FALSE(game_map.is_valid_path(1, 1, 5, 5, 1));
}



/****************
 * Player Tests *
 ****************/

class PlayerTest : public ::testing::Test {
protected:
	PlayerTest() : name{"Tester"}, num_units{10}, units{new Unit*[10]}, player{name, num_units, units} {
		for (int i = 0; i < 10; i += 1) {
			units[i] = new UnitDerivedGTest{char('A' + i), Unit::UnitType::Arrow, Unit::MAX_HEALTH, i+1, i+1, i+1, i+1, i+1, i+1, false};
		}
	}
	// No Destructor. Memory Leak will be caught and scored with -fsanitize.

	string name;
	int num_units;
	Unit** units;
	Player player;
};

TEST_F(PlayerTest, GetUnitById) {
	for (int i = 0; i < num_units; i += 1) {
		EXPECT_EQ(player.get_unit_by_id(units[i]->id), units[i]);
	}
}

TEST_F(PlayerTest, HasUnitsAlive) {
	EXPECT_TRUE(player.has_units_alive());
	for (int i = 0; i < num_units - 1; i += 1) {
		units[i]->health = 0;
		EXPECT_TRUE(player.has_units_alive());
	}
}

TEST_F(PlayerTest, HasNoUnitsAlive) {
	for (int i = 0; i < num_units; i += 1) {
		units[i]->health = 0;
	}
	EXPECT_FALSE(player.has_units_alive());
}

TEST_F(PlayerTest, HasUnitsReady) {
	for (int i = 0; i < num_units; i += 1) {
		units[i]->ready_state = true;
		EXPECT_TRUE(player.has_units_ready());
	}
}

TEST_F(PlayerTest, HasNoUnitsReady) {
	EXPECT_FALSE(player.has_units_ready());
}

TEST_F(PlayerTest, ReadyAllUnits) {
	player.ready_all_units();
	for (int i = 0; i < num_units; i += 1) {
		EXPECT_TRUE(units[i]->ready_state);
	}
}

TEST_F(PlayerTest, GetName) {
	EXPECT_EQ(player.get_name(), name);
}

TEST_F(PlayerTest, GetNumUnits) {
	EXPECT_EQ(player.get_num_units(), num_units);
}

TEST_F(PlayerTest, GetUnits) {
	EXPECT_EQ(player.get_units(), units);
}



/**************
 * Unit Tests *
 **************/
// Note: attack_unit() tests shifted to the Derived Unit classes instead, to support override.

class UnitTest : public ::testing::Test {
protected:
	~UnitTest() { delete unit; }
	Unit* unit{new UnitDerivedGTest{'z', Unit::UnitType::Arrow, Unit::MAX_HEALTH, 2012, 2012, 2012, 2012, 2012, 2012, false}};
};

TEST_F(UnitTest, BeginTurn) {
	unit->begin_turn();
	EXPECT_TRUE(unit->ready_state);
}

TEST_F(UnitTest, EndTurn) {
	unit->ready_state = true;
	unit->end_turn();
	EXPECT_FALSE(unit->ready_state);
}

TEST_F(UnitTest, MoveDeltaPositiveRowPositiveCol) {
	unit->move_delta(2012, 2012);
	EXPECT_EQ(unit->position_row, 4024);
	EXPECT_EQ(unit->position_col, 4024);
}

TEST_F(UnitTest, MoveDeltaNegativeRowNegativeCol) {
	unit->move_delta(-2012, -2012);
	EXPECT_EQ(unit->position_row, 0);
	EXPECT_EQ(unit->position_col, 0);
}

TEST_F(UnitTest, MoveDeltaPositiveRowNegativeCol) {
	unit->move_delta(2012, -2012);
	EXPECT_EQ(unit->position_row, 4024);
	EXPECT_EQ(unit->position_col, 0);
}

TEST_F(UnitTest, MoveDeltaNegativeRowPositiveCol) {
	unit->move_delta(-2012, 2012);
	EXPECT_EQ(unit->position_row, 0);
	EXPECT_EQ(unit->position_col, 4024);
}

TEST_F(UnitTest, HealRate) {
	int starting_health = 1;
	unit->health = starting_health;
	unit->heal();
	EXPECT_EQ(unit->health, starting_health + Unit::HEAL_RATE);
}

TEST_F(UnitTest, HealMaxHealth) {
	int starting_health = 9;
	unit->health = starting_health;
	unit->heal();
	EXPECT_EQ(unit->health, int(Unit::MAX_HEALTH));
}

TEST_F(UnitTest, GetId) {
	EXPECT_EQ(unit->get_id(), 'z');
}

TEST_F(UnitTest, GetUnitType) {
	EXPECT_EQ(unit->get_unit_type(), Unit::UnitType::Arrow);
}

TEST_F(UnitTest, GetAttackRange) {
	EXPECT_EQ(unit->get_attack_range(), 2012);
}

TEST_F(UnitTest, GetMovementRange) {
	EXPECT_EQ(unit->get_movement_range(), 2012);
}

TEST_F(UnitTest, GetPositionRow) {
	EXPECT_EQ(unit->get_position_row(), 2012);
}

TEST_F(UnitTest, GetPositionCol) {
	EXPECT_EQ(unit->get_position_col(), 2012);
}

TEST_F(UnitTest, IsReadyTrue) {
	unit->ready_state = true;
	EXPECT_TRUE(unit->is_ready());
}

TEST_F(UnitTest, IsReadyFalse) {
	EXPECT_FALSE(unit->is_ready());
}

TEST_F(UnitTest, IsAliveNonzeroHealth) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		unit->health = Unit::MAX_HEALTH - i;
		EXPECT_TRUE(unit->is_alive());
	}
}

TEST_F(UnitTest, IsAliveZeroHealth) {
	unit->health = 0;
	EXPECT_FALSE(unit->is_alive());
}



/*******************
 * Swordsman Tests *
 *******************/

class SwordsmanTest : public ::testing::Test {
protected:
	Swordsman swordsman{'S', 10, 10};
	Pikeman pikeman{'P', 9, 10};
	Knight knight{'K', 10, 9};
	Archer archer{'A', 10, 11};
	Swordsman swordsman_defender{'D', 11, 10};
};

TEST_F(SwordsmanTest, ConstructorId) {
	EXPECT_EQ(swordsman.id, 'S');
}

TEST_F(SwordsmanTest, ConstructorUnitType) {
	EXPECT_EQ(swordsman.unit_type, Unit::UnitType::Sword);
}

TEST_F(SwordsmanTest, ConstructorHealth) {
	EXPECT_EQ(swordsman.health, int(Unit::MAX_HEALTH));
}

TEST_F(SwordsmanTest, ConstructorAttack) {
	EXPECT_EQ(swordsman.attack, 10);
}

TEST_F(SwordsmanTest, ConstructorDefense) {
	EXPECT_EQ(swordsman.defense, 5);
}

TEST_F(SwordsmanTest, ConstructorAttackRange) {
	EXPECT_EQ(swordsman.attack_range, 1);
}

TEST_F(SwordsmanTest, ConstructorMovementRange) {
	EXPECT_EQ(swordsman.movement_range, 5);
}

TEST_F(SwordsmanTest, ConstructorPositionRow) {
	EXPECT_EQ(swordsman.position_row, 10);
}

TEST_F(SwordsmanTest, ConstructorPositionCol) {
	EXPECT_EQ(swordsman.position_col, 10);
}

TEST_F(SwordsmanTest, ToString) {
	EXPECT_EQ(swordsman.to_string(), swordsman.to_string_base() + "Swordsman");
}

TEST_F(SwordsmanTest, AttackSwordsman) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			swordsman.health = Unit::MAX_HEALTH - i;
			swordsman_defender.health = Unit::MAX_HEALTH - j;

			int attacker_expected_damage = round((swordsman.attack - swordsman_defender.defense) * (swordsman.health / double(Unit::MAX_HEALTH)));
			int defender_expected_health_remaining = swordsman_defender.health - attacker_expected_damage;
			if (defender_expected_health_remaining < 0) { defender_expected_health_remaining = 0; }

			swordsman.attack_unit(&swordsman_defender);
			EXPECT_EQ(swordsman_defender.health, defender_expected_health_remaining);
		}
	}
}

TEST_F(SwordsmanTest, AttackPikeman) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			swordsman.health = Unit::MAX_HEALTH - i;
			pikeman.health = Unit::MAX_HEALTH - j;

			int attacker_expected_damage = round((swordsman.attack - pikeman.defense) * (swordsman.health / double(Unit::MAX_HEALTH)) * 1.5);
			int defender_expected_health_remaining = pikeman.health - attacker_expected_damage;
			if (defender_expected_health_remaining < 0) { defender_expected_health_remaining = 0; }

			swordsman.attack_unit(&pikeman);
			EXPECT_EQ(pikeman.health, defender_expected_health_remaining);
		}
	}
}

TEST_F(SwordsmanTest, AttackKnight) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			swordsman.health = Unit::MAX_HEALTH - i;
			knight.health = Unit::MAX_HEALTH - j;

			int attacker_expected_damage = round((swordsman.attack - knight.defense) * (swordsman.health / double(Unit::MAX_HEALTH)) * 0.5);
			int defender_expected_health_remaining = knight.health - attacker_expected_damage;
			if (defender_expected_health_remaining < 0) { defender_expected_health_remaining = 0; }

			swordsman.attack_unit(&knight);
			EXPECT_EQ(knight.health, defender_expected_health_remaining);
		}
	}
}

TEST_F(SwordsmanTest, AttackArcher) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			swordsman.health = Unit::MAX_HEALTH - i;
			archer.health = Unit::MAX_HEALTH - j;

			int attacker_expected_damage = round((swordsman.attack - archer.defense) * (swordsman.health / double(Unit::MAX_HEALTH)));
			int defender_expected_health_remaining = archer.health - attacker_expected_damage;
			if (defender_expected_health_remaining < 0) { defender_expected_health_remaining = 0; }

			swordsman.attack_unit(&archer);
			EXPECT_EQ(archer.health, defender_expected_health_remaining);
		}
	}
}

TEST_F(SwordsmanTest, SimultaneousCounterattack) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			swordsman.health = Unit::MAX_HEALTH - i;
			swordsman_defender.health = Unit::MAX_HEALTH - j;

			int defender_expected_damage = round((swordsman_defender.attack - swordsman.defense) * (swordsman_defender.health / double(Unit::MAX_HEALTH)));
			int attacker_expected_health_remaining = swordsman.health - defender_expected_damage;
			if (attacker_expected_health_remaining < 0) { attacker_expected_health_remaining = 0; }

			swordsman.attack_unit(&swordsman_defender);
			EXPECT_EQ(swordsman.health, attacker_expected_health_remaining);
		}
	}
}



/*****************
 * Pikeman Tests *
 *****************/

class PikemanTest : public ::testing::Test {
protected:
	Pikeman pikeman{'P', 10, 10};
	Swordsman swordsman{'S', 9, 10};
	Knight knight{'K', 10, 9};
	Archer archer{'A', 10, 11};
	Pikeman pikeman_defender{'D', 11, 10};
};

TEST_F(PikemanTest, ConstructorId) {
	EXPECT_EQ(pikeman.id, 'P');
}

TEST_F(PikemanTest, ConstructorUnitType) {
	EXPECT_EQ(pikeman.unit_type, Unit::UnitType::Spear);
}

TEST_F(PikemanTest, ConstructorHealth) {
	EXPECT_EQ(pikeman.health, int(Unit::MAX_HEALTH));
}

TEST_F(PikemanTest, ConstructorAttack) {
	EXPECT_EQ(pikeman.attack, 8);
}

TEST_F(PikemanTest, ConstructorDefense) {
	EXPECT_EQ(pikeman.defense, 7);
}

TEST_F(PikemanTest, ConstructorAttackRange) {
	EXPECT_EQ(pikeman.attack_range, 1);
}

TEST_F(PikemanTest, ConstructorMovementRange) {
	EXPECT_EQ(pikeman.movement_range, 3);
}

TEST_F(PikemanTest, ConstructorPositionRow) {
	EXPECT_EQ(pikeman.position_row, 10);
}

TEST_F(PikemanTest, ConstructorPositionCol) {
	EXPECT_EQ(pikeman.position_col, 10);
}

TEST_F(PikemanTest, ToString) {
	EXPECT_EQ(pikeman.to_string(), pikeman.to_string_base() + "Pikeman");
}

TEST_F(PikemanTest, AttackSwordsman) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			pikeman.health = Unit::MAX_HEALTH - i;
			swordsman.health = Unit::MAX_HEALTH - j;

			int attacker_expected_damage = round((pikeman.attack - swordsman.defense) * (pikeman.health / double(Unit::MAX_HEALTH)) * 0.5);
			int defender_expected_health_remaining = swordsman.health - attacker_expected_damage;
			if (defender_expected_health_remaining < 0) { defender_expected_health_remaining = 0; }

			pikeman.attack_unit(&swordsman);
			EXPECT_EQ(swordsman.health, defender_expected_health_remaining);
		}
	}
}

TEST_F(PikemanTest, AttackPikeman) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			pikeman.health = Unit::MAX_HEALTH - i;
			pikeman_defender.health = Unit::MAX_HEALTH - j;

			int attacker_expected_damage = round((pikeman.attack - pikeman_defender.defense) * (pikeman.health / double(Unit::MAX_HEALTH)));
			int defender_expected_health_remaining = pikeman_defender.health - attacker_expected_damage;
			if (defender_expected_health_remaining < 0) { defender_expected_health_remaining = 0; }

			pikeman.attack_unit(&pikeman_defender);
			EXPECT_EQ(pikeman_defender.health, defender_expected_health_remaining);
		}
	}
}

TEST_F(PikemanTest, AttackKnight) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			pikeman.health = Unit::MAX_HEALTH - i;
			knight.health = Unit::MAX_HEALTH - j;

			int attacker_expected_damage = round((pikeman.attack - knight.defense) * (pikeman.health / double(Unit::MAX_HEALTH)) * 1.5);
			int defender_expected_health_remaining = knight.health - attacker_expected_damage;
			if (defender_expected_health_remaining < 0) { defender_expected_health_remaining = 0; }

			pikeman.attack_unit(&knight);
			EXPECT_EQ(knight.health, defender_expected_health_remaining);
		}
	}
}

TEST_F(PikemanTest, AttackArcher) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			pikeman.health = Unit::MAX_HEALTH - i;
			archer.health = Unit::MAX_HEALTH - j;

			int attacker_expected_damage = round((pikeman.attack - archer.defense) * (pikeman.health / double(Unit::MAX_HEALTH)));
			int defender_expected_health_remaining = archer.health - attacker_expected_damage;
			if (defender_expected_health_remaining < 0) { defender_expected_health_remaining = 0; }

			pikeman.attack_unit(&archer);
			EXPECT_EQ(archer.health, defender_expected_health_remaining);
		}
	}
}

TEST_F(PikemanTest, SimultaneousCounterattack) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			pikeman.health = Unit::MAX_HEALTH - i;
			pikeman_defender.health = Unit::MAX_HEALTH - j;

			int defender_expected_damage = round((pikeman_defender.attack - pikeman.defense) * (pikeman_defender.health / double(Unit::MAX_HEALTH)));
			int attacker_expected_health_remaining = pikeman.health - defender_expected_damage;
			if (attacker_expected_health_remaining < 0) { attacker_expected_health_remaining = 0; }

			pikeman.attack_unit(&pikeman_defender);
			EXPECT_EQ(pikeman.health, attacker_expected_health_remaining);
		}
	}
}



/****************
 * Knight Tests *
 ****************/

class KnightTest : public ::testing::Test {
protected:
	Knight knight{'K', 10, 10};
	Swordsman swordsman{'S', 9, 10};
	Pikeman pikeman{'P', 10, 9};
	Archer archer{'A', 10, 11};
	Knight knight_defender{'D', 11, 10};
};

TEST_F(KnightTest, ConstructorId) {
	EXPECT_EQ(knight.id, 'K');
}

TEST_F(KnightTest, ConstructorUnitType) {
	EXPECT_EQ(knight.unit_type, Unit::UnitType::Horse);
}

TEST_F(KnightTest, ConstructorHealth) {
	EXPECT_EQ(knight.health, int(Unit::MAX_HEALTH));
}

TEST_F(KnightTest, ConstructorAttack) {
	EXPECT_EQ(knight.attack, 14);
}

TEST_F(KnightTest, ConstructorDefense) {
	EXPECT_EQ(knight.defense, 3);
}

TEST_F(KnightTest, ConstructorAttackRange) {
	EXPECT_EQ(knight.attack_range, 1);
}

TEST_F(KnightTest, ConstructorMovementRange) {
	EXPECT_EQ(knight.movement_range, 10);
}

TEST_F(KnightTest, ConstructorPositionRow) {
	EXPECT_EQ(knight.position_row, 10);
}

TEST_F(KnightTest, ConstructorPositionCol) {
	EXPECT_EQ(knight.position_col, 10);
}

TEST_F(KnightTest, ToString) {
	EXPECT_EQ(knight.to_string(), knight.to_string_base() + "Knight");
}

TEST_F(KnightTest, AttackSwordsman) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			knight.health = Unit::MAX_HEALTH - i;
			swordsman.health = Unit::MAX_HEALTH - j;

			int attacker_expected_damage = round((knight.attack - swordsman.defense) * (knight.health / double(Unit::MAX_HEALTH)) * 1.5);
			int defender_expected_health_remaining = swordsman.health - attacker_expected_damage;
			if (defender_expected_health_remaining < 0) { defender_expected_health_remaining = 0; }

			knight.attack_unit(&swordsman);
			EXPECT_EQ(swordsman.health, defender_expected_health_remaining);
		}
	}
}

TEST_F(KnightTest, AttackPikeman) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			knight.health = Unit::MAX_HEALTH - i;
			pikeman.health = Unit::MAX_HEALTH - j;

			int attacker_expected_damage = round((knight.attack - pikeman.defense) * (knight.health / double(Unit::MAX_HEALTH)) * 0.5);
			int defender_expected_health_remaining = pikeman.health - attacker_expected_damage;
			if (defender_expected_health_remaining < 0) { defender_expected_health_remaining = 0; }

			knight.attack_unit(&pikeman);
			EXPECT_EQ(pikeman.health, defender_expected_health_remaining);
		}
	}
}

TEST_F(KnightTest, AttackKnight) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			knight.health = Unit::MAX_HEALTH - i;
			knight_defender.health = Unit::MAX_HEALTH - j;

			int attacker_expected_damage = round((knight.attack - knight_defender.defense) * (knight.health / double(Unit::MAX_HEALTH)));
			int defender_expected_health_remaining = knight_defender.health - attacker_expected_damage;
			if (defender_expected_health_remaining < 0) { defender_expected_health_remaining = 0; }

			knight.attack_unit(&knight_defender);
			EXPECT_EQ(knight_defender.health, defender_expected_health_remaining);
		}
	}
}

TEST_F(KnightTest, AttackArcher) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			knight.health = Unit::MAX_HEALTH - i;
			archer.health = Unit::MAX_HEALTH - j;

			int attacker_expected_damage = round((knight.attack - archer.defense) * (knight.health / double(Unit::MAX_HEALTH)));
			int defender_expected_health_remaining = archer.health - attacker_expected_damage;
			if (defender_expected_health_remaining < 0) { defender_expected_health_remaining = 0; }

			knight.attack_unit(&archer);
			EXPECT_EQ(archer.health, defender_expected_health_remaining);
		}
	}
}

TEST_F(KnightTest, SimultaneousCounterattack) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			knight.health = Unit::MAX_HEALTH - i;
			knight_defender.health = Unit::MAX_HEALTH - j;

			int defender_expected_damage = round((knight_defender.attack - knight.defense) * (knight_defender.health / double(Unit::MAX_HEALTH)));
			int attacker_expected_health_remaining = knight.health - defender_expected_damage;
			if (attacker_expected_health_remaining < 0) { attacker_expected_health_remaining = 0; }

			knight.attack_unit(&knight_defender);
			EXPECT_EQ(knight.health, attacker_expected_health_remaining);
		}
	}
}



/****************
 * Archer Tests *
 ****************/

class ArcherTest : public ::testing::Test {
protected:
	Archer archer{'A', 10, 10};
	Swordsman swordsman{'S', 9, 10};
	Pikeman pikeman{'P', 10, 9};
	Knight knight{'K', 10, 11};
	Archer archer_defender{'D', 11, 10};
	Archer archer_ranged{'R', 13, 10};
};

TEST_F(ArcherTest, ConstructorId) {
	EXPECT_EQ(archer.id, 'A');
}

TEST_F(ArcherTest, ConstructorUnitType) {
	EXPECT_EQ(archer.unit_type, Unit::UnitType::Arrow);
}

TEST_F(ArcherTest, ConstructorHealth) {
	EXPECT_EQ(archer.health, int(Unit::MAX_HEALTH));
}

TEST_F(ArcherTest, ConstructorAttack) {
	EXPECT_EQ(archer.attack, 9);
}

TEST_F(ArcherTest, ConstructorDefense) {
	EXPECT_EQ(archer.defense, 1);
}

TEST_F(ArcherTest, ConstructorAttackRange) {
	EXPECT_EQ(archer.attack_range, 5);
}

TEST_F(ArcherTest, ConstructorMovementRange) {
	EXPECT_EQ(archer.movement_range, 3);
}

TEST_F(ArcherTest, ConstructorPositionRow) {
	EXPECT_EQ(archer.position_row, 10);
}

TEST_F(ArcherTest, ConstructorPositionCol) {
	EXPECT_EQ(archer.position_col, 10);
}

TEST_F(ArcherTest, ToString) {
	EXPECT_EQ(archer.to_string(), archer.to_string_base() + "Archer");
}

TEST_F(ArcherTest, AttackSwordsman) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			archer.health = Unit::MAX_HEALTH - i;
			swordsman.health = Unit::MAX_HEALTH - j;

			int attacker_expected_damage = round((archer.attack - swordsman.defense) * (archer.health / double(Unit::MAX_HEALTH)));
			int defender_expected_health_remaining = swordsman.health - attacker_expected_damage;
			if (defender_expected_health_remaining < 0) { defender_expected_health_remaining = 0; }

			archer.attack_unit(&swordsman);
			EXPECT_EQ(swordsman.health, defender_expected_health_remaining);
		}
	}
}

TEST_F(ArcherTest, AttackPikeman) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			archer.health = Unit::MAX_HEALTH - i;
			pikeman.health = Unit::MAX_HEALTH - j;

			int attacker_expected_damage = round((archer.attack - pikeman.defense) * (archer.health / double(Unit::MAX_HEALTH)));
			int defender_expected_health_remaining = pikeman.health - attacker_expected_damage;
			if (defender_expected_health_remaining < 0) { defender_expected_health_remaining = 0; }

			archer.attack_unit(&pikeman);
			EXPECT_EQ(pikeman.health, defender_expected_health_remaining);
		}
	}
}

TEST_F(ArcherTest, AttackKnight) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			archer.health = Unit::MAX_HEALTH - i;
			knight.health = Unit::MAX_HEALTH - j;

			int attacker_expected_damage = round((archer.attack - knight.defense) * (archer.health / double(Unit::MAX_HEALTH)));
			int defender_expected_health_remaining = knight.health - attacker_expected_damage;
			if (defender_expected_health_remaining < 0) { defender_expected_health_remaining = 0; }

			archer.attack_unit(&knight);
			EXPECT_EQ(knight.health, defender_expected_health_remaining);
		}
	}
}

TEST_F(ArcherTest, AttackArcher) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			archer.health = Unit::MAX_HEALTH - i;
			archer_defender.health = Unit::MAX_HEALTH - j;

			int attacker_expected_damage = round((archer.attack - archer_defender.defense) * (archer.health / double(Unit::MAX_HEALTH)));
			int defender_expected_health_remaining = archer_defender.health - attacker_expected_damage;
			if (defender_expected_health_remaining < 0) { defender_expected_health_remaining = 0; }

			archer.attack_unit(&archer_defender);
			EXPECT_EQ(archer_defender.health, defender_expected_health_remaining);
		}
	}
}

TEST_F(ArcherTest, SimultaneousCounterattack) {
	for (int i = 0; i < Unit::MAX_HEALTH; i += 1) {
		for (int j = 0; j < Unit::MAX_HEALTH; j += 1) {
			archer.health = Unit::MAX_HEALTH - i;
			archer_defender.health = Unit::MAX_HEALTH - j;

			int defender_expected_damage = round((archer_defender.attack - archer.defense) * (archer_defender.health / double(Unit::MAX_HEALTH)));
			int attacker_expected_health_remaining = archer.health - defender_expected_damage;
			if (attacker_expected_health_remaining < 0) { attacker_expected_health_remaining = 0; }

			archer.attack_unit(&archer_defender);
			EXPECT_EQ(archer.health, attacker_expected_health_remaining);
		}
	}
}

TEST_F(ArcherTest, RangedAttackAgainstMelee) {
	Unit* melee_defenders[3] = {&swordsman, &pikeman, &knight};
	for (int i = 0; i < 3; i += 1) {
		archer_ranged.health = Unit::MAX_HEALTH;
		archer_ranged.attack_unit(melee_defenders[i]);
		EXPECT_EQ(archer_ranged.health, int(Unit::MAX_HEALTH));
		EXPECT_LT(melee_defenders[i]->health, int(Unit::MAX_HEALTH));
	}
}

TEST_F(ArcherTest, RangedAttackAgainstArcher) {
	archer_ranged.attack_unit(&archer);
	EXPECT_LT(archer_ranged.health, int(Unit::MAX_HEALTH));
	EXPECT_LT(archer.health, int(Unit::MAX_HEALTH));
}
