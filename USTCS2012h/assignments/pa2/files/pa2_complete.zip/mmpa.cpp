#include <iostream>
#include <cstring>

#include "formula.h"
#include "mmpa.h"

using namespace std;

/*
 * mmpa.cpp
 * Implementation file for My Mini Proof Assistant (TM)
 * You should submit ONLY this file
 */

// Given
void print_thms(const Theorem *thms)
{
    while (thms != nullptr)
    {
        cout << thms->name;
        cout << " : ";
        print_formula(thms->stmt);
        cout << endl;
        thms = thms->next;
    }
}

void display_focus(const ProofState &proof_state)
{
    if (proof_state.focus == nullptr)
        return;
    Theorem *premises = proof_state.focus->premises;
    print_thms(premises);
    cout << "________________________________________________________________________________" << endl;
    print_formula(proof_state.focus->conclusion);
    cout << endl;
}


// Task 1: Preliminaries
void delete_thms(Theorem *thms)
{
    while (thms != nullptr)
    {
        Theorem *next = thms->next;
        delete[] thms->name;
        delete_formula(thms->stmt);
        delete thms;
        thms = next;
    }
}

const Theorem *id_exists(const char *id, const Theorem *thms)
{
    while (thms != nullptr)
    {
        if (strcmp(id, thms->name) == 0)
            return thms;
        thms = thms->next;
    }
    return nullptr;
}

void init_proof(ProofState &proof_state, Formula *goal)
{
    Context *ctx = new Context;
    ctx->premises = nullptr;
    ctx->conclusion = goal;
    ctx->prev = ctx;
    ctx->next = ctx;
    proof_state.focus = ctx;
}

bool has_subgoals(const ProofState &proof_state)
{
    return proof_state.focus != nullptr;
}

void add_thm_to_database(Theorem *&thms, const char *name, Formula *stmt)
{
    Theorem *new_result = new Theorem;
    new_result->name = new char[1 + strlen(name)];
    strcpy(new_result->name, name);
    new_result->stmt = stmt;
    new_result->next = thms;
    thms = new_result;
}

int num_subgoals(const ProofState &proof_state)
{
    if (proof_state.focus == nullptr)
        return 0;
    int result = 1;
    Context *current = proof_state.focus->next;
    while (current != proof_state.focus)
    {
        ++result;
        current = current->next;
    }
    return result;
}

void clear_proof_state(ProofState &proof_state)
{
    if (proof_state.focus == nullptr)
        return;
    Context *ctx = proof_state.focus->next;
    delete_thms(proof_state.focus->premises);
    delete_formula(proof_state.focus->conclusion);
    delete proof_state.focus;
    while (ctx != proof_state.focus)
    {
        Context *next = ctx->next;
        delete_thms(ctx->premises);
        delete_formula(ctx->conclusion);
        delete ctx;
        ctx = next;
    }
    proof_state.focus = nullptr;
}


// My own helper functions
void init_thm(Theorem *thm, const char *name, const Formula *stmt, Theorem *next)
{
    if (name != nullptr)
    {
        thm->name = new char[1 + strlen(name)];
        strcpy(thm->name, name);
    }
    else
    {
        thm->name = nullptr;
    }
    thm->stmt = formula_deep_copy(stmt);
    thm->next = next;
}

void solve_current_subgoal(ProofState &proof_state)
{
    if (proof_state.focus == nullptr)
        return;
    Context *focus = proof_state.focus;
    if (focus->next == focus)
    {
        delete_thms(focus->premises);
        delete_formula(focus->conclusion);
        delete focus;
        proof_state.focus = nullptr;
        return;
    }
    focus->prev->next = focus->next;
    focus->next->prev = focus->prev;
    proof_state.focus = focus->next;
    delete_thms(focus->premises);
    delete_formula(focus->conclusion);
    delete focus;
}

Theorem *duplicate_thms(const Theorem *thms)
{
    if (thms == nullptr)
        return nullptr;
    Theorem *result = new Theorem;
    if (thms->name == nullptr)
        result->name = nullptr;
    else
    {
        result->name = new char[1 + strlen(thms->name)];
        strcpy(result->name, thms->name);
    }
    result->stmt = formula_deep_copy(thms->stmt);
    result->next = duplicate_thms(thms->next);
    return result;
}

void duplicate_focus(ProofState &proof_state)
{
    if (proof_state.focus == nullptr)
        return;
    Context *ctx = new Context;
    ctx->premises = duplicate_thms(proof_state.focus->premises);
    ctx->conclusion = formula_deep_copy(proof_state.focus->conclusion);
    ctx->prev = proof_state.focus;
    ctx->next = proof_state.focus->next;
    proof_state.focus->next->prev = ctx;
    proof_state.focus->next = ctx;
}

void add_thm_to_premises(Context *ctx, Theorem *new_thm)
{
    new_thm->next = ctx->premises;
    ctx->premises = new_thm;
}


// Task 2: Tactics for constructive logic, Part I
void tactic_trivial(ProofState &proof_state)
{
    if (proof_state.focus == nullptr)
        return;
    if (!formula_is_T(proof_state.focus->conclusion))
    {
        cout << "Tactic 'trivial' failed: conclusion is not 'T'" << endl;
        return;
    }
    solve_current_subgoal(proof_state);
}

void tactic_exfalso(ProofState &proof_state)
{
    if (proof_state.focus == nullptr)
        return;
    Formula *conclusion = proof_state.focus->conclusion;
    proof_state.focus->conclusion = formula_F();
    delete_formula(conclusion);
}

void tactic_left(ProofState &proof_state)
{
    if (proof_state.focus == nullptr)
        return;
    if (!formula_is_disj(proof_state.focus->conclusion))
    {
        cout << "Tactic 'left' failed: conclusion is not a disjunction" << endl;
        return;
    }
    Formula *conclusion = proof_state.focus->conclusion;
    proof_state.focus->conclusion = formula_disj_left(conclusion);
    delete_formula(formula_disj_right(conclusion));
    delete conclusion;
}

void tactic_right(ProofState &proof_state)
{
    if (proof_state.focus == nullptr)
        return;
    if (!formula_is_disj(proof_state.focus->conclusion))
    {
        cout << "Tactic 'right' failed: conclusion is not a disjunction" << endl;
        return;
    }
    Formula *conclusion = proof_state.focus->conclusion;
    proof_state.focus->conclusion = formula_disj_right(conclusion);
    delete_formula(formula_disj_left(conclusion));
    delete conclusion;
}

void tactic_intro(ProofState &proof_state, const char *hyp)
{
    if (proof_state.focus == nullptr)
        return;
    if (!formula_is_impl(proof_state.focus->conclusion))
    {
        cout << "Tactic 'intro' failed: conclusion is not an implication" << endl;
        return;
    }
    if (id_exists(hyp, proof_state.focus->premises) != nullptr)
    {
        cout << "Tactic 'intro' failed: hypothesis name is already taken" << endl;
        return;
    }
    Formula *conclusion = proof_state.focus->conclusion;
    Theorem *hyp_P = new Theorem;
    init_thm(hyp_P, hyp, formula_impl_antecedent(conclusion));
    add_thm_to_premises(proof_state.focus, hyp_P);
    proof_state.focus->conclusion = formula_impl_consequent(conclusion);
    conclusion->right = nullptr;
    delete_formula(conclusion);
}

void tactic_split(ProofState &proof_state)
{
    if (proof_state.focus == nullptr)
        return;
    if (!formula_is_conj(proof_state.focus->conclusion))
    {
        cout << "Tactic 'split' failed: conclusion is not a conjunction" << endl;
        return;
    }
    duplicate_focus(proof_state);
    Formula *conclusion = proof_state.focus->conclusion;
    proof_state.focus->conclusion = formula_conj_left(conclusion);
    conclusion->left = nullptr;
    delete_formula(proof_state.focus->next->conclusion);
    proof_state.focus->next->conclusion = formula_conj_right(conclusion);
    conclusion->right = nullptr;
    delete_formula(conclusion);
}


// Task 3: Tactics for constructive logic, Part II
void tactic_contradiction(ProofState &proof_state, const Theorem *proven_results)
{
    if (proof_state.focus == nullptr)
        return;
    Theorem *premises = proof_state.focus->premises;
    while (premises != nullptr)
    {
        if (formula_is_F(premises->stmt))
        {
            solve_current_subgoal(proof_state);
            return;
        }
        premises = premises->next;
    }
    while (proven_results != nullptr)
    {
        if (formula_is_F(proven_results->stmt))
        {
            solve_current_subgoal(proof_state);
            return;
        }
        proven_results = proven_results->next;
    }
    cout << "Tactic 'contradiction' failed: no contradiction found in local or global context" << endl;
}

void tactic_destruct(ProofState &proof_state, const Theorem *proven_results, const char *hyp, const char *hyp1, const char *hyp2)
{
    if (proof_state.focus == nullptr)
        return;
    const Theorem *hyp_P_Q = id_exists(hyp, proof_state.focus->premises);
    if (hyp_P_Q == nullptr)
        hyp_P_Q = id_exists(hyp, proven_results);
    if (hyp_P_Q == nullptr)
    {
        cout << "Tactic 'destruct' failed: given hypothesis name not found in local or global context" << endl;
        return;
    }
    if (!formula_is_conj(hyp_P_Q->stmt) && !formula_is_disj(hyp_P_Q->stmt))
    {
        cout << "Tactic 'destruct' failed: the given hypothesis is not a conjunction or disjunction" << endl;
        return;
    }
    if (id_exists(hyp1, proof_state.focus->premises) != nullptr || id_exists(hyp2, proof_state.focus->premises) != nullptr)
    {
        cout << "Tactic 'destruct' failed: hypothesis name is already taken" << endl;
        return;
    }
    if (formula_is_conj(hyp_P_Q->stmt))
    {
        if (strcmp(hyp1, hyp2) == 0)
        {
            cout << "Tactic 'destruct' failed: the two hypothesis names must be unique" << endl;
            return;
        }
        Theorem *hyp2_Q = new Theorem;
        init_thm(hyp2_Q, hyp2, formula_conj_right(hyp_P_Q->stmt), proof_state.focus->premises);
        add_thm_to_premises(proof_state.focus, hyp2_Q);
        Theorem *hyp1_P = new Theorem;
        init_thm(hyp1_P, hyp1, formula_conj_left(hyp_P_Q->stmt), proof_state.focus->premises);
        add_thm_to_premises(proof_state.focus, hyp1_P);
        return;
    }
    else if (formula_is_disj(hyp_P_Q->stmt))
    {
        duplicate_focus(proof_state);
        Theorem *hyp1_P = new Theorem;
        init_thm(hyp1_P, hyp1, formula_disj_left(hyp_P_Q->stmt), proof_state.focus->premises);
        add_thm_to_premises(proof_state.focus, hyp1_P);
        Theorem *hyp2_Q = new Theorem;
        init_thm(hyp2_Q, hyp2, formula_disj_right(hyp_P_Q->stmt), proof_state.focus->next->premises);
        add_thm_to_premises(proof_state.focus->next, hyp2_Q);
    }
}

void tactic_apply(ProofState &proof_state, const Theorem *proven_results, const char *hyp)
{
    if (proof_state.focus == nullptr)
        return;
    const Theorem *hyp_impl = id_exists(hyp, proof_state.focus->premises);
    if (hyp_impl == nullptr)
        hyp_impl = id_exists(hyp, proven_results);
    if (hyp_impl == nullptr)
    {
        cout << "Tactic 'apply' failed: hypothesis not found in local or global context" << endl;
        return;
    }
    if (formulae_equal(hyp_impl->stmt, proof_state.focus->conclusion))
    {
        solve_current_subgoal(proof_state);
        return;
    }
    Theorem *premises = nullptr;
    Formula *hyp_impl_stmt = hyp_impl->stmt;
    int premises_length = 0;
    while (formula_is_impl(hyp_impl_stmt))
    {
        Theorem *temp = new Theorem;
        init_thm(temp, nullptr, formula_impl_antecedent(hyp_impl_stmt), premises);
        premises = temp;
        ++premises_length;
        hyp_impl_stmt = formula_impl_consequent(hyp_impl_stmt);
        if (formulae_equal(hyp_impl_stmt, proof_state.focus->conclusion))
        {
            for (int i = 0; i < premises_length - 1; ++i)
            {
                duplicate_focus(proof_state);
                proof_state.focus = proof_state.focus->next;
            }
            for (int i = 0; i < premises_length; ++i)
            {
                delete_formula(proof_state.focus->conclusion);
                proof_state.focus->conclusion = premises->stmt;
                Theorem *temp = premises;
                premises = premises->next;
                delete temp;
                proof_state.focus = proof_state.focus->prev;
            }
            proof_state.focus = proof_state.focus->next;
            return;
        }
    }
    delete_thms(premises);
    cout << "Tactic 'apply' failed: hypothesis is not applicable to conclusion" << endl;
}


// Task 4: Tactics for classical logic
void tactic_excluded_middle(ProofState &proof_state, const char *hyp, Formula *ex_mid_P)
{
    if (proof_state.focus == nullptr)
        return;
    if (id_exists(hyp, proof_state.focus->premises) != nullptr)
    {
        cout << "Tactic 'excluded_middle' failed: hypothesis name is already taken" << endl;
        return;
    }
    duplicate_focus(proof_state);
    Formula *ex_mid_not_P = formula_neg_of(formula_deep_copy(ex_mid_P));
    Theorem *hyp_P = new Theorem;
    init_thm(hyp_P, hyp, ex_mid_P, proof_state.focus->premises);
    add_thm_to_premises(proof_state.focus, hyp_P);
    Theorem *hyp_not_P = new Theorem;
    init_thm(hyp_not_P, hyp, ex_mid_not_P, proof_state.focus->next->premises);
    add_thm_to_premises(proof_state.focus->next, hyp_not_P);
    delete_formula(ex_mid_not_P);
}

void tactic_by_contradiction(ProofState &proof_state, const char *hyp)
{
    if (proof_state.focus == nullptr)
        return;
    if (id_exists(hyp, proof_state.focus->premises) != nullptr)
    {
        cout << "Tactic 'by_contradiction' failed: hypothesis name is already taken" << endl;
        return;
    }
    Formula *stmt_not_P = formula_neg_of(proof_state.focus->conclusion);
    Theorem *hyp_not_P = new Theorem;
    init_thm(hyp_not_P, hyp, stmt_not_P);
    add_thm_to_premises(proof_state.focus, hyp_not_P);
    proof_state.focus->conclusion = formula_F();
    delete_formula(stmt_not_P);
}

// Task 5: Tactics for proof management
void tactic_rotate(ProofState &proof_state, int n)
{
    if (proof_state.focus == nullptr)
        return;
    if (n < 0)
    {
        while (n < 0)
        {
            proof_state.focus = proof_state.focus->prev;
            ++n;
        }
        return;
    }
    while (n > 0)
    {
        proof_state.focus = proof_state.focus->next;
        --n;
    }
}

void tactic_clear(ProofState &proof_state, const char *hyp)
{
    if (proof_state.focus == nullptr)
        return;
    if (proof_state.focus->premises == nullptr)
    {
        cout << "Tactic 'clear' failed: no hypothesis of the given name found" << endl;
        return;
    }
    if (strcmp(hyp, proof_state.focus->premises->name) == 0)
    {
        Theorem *del_hyp = proof_state.focus->premises;
        proof_state.focus->premises = del_hyp->next;
        delete[] del_hyp->name;
        delete_formula(del_hyp->stmt);
        delete del_hyp;
        return;
    }
    Theorem *prev = proof_state.focus->premises;
    Theorem *current = prev->next;
    while (current != nullptr)
    {
        if (strcmp(hyp, current->name) == 0)
        {
            prev->next = current->next;
            delete[] current->name;
            delete_formula(current->stmt);
            delete current;
            return;
        }
        prev = current;
        current = current->next;
    }
    cout << "Tactic 'clear' failed: no hypothesis of the given name found" << endl;
}
