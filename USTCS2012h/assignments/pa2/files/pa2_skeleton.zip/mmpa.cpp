#include <iostream>
#include <cstring>

#include "formula.h"
#include "mmpa.h"

using namespace std;

/*
 * mmpa.cpp
 * Implementation file for My Mini Proof Assistant (TM)
 * You should submit ONLY this file
 */

// Given
void print_thms(const Theorem *thms)
{
    while (thms != nullptr)
    {
        cout << thms->name;
        cout << " : ";
        print_formula(thms->stmt);
        cout << endl;
        thms = thms->next;
    }
}

void display_focus(const ProofState &proof_state)
{
    if (proof_state.focus == nullptr)
        return;
    Theorem *premises = proof_state.focus->premises;
    print_thms(premises);
    cout << "________________________________________________________________________________" << endl;
    print_formula(proof_state.focus->conclusion);
    cout << endl;
}


// Task 1: Preliminaries
void delete_thms(Theorem *thms)
{
    // TODO
}

const Theorem *id_exists(const char *id, const Theorem *thms)
{
    // TODO
    return nullptr;
}

void init_proof(ProofState &proof_state, Formula *goal)
{
    // TODO
}

bool has_subgoals(const ProofState &proof_state)
{
    return false;  // TODO
}

void add_thm_to_database(Theorem *&thms, const char *name, Formula *stmt)
{
    // TODO
}

int num_subgoals(const ProofState &proof_state)
{
    return 0;  // TODO
}

void clear_proof_state(ProofState &proof_state)
{
    // TODO
}


// Task 2: Tactics for constructive logic, Part I
void tactic_trivial(ProofState &proof_state)
{
    // TODO
}

void tactic_exfalso(ProofState &proof_state)
{
    // TODO
}

void tactic_left(ProofState &proof_state)
{
    // TODO
}

void tactic_right(ProofState &proof_state)
{
    // TODO
}

void tactic_intro(ProofState &proof_state, const char *hyp)
{
    // TODO
}

void tactic_split(ProofState &proof_state)
{
    // TODO
}


// Task 3: Tactics for constructive logic, Part II
void tactic_contradiction(ProofState &proof_state, const Theorem *proven_results)
{
    // TODO
}

void tactic_destruct(ProofState &proof_state, const Theorem *proven_results, const char *hyp, const char *hyp1, const char *hyp2)
{
    // TODO
}

void tactic_apply(ProofState &proof_state, const Theorem *proven_results, const char *hyp)
{
    // TODO
}


// Task 4: Tactics for classical logic
void tactic_excluded_middle(ProofState &proof_state, const char *hyp, Formula *ex_mid_P)
{
    // TODO
}

void tactic_by_contradiction(ProofState &proof_state, const char *hyp)
{
    // TODO
}

// Task 5: Tactics for proof management
void tactic_rotate(ProofState &proof_state, int n)
{
    // TODO
}

void tactic_clear(ProofState &proof_state, const char *hyp)
{
    // TODO
}
