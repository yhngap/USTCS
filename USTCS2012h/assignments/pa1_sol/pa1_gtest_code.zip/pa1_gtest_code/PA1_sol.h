#ifndef PA1_SOL_H_
#define PA1_SOL_H_

#include "PA1.h"

// Game State Variables.
extern Cell grid_sol[MAX_ROWS][MAX_COLS];
extern bool has_mine_sol[MAX_ROWS][MAX_COLS];
extern int game_stats_sol[5]; // num_rows, num_cols, num_flags_left, num_safe_reveals_left, num_incorrect_flags.
extern bool mine_exploded_sol;

void reveal_sol(int row, int col);
void flag_sol(int row, int col);
bool local_solver_sol(int to_reveal[MAX_CELLS][2], int to_flag[MAX_CELLS][2], int num_cells[2]);
void classify_hidden_cells_sol(int constrained_cells[MAX_CELLS][2], int unconstrained_cells[MAX_CELLS][2], int num_hidden_cells[2]);
bool has_satisfiable_neighbor_constraints_sol(int row, int col);
void record_possibility_sol(int constrained_cells[MAX_CELLS][2], int num_constrained_cells, int num_flags_bounds_used[4], int num_safe_config_records[MAX_CELLS], int num_flagged_config_records[MAX_CELLS]);
void enumerate_possibilities_sol(int constrained_cells[MAX_CELLS][2], int index, int num_constrained_cells, int num_flags_bounds_used[4], int num_safe_config_records[MAX_CELLS], int num_flagged_config_records[MAX_CELLS]);
void handle_constrained_cells_sol(int constrained_cells[MAX_CELLS][2], int num_constrained_cells, int num_safe_config_records[MAX_CELLS], int num_flagged_config_records[MAX_CELLS], int cells_to_reveal[MAX_CELLS][2], int cells_to_flag[MAX_CELLS][2], int num_cells[2]);
void handle_unconstrained_cells_sol(int unconstrained_cells[MAX_CELLS][2], int num_unconstrained_cells, int num_flags_bounds_used[4], int cells_to_reveal[MAX_CELLS][2], int cells_to_flag[MAX_CELLS][2], int num_cells[2]);
bool global_solver_sol(int cells_to_reveal[MAX_CELLS][2], int cells_to_flag[MAX_CELLS][2], int num_cells[2]);

#endif /* PA1_SOL_H_ */
