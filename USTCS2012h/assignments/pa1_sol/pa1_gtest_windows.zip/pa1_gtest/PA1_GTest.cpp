#include <chrono>
//#include <iostream>
#include <set>
#include <utility>
#include "gtest/gtest.h"
#include "PA1.h"
#include "PA1_sol.h"
using namespace std;

// Game State Variables.
Cell grid[MAX_ROWS][MAX_COLS];
bool has_mine[MAX_ROWS][MAX_COLS]; // Default value of false.
int game_stats[5]; // num_rows, num_cols, num_flags_left, num_safe_reveals_left, num_incorrect_flags.
bool mine_exploded = false;



// Helper functions.
//void display_grid_or_sol(Cell grid_input[MAX_ROWS][MAX_COLS], int game_stats_input[5]) {
//	cout << '\n';
//	cout << "  ";
//	for (int col = 0; col < game_stats_input[1]; col += 1) {
//		cout << ' ' << char(col + 'A');
//	}
//	cout << '\n';
//
//	for (int row = 0; row < game_stats_input[0]; row += 1) {
//		if (row < 9) {
//			cout << ' ';
//		}
//		cout << row + 1;
//
//		for (int col = 0; col < game_stats_input[1]; col += 1) {
//			cout << ' ';
//			switch (grid_input[row][col]) {
//			case HIDDEN:
//				cout << 'o';
//				break;
//			case FLAGGED:
//				cout << 'x';
//				break;
//			case SAFE:
//				cout << '?';
//				break;
//			case MINE:
//				cout << '!';
//				break;
//			case ZERO:
//				cout << '.';
//				break;
//			default:
//				cout << grid_input[row][col]; // Unscoped enum implicit conversion to int.
//			}
//		}
//		cout << '\n';
//	}
//
//	cout << '\n';
//	cout << "Flags Left: " << game_stats_input[2] << '\n';
//	cout << "Safe cells left: " << game_stats_input[3] << '\n';
//	cout << "Incorrect flags: " << game_stats_input[4] << '\n';
//	cout << '\n';
//}

void reset_grid_layout(Cell layout_to_reset[MAX_ROWS][MAX_COLS]) {
	for (int row = 0; row < MAX_ROWS; row += 1) {
		for (int col = 0; col < MAX_COLS; col += 1) {
			layout_to_reset[row][col] = HIDDEN;
		}
	}
}

void reset_mine_layout(bool layout_to_reset[MAX_ROWS][MAX_COLS]) {
	for (int row = 0; row < MAX_ROWS; row += 1) {
		for (int col = 0; col < MAX_COLS; col += 1) {
			layout_to_reset[row][col] = false;
		}
	}
}

void reset_all() {
	reset_grid_layout(grid);
	reset_mine_layout(has_mine);
	game_stats[0] = game_stats[1] = game_stats[2] = game_stats[3] = game_stats[4] = 0;
	mine_exploded = false;

	reset_grid_layout(grid_sol);
	reset_mine_layout(has_mine_sol);
	game_stats_sol[0] = game_stats_sol[1] = game_stats_sol[2] = game_stats_sol[3] = game_stats_sol[4] = 0;
	mine_exploded_sol = false;
}


void copy_grid_layout(Cell layout_overwritten[MAX_ROWS][MAX_COLS], Cell layout_input[MAX_ROWS][MAX_COLS]) {
	for (int row = 0; row < MAX_ROWS; row += 1) {
		for (int col = 0; col < MAX_COLS; col += 1) {
			layout_overwritten[row][col] = layout_input[row][col];
		}
	}
}

void copy_mine_layout(bool layout_overwritten[MAX_ROWS][MAX_COLS], bool layout_input[MAX_ROWS][MAX_COLS]) {
	for (int row = 0; row < MAX_ROWS; row += 1) {
		for (int col = 0; col < MAX_COLS; col += 1) {
			layout_overwritten[row][col] = layout_input[row][col];
		}
	}
}

void copy_sol_to_current_state() {
	copy_grid_layout(grid, grid_sol);
	copy_mine_layout(has_mine, has_mine_sol);
	for (int i = 0; i < 5; i += 1) {
		game_stats[i] = game_stats_sol[i];
	}
	mine_exploded = mine_exploded_sol;
}

//void generate_random_mine_layout(int num_rows, int num_cols, int num_mines, unsigned int seed, bool has_mine_output[MAX_ROWS][MAX_COLS]) {
//	reset_mine_layout(has_mine_output);
//	srand(seed);
//	for (int n = 0; n < num_mines; n += 1) {
//		int row = rand() % num_rows;
//		int col = rand() % num_cols;
//
//		// If already have a mine in this location, increment col and wrap-around in row-major order.
//		while (has_mine_output[row][col]) {
//			row = (row + ((col+1)/num_cols)) % num_rows;
//			col = (col+1) % num_cols;
//		}
//		has_mine_output[row][col] = true;
//	}
//}



/********************
 * Task 1: reveal() *
 ********************/
TEST(Reveal, NonZeroCell) {
	// Grid Setup.
	reset_all();

	bool has_mine_copy[MAX_ROWS][MAX_COLS] = {
		{true , true , true , true , false},
		{true , false, false, false, false},
		{true , true , true , false, false},
		{true , false, true , false, false},
		{true , true , true , true , false},
		{true , false, true , false, false},
		{true , false, false, false, false}
	};
	copy_mine_layout(has_mine, has_mine_copy);

	game_stats[0] = 7;
	game_stats[1] = 5;
	game_stats[2] = 17;
	int num_safe_reveals_left = game_stats[0] * game_stats[1] - game_stats[2];
	game_stats[3] = num_safe_reveals_left;
	game_stats[4] = 0;
	mine_exploded = false;

	// Reveal 8 cells which have 1-8 neighbor mines.
	reveal(6, 3);
	num_safe_reveals_left -= 1;
	EXPECT_EQ(grid[6][3], Cell(1));
	EXPECT_EQ(game_stats[3], num_safe_reveals_left);

	reveal(2, 3);
	num_safe_reveals_left -= 1;
	EXPECT_EQ(grid[2][3], Cell(2));
	EXPECT_EQ(game_stats[3], num_safe_reveals_left);

	reveal(5, 3);
	num_safe_reveals_left -= 1;
	EXPECT_EQ(grid[5][3], Cell(3));
	EXPECT_EQ(game_stats[3], num_safe_reveals_left);

	reveal(3, 3);
	num_safe_reveals_left -= 1;
	EXPECT_EQ(grid[3][3], Cell(4));
	EXPECT_EQ(game_stats[3], num_safe_reveals_left);

	reveal(1, 2);
	num_safe_reveals_left -= 1;
	EXPECT_EQ(grid[1][2], Cell(5));
	EXPECT_EQ(game_stats[3], num_safe_reveals_left);

	reveal(5, 1);
	num_safe_reveals_left -= 1;
	EXPECT_EQ(grid[5][1], Cell(6));
	EXPECT_EQ(game_stats[3], num_safe_reveals_left);

	reveal(1, 1);
	num_safe_reveals_left -= 1;
	EXPECT_EQ(grid[1][1], Cell(7));
	EXPECT_EQ(game_stats[3], num_safe_reveals_left);

	reveal(3, 1);
	num_safe_reveals_left -= 1;
	EXPECT_EQ(grid[3][1], Cell(8));
	EXPECT_EQ(game_stats[3], num_safe_reveals_left);

	// Reveal a mine.
	reveal(0, 0);
	EXPECT_EQ(grid[0][0], MINE);
	EXPECT_TRUE(mine_exploded);
}

TEST(Reveal, ZeroCell) {
	// Grid Setup.
	reset_all();

	bool has_mine_copy[MAX_ROWS][MAX_COLS] = {
		{false, true , true , false, false, false, false, true , false},
		{false, false, false, false, false, false, false, false, false},
		{false, true , false, true , false, false, false, false, false},
		{false, false, false, false, false, false, false, false, false},
		{false, false, false, true , true , false, false, false, false},
		{false, false, false, false, false, false, true , false, false},
		{false, true , false, false, false, false, false, false, false},
		{false, false, true , false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, false},
	};
	copy_mine_layout(has_mine_sol, has_mine_copy);

	game_stats_sol[0] = game_stats_sol[1] = 9;
	game_stats_sol[2] = 10;
	game_stats_sol[3] = game_stats_sol[0] * game_stats_sol[1] - game_stats_sol[2];
	game_stats_sol[4] = 0;
	mine_exploded_sol = false;

	copy_sol_to_current_state();

	// Reveal the bottom-right cell and compare with solution.
	reveal(8, 8);
	reveal_sol(8, 8);
	for (int row = 0; row < game_stats[0]; row += 1) {
		for (int col = 0; col < game_stats[1]; col += 1) {
			EXPECT_EQ(grid[row][col], grid_sol[row][col]);
		}
	}
	EXPECT_EQ(game_stats[3], game_stats_sol[3]);
}



/******************
 * Task 2: flag() *
 ******************/
TEST(Flag, Toggle) {
	// Grid Setup.
	reset_all();

	bool has_mine_copy[MAX_ROWS][MAX_COLS] = {
		{false, false, false, false, false},
		{false, false, false, false, false},
		{false, false, true , false, false},
		{false, false, false, false, false},
		{false, false, false, false, false}
	};
	copy_mine_layout(has_mine, has_mine_copy);

	game_stats[0] = game_stats[1] = 5;
	game_stats[2] = 1;
	game_stats[3] = game_stats[0] * game_stats[1] - game_stats[2];
	game_stats[4] = 0;
	mine_exploded = false;

	// Flag and unflag the center mine.
	flag(2, 2);
	EXPECT_EQ(grid[2][2], FLAGGED);
	EXPECT_EQ(game_stats[2], 0);
	EXPECT_EQ(game_stats[4], 0);

	flag(2, 2);
	EXPECT_EQ(grid[2][2], HIDDEN);
	EXPECT_EQ(game_stats[2], 1);
	EXPECT_EQ(game_stats[4], 0);

	// Flag and unflag the top-left safe cell.
	flag(0, 0);
	EXPECT_EQ(grid[0][0], FLAGGED);
	EXPECT_EQ(game_stats[2], 0);
	EXPECT_EQ(game_stats[4], 1);

	flag(0, 0);
	EXPECT_EQ(grid[0][0], HIDDEN);
	EXPECT_EQ(game_stats[2], 1);
	EXPECT_EQ(game_stats[4], 0);
}



/**************************
 * Task 3: local_solver() *
 **************************/
TEST(LocalSolver, CompletelyHiddenGrid) {
	// Grid Setup.
	reset_all();
	has_mine[0][0] = true;
	game_stats[0] = game_stats[1] = 25;
	game_stats[2] = 1;
	game_stats[3] = game_stats[0] * game_stats[1] - game_stats[2];
	game_stats[4] = 0;
	mine_exploded = false;

	// Completely Hidden Grid should return false.
	int cells_to_reveal[MAX_CELLS][2] = {};
	int cells_to_flag[MAX_CELLS][2] = {};
	int num_cells[2] = {};
	bool local_solver_return_value = local_solver(cells_to_reveal, cells_to_flag, num_cells);

	EXPECT_FALSE(local_solver_return_value);
	EXPECT_EQ(num_cells[0], 0);
	EXPECT_EQ(num_cells[1], 0);
}

TEST(LocalSolver, SimpleReveal) {
	// Grid Setup.
	reset_all();

	bool has_mine_copy[MAX_ROWS][MAX_COLS] = {
		{false, false, false, false, false},
		{false, true , false, true , false},
		{false, true , false, false, false},
		{false, false, true , false, false},
		{false, false, false, false, true }
	};
	copy_mine_layout(has_mine_sol, has_mine_copy);

	game_stats_sol[0] = game_stats_sol[1] = 5;
	game_stats_sol[2] = 5;
	game_stats_sol[3] = game_stats_sol[0] * game_stats_sol[1] - game_stats_sol[2];
	game_stats_sol[4] = 0;
	mine_exploded_sol = false;

	//copy_sol_to_current_state();

	// Partially reveal and flag the grid.
	reveal_sol(0, 0);
	flag_sol(1, 1);
	reveal_sol(3, 1);
	flag_sol(2, 1);
	flag_sol(3, 2);
	reveal_sol(1, 2);
	flag_sol(1, 3);
	reveal_sol(3, 4);
	flag_sol(4, 4);
	copy_sol_to_current_state();

	// Call and compare with solution.
	int cells_to_reveal_sol[MAX_CELLS][2] = {};
	int cells_to_flag_sol[MAX_CELLS][2] = {};
	int num_cells_sol[2] = {};
	bool local_solver_return_value_sol = local_solver_sol(cells_to_reveal_sol, cells_to_flag_sol, num_cells_sol);

	int cells_to_reveal[MAX_CELLS][2] = {};
	int cells_to_flag[MAX_CELLS][2] = {};
	int num_cells[2] = {};
	bool local_solver_return_value = local_solver(cells_to_reveal, cells_to_flag, num_cells);

	EXPECT_EQ(local_solver_return_value, local_solver_return_value_sol);
	EXPECT_EQ(num_cells[0], num_cells_sol[0]);

	// Convert into STL Set and compare cells to reveal.
	set<pair<int, int>> cells_to_reveal_set_sol;
	for (int i = 0; i < num_cells_sol[0]; i += 1) {
		cells_to_reveal_set_sol.emplace(cells_to_reveal_sol[i][0], cells_to_reveal_sol[i][1]);
	}

	set<pair<int, int>> cells_to_reveal_set;
	for (int i = 0; i < num_cells_sol[0]; i += 1) {
		cells_to_reveal_set.emplace(cells_to_reveal[i][0], cells_to_reveal[i][1]);
	}

	EXPECT_EQ(cells_to_reveal_set, cells_to_reveal_set_sol);
	for (auto c_iter = cells_to_reveal_set.cbegin(), c_iter_sol = cells_to_reveal_set_sol.cbegin();
			c_iter != cells_to_reveal_set.end() && c_iter_sol != cells_to_reveal_set_sol.end();
			++c_iter, ++c_iter_sol) {
		EXPECT_EQ(*c_iter, *c_iter_sol);
	}
}

TEST(LocalSolver, SimpleFlag) {
	// Grid Setup.
	reset_all();

	bool has_mine_copy[MAX_ROWS][MAX_COLS] = {
		{false, false, false, false, false},
		{false, true , false, true , false},
		{false, true , false, false, false},
		{false, false, true , false, false},
		{false, false, false, false, true }
	};
	copy_mine_layout(has_mine_sol, has_mine_copy);

	game_stats_sol[0] = game_stats_sol[1] = 5;
	game_stats_sol[2] = 5;
	game_stats_sol[3] = game_stats_sol[0] * game_stats_sol[1] - game_stats_sol[2];
	game_stats_sol[4] = 0;
	mine_exploded_sol = false;

	//copy_sol_to_current_state();

	// Reveal the grid except for the flags.
	reveal_sol(0, 0);
	reveal_sol(0, 1);
	reveal_sol(0, 2);
	reveal_sol(0, 3);
	reveal_sol(0, 4);
	reveal_sol(1, 0);
	reveal_sol(1, 2);
	reveal_sol(1, 4);
	reveal_sol(2, 0);
	reveal_sol(2, 2);
	reveal_sol(2, 3);
	reveal_sol(2, 4);
	reveal_sol(4, 0);
	reveal_sol(3, 3);
	reveal_sol(3, 4);
	reveal_sol(4, 2);
	reveal_sol(4, 3);
	copy_sol_to_current_state();

	// Call and compare with solution.
	int cells_to_reveal_sol[MAX_CELLS][2] = {};
	int cells_to_flag_sol[MAX_CELLS][2] = {};
	int num_cells_sol[2] = {};
	bool local_solver_return_value_sol = local_solver_sol(cells_to_reveal_sol, cells_to_flag_sol, num_cells_sol);

	int cells_to_reveal[MAX_CELLS][2] = {};
	int cells_to_flag[MAX_CELLS][2] = {};
	int num_cells[2] = {};
	bool local_solver_return_value = local_solver(cells_to_reveal, cells_to_flag, num_cells);

	EXPECT_EQ(local_solver_return_value, local_solver_return_value_sol);
	EXPECT_EQ(num_cells[1], num_cells_sol[1]);

	// Convert into STL Set and compare cells to flag.
	set<pair<int, int>> cells_to_flag_set_sol;
	for (int i = 0; i < num_cells_sol[1]; i += 1) {
		cells_to_flag_set_sol.emplace(cells_to_flag_sol[i][0], cells_to_flag_sol[i][1]);
	}

	set<pair<int, int>> cells_to_flag_set;
	for (int i = 0; i < num_cells_sol[1]; i += 1) {
		cells_to_flag_set.emplace(cells_to_flag[i][0], cells_to_flag[i][1]);
	}

	EXPECT_EQ(cells_to_flag_set, cells_to_flag_set_sol);
	for (auto c_iter = cells_to_flag_set.cbegin(), c_iter_sol = cells_to_flag_set_sol.cbegin();
			c_iter != cells_to_flag_set.end() && c_iter_sol != cells_to_flag_set_sol.end();
			++c_iter, ++c_iter_sol) {
		EXPECT_EQ(*c_iter, *c_iter_sol);
	}
}

TEST(LocalSolver, GeneralGrid) {
	// Grid Setup.
	reset_all();

	bool has_mine_copy[MAX_ROWS][MAX_COLS] = {
		{false, false, false, true , false, false, true , false, false, true , false, false, false, false, false, false, true , false, false, true , false, false, false, false, false},
		{false, false, false, false, false, true , false, true , true , false, false, false, false, false, false, false, true , false, false, false, false, false, false, false, false},
		{true , false, false, false, false, false, false, false, false, false, false, false, false, true , true , false, false, false, false, true , false, false, false, false, false},
		{false, false, false, false, true , false, true , true , true , false, false, false, false, false, false, true , false, true , false, false, true , false, false, false, false},
		{false, false, false, false, false, false, false, false, false, false, false, true , false, true , false, true , false, false, false, false, true , false, false, false, true },
		{false, false, false, false, false, true , false, true , false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, false, true , false, false, false, false, true , false, false, false, true , false, false, false, false, false, false},
		{true , false, false, false, false, false, true , true , false, false, true , false, false, false, false, false, false, false, false, false, false, true , false, false, false},
		{false, true , false, false, false, false, false, false, false, false, false, false, true , false, false, false, true , false, false, false, false, false, false, true , false},
		{true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true , true , false},
		{false, false, false, false, false, false, false, false, true , false, false, false, false, false, true , false, true , false, false, false, false, false, true , true , false},
		{false, false, false, false, false, false, false, false, false, false, true , false, false, false, false, false, true , false, true , false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, true , false, false, true , false, false, false, false, true , false, false, false, true , false, false, false, false},
		{false, true , true , false, false, false, false, false, false, false, false, false, false, true , false, false, false, true , false, true , false, false, false, false, false},
		{false, false, false, false, false, false, true , false, false, false, false, false, true , true , false, false, false, false, false, true , false, false, false, false, true },
		{false, false, false, false, false, false, false, false, false, false, false, false, true , false, false, false, false, true , false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, true , false, false, false, false, false, false, true , false, true , false, true , false, false, false, false, false, true },
		{true , false, true , false, false, false, false, false, false, false, false, false, false, false, true , false, false, true , false, false, false, true , false, false, false},
		{false, true , true , true , false, false, false, false, false, true , true , false, false, true , true , false, true , false, true , false, true , true , false, false, false},
		{false, false, false, false, true , false, false, false, false, false, false, false, false, false, false, false, false, false, true , false, false, true , false, false, false},
		{false, false, true , true , false, false, true , true , false, true , false, true , false, false, false, false, false, false, false, false, false, false, false, true , false},
		{false, false, false, true , false, false, true , false, false, true , true , false, false, false, true , false, false, true , false, true , false, false, false, true , true },
		{false, false, false, false, false, true , true , true , false, false, true , false, false, false, false, false, false, true , false, false, true , false, false, false, false},
		{false, false, false, false, false, false, false, true , true , false, false, false, false, false, false, false, false, false, false, false, true , false, false, false, false},
		{true , true , false, true , false, false, true , true , false, false, true , false, false, false, false, false, false, true , false, false, true , true , false, true , false}
	};
	copy_mine_layout(has_mine_sol, has_mine_copy);

	game_stats_sol[0] = game_stats_sol[1] = 25;
	game_stats_sol[2] = 125;
	game_stats_sol[3] = game_stats_sol[0] * game_stats_sol[1] - game_stats_sol[2];
	game_stats_sol[4] = 0;
	mine_exploded_sol = false;

	copy_sol_to_current_state();

	// Reveal part of the grid and run local_solver().
	//reveal(0, 0);
	reveal_sol(0, 0);
	//reveal(2, 2);
	reveal_sol(2, 2);
	copy_sol_to_current_state();

	int cells_to_reveal_sol[MAX_CELLS][2] = {};
	int cells_to_flag_sol[MAX_CELLS][2] = {};
	int num_cells_sol[2] = {};

	int cells_to_reveal[MAX_CELLS][2] = {};
	int cells_to_flag[MAX_CELLS][2] = {};
	int num_cells[2] = {};

	bool local_solver_return_sol = true;
	while (local_solver_return_sol) {
		local_solver_return_sol = local_solver_sol(cells_to_reveal_sol, cells_to_flag_sol, num_cells_sol);
		bool local_solver_return = local_solver(cells_to_reveal, cells_to_flag, num_cells);

		// Compare return value and num cells.
		EXPECT_EQ(local_solver_return, local_solver_return_sol);
		EXPECT_EQ(num_cells[0], num_cells_sol[0]);
		EXPECT_EQ(num_cells[1], num_cells_sol[1]);

		// Compare cells to reveal.
		set<pair<int, int>> cells_to_reveal_set_sol;
		for (int i = 0; i < num_cells_sol[0]; i += 1) {
			cells_to_reveal_set_sol.emplace(cells_to_reveal_sol[i][0], cells_to_reveal_sol[i][1]);
		}

		set<pair<int, int>> cells_to_reveal_set;
		for (int i = 0; i < num_cells_sol[0]; i += 1) {
			cells_to_reveal_set.emplace(cells_to_reveal[i][0], cells_to_reveal[i][1]);
		}

		EXPECT_EQ(cells_to_reveal_set, cells_to_reveal_set_sol);
		for (auto c_iter = cells_to_reveal_set.cbegin(), c_iter_sol = cells_to_reveal_set_sol.cbegin();
				c_iter != cells_to_reveal_set.end() && c_iter_sol != cells_to_reveal_set_sol.end();
				++c_iter, ++c_iter_sol) {
			EXPECT_EQ(*c_iter, *c_iter_sol);
		}

		// Compare cells to flag.
		set<pair<int, int>> cells_to_flag_set_sol;
		for (int i = 0; i < num_cells_sol[1]; i += 1) {
			cells_to_flag_set_sol.emplace(cells_to_flag_sol[i][0], cells_to_flag_sol[i][1]);
		}

		set<pair<int, int>> cells_to_flag_set;
		for (int i = 0; i < num_cells_sol[1]; i += 1) {
			cells_to_flag_set.emplace(cells_to_flag[i][0], cells_to_flag[i][1]);
		}

		EXPECT_EQ(cells_to_flag_set, cells_to_flag_set_sol);
		for (auto c_iter = cells_to_flag_set.cbegin(), c_iter_sol = cells_to_flag_set_sol.cbegin();
				c_iter != cells_to_flag_set.end() && c_iter_sol != cells_to_flag_set_sol.end();
				++c_iter, ++c_iter_sol) {
			EXPECT_EQ(*c_iter, *c_iter_sol);
		}

		// Reveal and Flag each iteration.
		for (int i = 0; i < num_cells_sol[0]; i += 1) {
			//reveal(cells_to_reveal[i][0], cells_to_reveal[i][1]);
			reveal_sol(cells_to_reveal_sol[i][0], cells_to_reveal_sol[i][1]);
		}
		for (int i = 0; i < num_cells_sol[1]; i += 1) {
			//flag(cells_to_flag[i][0], cells_to_flag[i][1]);
			flag_sol(cells_to_flag_sol[i][0], cells_to_flag_sol[i][1]);
		}
		copy_sol_to_current_state();

		// Uncomment to display grid and sol at each iteration.
//		cout << '\n';
//		cout << "Actual Grid: ";
//		display_grid_or_sol(grid, game_stats);
//		cout << "Grid Solution: ";
//		display_grid_or_sol(grid_sol, game_stats_sol);
//		cout << '\n';
	}
}



/***********************************
 * Task 4: classify_hidden_cells() *
 ***********************************/
TEST(ClassifyHiddenCells, CompletelyHiddenGrid) {
	// Grid Setup.
	reset_all();
	has_mine[0][0] = true;
	game_stats[0] = game_stats[1] = 25;
	game_stats[2] = 1;
	game_stats[3] = game_stats[0] * game_stats[1] - game_stats[2];
	game_stats[4] = 0;
	mine_exploded = false;

	// Return Arrays zero-initialization.
	int constrained_cells[MAX_CELLS][2] = {};
	int unconstrained_cells[MAX_CELLS][2] = {};
	int num_cells[2] = {};

	// Convert into STL Set and compare.
	classify_hidden_cells(constrained_cells, unconstrained_cells, num_cells);
	EXPECT_EQ(num_cells[0], 0);
	EXPECT_EQ(num_cells[1], MAX_CELLS);

	set<pair<int, int>> unconstrained_cells_set;
	for (int i = 0; i < MAX_CELLS; i += 1) {
		unconstrained_cells_set.emplace(unconstrained_cells[i][0], unconstrained_cells[i][1]);
	}

	set<pair<int, int>> unconstrained_cells_set_sol;
	for (int row = 0; row < MAX_ROWS; row += 1) {
		for (int col = 0; col < MAX_COLS; col += 1) {
			unconstrained_cells_set_sol.emplace(row, col);
		}
	}

	// Also try to manually compare each element in the set, so that the GTest report will show more details of the difference.
	EXPECT_EQ(unconstrained_cells_set, unconstrained_cells_set_sol);
	for (auto c_iter = unconstrained_cells_set.cbegin(), c_iter_sol = unconstrained_cells_set_sol.cbegin();
			c_iter != unconstrained_cells_set.end() && c_iter_sol != unconstrained_cells_set_sol.end();
			++c_iter, ++c_iter_sol) {
		EXPECT_EQ(*c_iter, *c_iter_sol);
	}
}

TEST(ClassifyHiddenCells, PartiallyRevealedGrid) {
	// Grid Setup.
	reset_all();

	bool has_mine_copy[MAX_ROWS][MAX_COLS] = {
		{false, false, false, false, false, false, true , false, false},
		{false, false, false, true , false, false, false, false, false},
		{false, false, false, false, true , true , false, false, false},
		{false, false, true , false, false, false, false, false, false},
		{false, false, true , false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, false},
		{true , false, false, false, true , false, true , false, false},
		{false, false, false, false, false, false, false, false, false},
		{false, false, false, false, true , false, false, false, false}
	};
	copy_mine_layout(has_mine_sol, has_mine_copy);

	game_stats_sol[0] = game_stats_sol[1] = 9;
	game_stats_sol[2] = 10;
	game_stats_sol[3] = game_stats_sol[0] * game_stats_sol[1] - game_stats_sol[2];
	game_stats_sol[4] = 0;
	mine_exploded_sol = false;

	copy_sol_to_current_state();

	// Reveal bottom-right cell and classify.
	reveal_sol(8, 8);
	copy_grid_layout(grid, grid_sol);

	int constrained_cells_sol[MAX_CELLS][2] = {};
	int unconstrained_cells_sol[MAX_CELLS][2] = {};
	int num_cells_sol[2] = {};
	classify_hidden_cells_sol(constrained_cells_sol, unconstrained_cells_sol, num_cells_sol);

	int constrained_cells[MAX_CELLS][2] = {};
	int unconstrained_cells[MAX_CELLS][2] = {};
	int num_cells[2] = {};
	classify_hidden_cells(constrained_cells, unconstrained_cells, num_cells);

	EXPECT_EQ(num_cells[0], num_cells_sol[0]);
	EXPECT_EQ(num_cells[1], num_cells_sol[1]);

	// Compare constrained cells.
	set<pair<int, int>> constrained_cells_set_sol;
	for (int i = 0; i < num_cells_sol[0]; i += 1) {
		constrained_cells_set_sol.emplace(constrained_cells_sol[i][0], constrained_cells_sol[i][1]);
	}

	set<pair<int, int>> constrained_cells_set;
	for (int i = 0; i < num_cells_sol[0]; i += 1) {
		constrained_cells_set.emplace(constrained_cells[i][0], constrained_cells[i][1]);
	}

	EXPECT_EQ(constrained_cells_set, constrained_cells_set_sol);
	for (auto c_iter = constrained_cells_set.cbegin(), c_iter_sol = constrained_cells_set_sol.cbegin();
			c_iter != constrained_cells_set.end() && c_iter_sol != constrained_cells_set_sol.end();
			++c_iter, ++c_iter_sol) {
		EXPECT_EQ(*c_iter, *c_iter_sol);
	}

	// Compare unconstrained cells.
	set<pair<int, int>> unconstrained_cells_set_sol;
	for (int i = 0; i < num_cells_sol[1]; i += 1) {
		unconstrained_cells_set_sol.emplace(unconstrained_cells_sol[i][0], unconstrained_cells_sol[i][1]);
	}

	set<pair<int, int>> unconstrained_cells_set;
	for (int i = 0; i < num_cells_sol[1]; i += 1) {
		unconstrained_cells_set.emplace(unconstrained_cells[i][0], unconstrained_cells[i][1]);
	}

	EXPECT_EQ(unconstrained_cells_set, unconstrained_cells_set_sol);
	for (auto c_iter = unconstrained_cells_set.cbegin(), c_iter_sol = unconstrained_cells_set_sol.cbegin();
			c_iter != unconstrained_cells_set.end() && c_iter_sol != unconstrained_cells_set_sol.end();
			++c_iter, ++c_iter_sol) {
		EXPECT_EQ(*c_iter, *c_iter_sol);
	}
}



/**************************************************
 * Task 5: has_satisfiable_neighbor_constraints() *
 **************************************************/
TEST(HasSatisfiableNeighborConstraints, InsufficientPossibleFlags) {
	// Grid Setup.
	reset_all();

	bool has_mine_copy[MAX_ROWS][MAX_COLS] = {
		{false, false, false, false, true },
		{false, false, true , false, false},
		{false, true , true , false, false},
		{false, false, false, false, false},
		{false, false, false, true , false}
	};
	copy_mine_layout(has_mine_sol, has_mine_copy);

	game_stats_sol[0] = game_stats_sol[1] = 5;
	game_stats_sol[2] = 5;
	game_stats_sol[3] = game_stats_sol[0] * game_stats_sol[1] - game_stats_sol[2];
	game_stats_sol[4] = 0;
	mine_exploded_sol = false;

	//copy_sol_to_current_state();

	// Partially reveal the grid, set mines to be SAFE, and compare.
	reveal_sol(0, 0);
	reveal_sol(0, 2);
	reveal_sol(2, 0);
	copy_sol_to_current_state();
	grid_sol[2][2] = grid[2][2] = SAFE;
	EXPECT_EQ(has_satisfiable_neighbor_constraints(2, 2), has_satisfiable_neighbor_constraints_sol(2, 2));
	grid_sol[2][2] = grid[2][2] = FLAGGED;
	EXPECT_EQ(has_satisfiable_neighbor_constraints(2, 2), has_satisfiable_neighbor_constraints_sol(2, 2));
	grid_sol[2][2] = grid[2][2] = HIDDEN;

	reveal_sol(2, 4);
	reveal_sol(0, 3);
	copy_sol_to_current_state();
	grid_sol[0][4] = grid[0][4] = SAFE;
	EXPECT_EQ(has_satisfiable_neighbor_constraints(0, 4), has_satisfiable_neighbor_constraints_sol(0, 4));
	grid_sol[0][4] = grid[0][4] = FLAGGED;
	EXPECT_EQ(has_satisfiable_neighbor_constraints(0, 4), has_satisfiable_neighbor_constraints_sol(0, 4));
	grid_sol[0][4] = grid[0][4] = HIDDEN;
}

TEST(HasSatisfiableNeighborConstraints, TooManyFlags) {
	// Grid Setup.
	reset_all();

	bool has_mine_copy[MAX_ROWS][MAX_COLS] = {
		{false, false, false, false, true },
		{false, false, true , false, false},
		{false, true , false, false, false},
		{false, false, false, false, false},
		{true , false, false, true , false}
	};
	copy_mine_layout(has_mine_sol, has_mine_copy);

	game_stats_sol[0] = game_stats_sol[1] = 5;
	game_stats_sol[2] = 5;
	game_stats_sol[3] = game_stats_sol[0] * game_stats_sol[1] - game_stats_sol[2];
	game_stats_sol[4] = 0;
	mine_exploded_sol = false;

	//copy_sol_to_current_state();

	// Partially reveal the grid, set safe cells to be FLAGGED, and compare.
	reveal_sol(0, 0);
	reveal_sol(0, 2);
	reveal_sol(2, 0);
	flag_sol(1, 2);
	flag_sol(2, 1);
	copy_sol_to_current_state();
	grid_sol[2][2] = grid[2][2] = FLAGGED;
	EXPECT_EQ(has_satisfiable_neighbor_constraints(2, 2), has_satisfiable_neighbor_constraints_sol(2, 2));
	grid_sol[2][2] = grid[2][2] = SAFE;
	EXPECT_EQ(has_satisfiable_neighbor_constraints(2, 2), has_satisfiable_neighbor_constraints_sol(2, 2));
	grid_sol[2][2] = grid[2][2] = HIDDEN;

	reveal_sol(2, 4);
	copy_sol_to_current_state();
	grid_sol[3][2] = grid[3][2] = FLAGGED;
	EXPECT_EQ(has_satisfiable_neighbor_constraints(3, 2), has_satisfiable_neighbor_constraints_sol(3, 2));
	grid_sol[3][2] = grid[3][2] = SAFE;
	EXPECT_EQ(has_satisfiable_neighbor_constraints(3, 2), has_satisfiable_neighbor_constraints_sol(3, 2));
	grid_sol[3][2] = grid[3][2] = HIDDEN;
}



/********************************
 * Task 6: record_possibility() *
 ********************************/
TEST(RecordPossibility, InvalidRecord) {
	// Grid Setup.
	reset_all();
	has_mine_sol[2][2] = true;
	game_stats_sol[0] = game_stats_sol[1] = 5;
	game_stats_sol[2] = 1;
	game_stats_sol[3] = game_stats_sol[0] * game_stats_sol[1] - game_stats_sol[2];
	game_stats_sol[4] = 0;
	mine_exploded_sol = false;
	copy_sol_to_current_state();

	// Setup required variables arbitrarily.
	int constrained_cells[MAX_CELLS][2] = {};
	int num_constrained_cells = 5;
	for (int i = 0; i < num_constrained_cells; i += 1) {
		constrained_cells[i][0] = constrained_cells[i][1] = i;
	}

	int num_flags_bounds_used_sol[4] = {};
	int num_flags_bounds_used[4] = {};
	num_flags_bounds_used_sol[0] = num_flags_bounds_used_sol[3] = num_flags_bounds_used[0] = num_flags_bounds_used[3] = 1;
	num_flags_bounds_used_sol[1] = num_flags_bounds_used_sol[2] = num_flags_bounds_used[1] = num_flags_bounds_used[2] = 4;

	int num_safe_config_records_sol[MAX_CELLS] = {};
	int num_flagged_config_records_sol[MAX_CELLS] = {};
	int num_safe_config_records[MAX_CELLS] = {};
	int num_flagged_config_records[MAX_CELLS] = {};

	// Test with flags above upper bound.
	for (int i = 0; i < num_constrained_cells; i += 1) {
		grid[constrained_cells[i][0]][constrained_cells[i][1]] = grid_sol[constrained_cells[i][0]][constrained_cells[i][1]] = FLAGGED;
	}
	record_possibility_sol(constrained_cells, num_constrained_cells, num_flags_bounds_used_sol, num_safe_config_records_sol, num_flagged_config_records_sol);
	record_possibility(constrained_cells, num_constrained_cells, num_flags_bounds_used, num_safe_config_records, num_flagged_config_records);

	EXPECT_EQ(num_flags_bounds_used[2], num_flags_bounds_used_sol[2]);
	EXPECT_EQ(num_flags_bounds_used[3], num_flags_bounds_used_sol[3]);
	for (int i = 0; i < num_constrained_cells; i += 1) {
		EXPECT_EQ(num_safe_config_records[i], num_safe_config_records_sol[i]);
		EXPECT_EQ(num_flagged_config_records[i], num_flagged_config_records_sol[i]);
	}

	// Test with flags below lower bound.
	for (int i = 0; i < num_constrained_cells; i += 1) {
		grid[constrained_cells[i][0]][constrained_cells[i][1]] = grid_sol[constrained_cells[i][0]][constrained_cells[i][1]] = SAFE;
	}
	record_possibility_sol(constrained_cells, num_constrained_cells, num_flags_bounds_used_sol, num_safe_config_records_sol, num_flagged_config_records_sol);
	record_possibility(constrained_cells, num_constrained_cells, num_flags_bounds_used, num_safe_config_records, num_flagged_config_records);

	EXPECT_EQ(num_flags_bounds_used[2], num_flags_bounds_used_sol[2]);
	EXPECT_EQ(num_flags_bounds_used[3], num_flags_bounds_used_sol[3]);
	for (int i = 0; i < num_constrained_cells; i += 1) {
		EXPECT_EQ(num_safe_config_records[i], num_safe_config_records_sol[i]);
		EXPECT_EQ(num_flagged_config_records[i], num_flagged_config_records_sol[i]);
	}
}

TEST(RecordPossibility, ValidRecord) {
	// Grid Setup.
	reset_all();

	bool has_mine_copy[MAX_ROWS][MAX_COLS] = {
		{false, false, false, true , false, false, true , false, false, true , false, false, false, false, false, false, true , false, false, true , false, false, false, false, false},
		{false, false, false, false, false, true , false, true , true , false, false, false, false, false, false, false, true , false, false, false, false, false, false, false, false},
		{true , false, false, false, false, false, false, false, false, false, false, false, false, true , true , false, false, false, false, true , false, false, false, false, false},
		{false, false, false, false, true , false, true , true , true , false, false, false, false, false, false, true , false, true , false, false, true , false, false, false, false},
		{false, false, false, false, false, false, false, false, false, false, false, true , false, true , false, true , false, false, false, false, true , false, false, false, true },
		{false, false, false, false, false, true , false, true , false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, false, true , false, false, false, false, true , false, false, false, true , false, false, false, false, false, false},
		{true , false, false, false, false, false, true , true , false, false, true , false, false, false, false, false, false, false, false, false, false, true , false, false, false},
		{false, true , false, false, false, false, false, false, false, false, false, false, true , false, false, false, true , false, false, false, false, false, false, true , false},
		{true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true , true , false},
		{false, false, false, false, false, false, false, false, true , false, false, false, false, false, true , false, true , false, false, false, false, false, true , true , false},
		{false, false, false, false, false, false, false, false, false, false, true , false, false, false, false, false, true , false, true , false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, true , false, false, true , false, false, false, false, true , false, false, false, true , false, false, false, false},
		{false, true , true , false, false, false, false, false, false, false, false, false, false, true , false, false, false, true , false, true , false, false, false, false, false},
		{false, false, false, false, false, false, true , false, false, false, false, false, true , true , false, false, false, false, false, true , false, false, false, false, true },
		{false, false, false, false, false, false, false, false, false, false, false, false, true , false, false, false, false, true , false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, true , false, false, false, false, false, false, true , false, true , false, true , false, false, false, false, false, true },
		{true , false, true , false, false, false, false, false, false, false, false, false, false, false, true , false, false, true , false, false, false, true , false, false, false},
		{false, true , true , true , false, false, false, false, false, true , true , false, false, true , true , false, true , false, true , false, true , true , false, false, false},
		{false, false, false, false, true , false, false, false, false, false, false, false, false, false, false, false, false, false, true , false, false, true , false, false, false},
		{false, false, true , true , false, false, true , true , false, true , false, true , false, false, false, false, false, false, false, false, false, false, false, true , false},
		{false, false, false, true , false, false, true , false, false, true , true , false, false, false, true , false, false, true , false, true , false, false, false, true , true },
		{false, false, false, false, false, true , true , true , false, false, true , false, false, false, false, false, false, true , false, false, true , false, false, false, false},
		{false, false, false, false, false, false, false, true , true , false, false, false, false, false, false, false, false, false, false, false, true , false, false, false, false},
		{true , true , false, true , false, false, true , true , false, false, true , false, false, false, false, false, false, true , false, false, true , true , false, true , false}
	};
	copy_mine_layout(has_mine_sol, has_mine_copy);

	game_stats_sol[0] = game_stats_sol[1] = 25;
	game_stats_sol[2] = 125;
	game_stats_sol[3] = game_stats_sol[0] * game_stats_sol[1] - game_stats_sol[2];
	game_stats_sol[4] = 0;
	mine_exploded_sol = false;

	//copy_sol_to_current_state();

	// Partially reveal the grid.
	reveal_sol(0, 0);
	reveal_sol(2, 2);
	//copy_sol_to_current_state();

	// Setup required variables.
	int constrained_cells_sol[MAX_CELLS][2] = {};
	int unconstrained_cells_sol[MAX_CELLS][2] = {};
	int num_cells_sol[2] = {};
	classify_hidden_cells_sol(constrained_cells_sol, unconstrained_cells_sol, num_cells_sol);

	int num_constrained_cells = num_cells_sol[0];
	int constrained_cells[MAX_CELLS][2] = {};
	for (int i = 0; i < MAX_CELLS; i += 1) {
		constrained_cells[i][0] = constrained_cells_sol[i][0];
		constrained_cells[i][1] = constrained_cells_sol[i][1];
	}

	int num_flags_bounds_used_sol[4] = {};
	int num_flags_bounds_used[4] = {};
	num_flags_bounds_used_sol[0] = num_flags_bounds_used_sol[3] = num_flags_bounds_used[0] = num_flags_bounds_used[3] = game_stats_sol[2] - num_cells_sol[1];
	num_flags_bounds_used_sol[1] = num_flags_bounds_used_sol[2] = num_flags_bounds_used[1] = num_flags_bounds_used[2] = game_stats_sol[2];

	// Potential solution.
	for (int i = 0; i < num_constrained_cells; i += 1) {
		grid_sol[constrained_cells_sol[i][0]][constrained_cells_sol[i][1]] = SAFE;
	}
	grid_sol[2][0] = FLAGGED;
	grid_sol[0][3] = FLAGGED;
	grid_sol[3][4] = FLAGGED;
	grid_sol[5][5] = FLAGGED;
	grid_sol[7][6] = FLAGGED;
	grid_sol[7][7] = FLAGGED;
	grid_sol[7][0] = FLAGGED;
	grid_sol[8][1] = FLAGGED;
	grid_sol[9][0] = FLAGGED;
	grid_sol[14][6] = FLAGGED;
	grid_sol[13][1] = FLAGGED;
	grid_sol[13][2] = FLAGGED;
	grid_sol[16][7] = FLAGGED;
	grid_sol[17][2] = FLAGGED;
	grid_sol[18][2] = FLAGGED;
	grid_sol[18][3] = FLAGGED;
	grid_sol[19][4] = FLAGGED;
	copy_sol_to_current_state();
	//display_grid_or_sol(grid_sol, game_stats_sol);

	// Compare function output with solution.
	int num_safe_config_records_sol[MAX_CELLS] = {};
	int num_flagged_config_records_sol[MAX_CELLS] = {};
	record_possibility_sol(constrained_cells_sol, num_constrained_cells, num_flags_bounds_used_sol, num_safe_config_records_sol, num_flagged_config_records_sol);

	int num_safe_config_records[MAX_CELLS] = {};
	int num_flagged_config_records[MAX_CELLS] = {};
	record_possibility(constrained_cells, num_constrained_cells, num_flags_bounds_used, num_safe_config_records, num_flagged_config_records);

	EXPECT_EQ(num_flags_bounds_used[2], num_flags_bounds_used_sol[2]);
	EXPECT_EQ(num_flags_bounds_used[3], num_flags_bounds_used_sol[3]);
	for (int i = 0; i < num_constrained_cells; i += 1) {
		EXPECT_EQ(num_safe_config_records[i], num_safe_config_records_sol[i]);
		EXPECT_EQ(num_flagged_config_records[i], num_flagged_config_records_sol[i]);
	}
}



/*************************************
 * Task 7: enumerate_possibilities() *
 *************************************/
TEST(EnumeratePossibilities, SimpleGrid) {
	// Grid Setup.
	reset_all();

	bool has_mine_copy[MAX_ROWS][MAX_COLS] = {
		{false, false, false, false, false},
		{false, false, false, false, false},
		{false, false, true , false, false},
		{false, false, false, false, false},
		{false, false, false, false, false}
	};
	copy_mine_layout(has_mine_sol, has_mine_copy);

	game_stats_sol[0] = game_stats_sol[1] = 5;
	game_stats_sol[2] = 1;
	game_stats_sol[3] = game_stats_sol[0] * game_stats_sol[1] - game_stats_sol[2];
	game_stats_sol[4] = 0;
	mine_exploded_sol = false;

	//copy_sol_to_current_state();

	// Reveal the grid, should only have on constrained cell in the center.
	reveal_sol(0, 0);
	copy_sol_to_current_state();

	// Variables Setup and function call.
	int constrained_cells[MAX_CELLS][2] = {{2, 2}};

	int num_flags_bounds_used_sol[4] = {};
	int num_flags_bounds_used[4] = {};
	num_flags_bounds_used_sol[0] = num_flags_bounds_used_sol[3] = num_flags_bounds_used[0] = num_flags_bounds_used[3] = 0;
	num_flags_bounds_used_sol[1] = num_flags_bounds_used_sol[2] = num_flags_bounds_used[1] = num_flags_bounds_used[2] = 1;

	int num_safe_config_records_sol[MAX_CELLS] = {};
	int num_flagged_config_records_sol[MAX_CELLS] = {};
	enumerate_possibilities_sol(constrained_cells, 0, 1, num_flags_bounds_used_sol, num_safe_config_records_sol, num_flagged_config_records_sol);

	int num_safe_config_records[MAX_CELLS] = {};
	int num_flagged_config_records[MAX_CELLS] = {};
	enumerate_possibilities(constrained_cells, 0, 1, num_flags_bounds_used, num_safe_config_records, num_flagged_config_records);

	// Compare with solution.
	EXPECT_EQ(num_flags_bounds_used[2], num_flags_bounds_used_sol[2]);
	EXPECT_EQ(num_flags_bounds_used[3], num_flags_bounds_used_sol[3]);
	EXPECT_EQ(num_safe_config_records[0], num_safe_config_records_sol[0]);
	EXPECT_EQ(num_flagged_config_records[0], num_flagged_config_records_sol[0]);
}

TEST(EnumeratePossibilities, ResetHidden) {
	// Grid Setup.
	reset_all();

	bool has_mine_copy[MAX_ROWS][MAX_COLS] = {
		{false, false, false, true , false, false, true , false, false, true , false, false, false, false, false, false, true , false, false, true , false, false, false, false, false},
		{false, false, false, false, false, true , false, true , true , false, false, false, false, false, false, false, true , false, false, false, false, false, false, false, false},
		{true , false, false, false, false, false, false, false, false, false, false, false, false, true , true , false, false, false, false, true , false, false, false, false, false},
		{false, false, false, false, true , false, true , true , true , false, false, false, false, false, false, true , false, true , false, false, true , false, false, false, false},
		{false, false, false, false, false, false, false, false, false, false, false, true , false, true , false, true , false, false, false, false, true , false, false, false, true },
		{false, false, false, false, false, true , false, true , false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, false, true , false, false, false, false, true , false, false, false, true , false, false, false, false, false, false},
		{true , false, false, false, false, false, true , true , false, false, true , false, false, false, false, false, false, false, false, false, false, true , false, false, false},
		{false, true , false, false, false, false, false, false, false, false, false, false, true , false, false, false, true , false, false, false, false, false, false, true , false},
		{true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true , true , false},
		{false, false, false, false, false, false, false, false, true , false, false, false, false, false, true , false, true , false, false, false, false, false, true , true , false},
		{false, false, false, false, false, false, false, false, false, false, true , false, false, false, false, false, true , false, true , false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, true , false, false, true , false, false, false, false, true , false, false, false, true , false, false, false, false},
		{false, true , true , false, false, false, false, false, false, false, false, false, false, true , false, false, false, true , false, true , false, false, false, false, false},
		{false, false, false, false, false, false, true , false, false, false, false, false, true , true , false, false, false, false, false, true , false, false, false, false, true },
		{false, false, false, false, false, false, false, false, false, false, false, false, true , false, false, false, false, true , false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, true , false, false, false, false, false, false, true , false, true , false, true , false, false, false, false, false, true },
		{true , false, true , false, false, false, false, false, false, false, false, false, false, false, true , false, false, true , false, false, false, true , false, false, false},
		{false, true , true , true , false, false, false, false, false, true , true , false, false, true , true , false, true , false, true , false, true , true , false, false, false},
		{false, false, false, false, true , false, false, false, false, false, false, false, false, false, false, false, false, false, true , false, false, true , false, false, false},
		{false, false, true , true , false, false, true , true , false, true , false, true , false, false, false, false, false, false, false, false, false, false, false, true , false},
		{false, false, false, true , false, false, true , false, false, true , true , false, false, false, true , false, false, true , false, true , false, false, false, true , true },
		{false, false, false, false, false, true , true , true , false, false, true , false, false, false, false, false, false, true , false, false, true , false, false, false, false},
		{false, false, false, false, false, false, false, true , true , false, false, false, false, false, false, false, false, false, false, false, true , false, false, false, false},
		{true , true , false, true , false, false, true , true , false, false, true , false, false, false, false, false, false, true , false, false, true , true , false, true , false}
	};
	copy_mine_layout(has_mine_sol, has_mine_copy);

	game_stats_sol[0] = game_stats_sol[1] = 25;
	game_stats_sol[2] = 125;
	game_stats_sol[3] = game_stats_sol[0] * game_stats_sol[1] - game_stats_sol[2];
	game_stats_sol[4] = 0;
	mine_exploded_sol = false;

	//copy_sol_to_current_state();

	// Partially reveal the grid.
	reveal_sol(2, 2);
	reveal_sol(0, 12);
	reveal_sol(0, 24);
	reveal_sol(12, 24);
	reveal_sol(24, 12);
	copy_sol_to_current_state();

	// Variables Setup and function call.
	int constrained_cells[MAX_CELLS][2] = {};
	int unconstrained_cells[MAX_CELLS][2] = {};
	int num_cells[2] = {};
	classify_hidden_cells_sol(constrained_cells, unconstrained_cells, num_cells);

	int num_flags_bounds_used[4] = {};
	int num_safe_config_records[MAX_CELLS] = {};
	int num_flagged_config_records[MAX_CELLS] = {};
	enumerate_possibilities(constrained_cells, 0, num_cells[0], num_flags_bounds_used, num_safe_config_records, num_flagged_config_records);

	// Verify all constrained cells reset to HIDDEN.
	for (int i = 0; i < num_cells[0]; i += 1) {
		EXPECT_EQ(grid[constrained_cells[i][0]][constrained_cells[i][1]], HIDDEN);
	}
}

TEST(EnumeratePossibilities, Optimization) {
	// Grid Setup.
	reset_all();

	bool has_mine_copy[MAX_ROWS][MAX_COLS] = {
		{false, false, false, true , false, false, true , false, false, true , false, false, false, false, false, false, true , false, false, true , false, false, false, false, false},
		{false, false, false, false, false, true , false, true , true , false, false, false, false, false, false, false, true , false, false, false, false, false, false, false, false},
		{true , false, false, false, false, false, false, false, false, false, false, false, false, true , true , false, false, false, false, true , false, false, false, false, false},
		{false, false, false, false, true , false, true , true , true , false, false, false, false, false, false, true , false, true , false, false, true , false, false, false, false},
		{false, false, false, false, false, false, false, false, false, false, false, true , false, true , false, true , false, false, false, false, true , false, false, false, true },
		{false, false, false, false, false, true , false, true , false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, false, true , false, false, false, false, true , false, false, false, true , false, false, false, false, false, false},
		{true , false, false, false, false, false, true , true , false, false, true , false, false, false, false, false, false, false, false, false, false, true , false, false, false},
		{false, true , false, false, false, false, false, false, false, false, false, false, true , false, false, false, true , false, false, false, false, false, false, true , false},
		{true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true , true , false},
		{false, false, false, false, false, false, false, false, true , false, false, false, false, false, true , false, true , false, false, false, false, false, true , true , false},
		{false, false, false, false, false, false, false, false, false, false, true , false, false, false, false, false, true , false, true , false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, true , false, false, true , false, false, false, false, true , false, false, false, true , false, false, false, false},
		{false, true , true , false, false, false, false, false, false, false, false, false, false, true , false, false, false, true , false, true , false, false, false, false, false},
		{false, false, false, false, false, false, true , false, false, false, false, false, true , true , false, false, false, false, false, true , false, false, false, false, true },
		{false, false, false, false, false, false, false, false, false, false, false, false, true , false, false, false, false, true , false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, true , false, false, false, false, false, false, true , false, true , false, true , false, false, false, false, false, true },
		{true , false, true , false, false, false, false, false, false, false, false, false, false, false, true , false, false, true , false, false, false, true , false, false, false},
		{false, true , true , true , false, false, false, false, false, true , true , false, false, true , true , false, true , false, true , false, true , true , false, false, false},
		{false, false, false, false, true , false, false, false, false, false, false, false, false, false, false, false, false, false, true , false, false, true , false, false, false},
		{false, false, true , true , false, false, true , true , false, true , false, true , false, false, false, false, false, false, false, false, false, false, false, true , false},
		{false, false, false, true , false, false, true , false, false, true , true , false, false, false, true , false, false, true , false, true , false, false, false, true , true },
		{false, false, false, false, false, true , true , true , false, false, true , false, false, false, false, false, false, true , false, false, true , false, false, false, false},
		{false, false, false, false, false, false, false, true , true , false, false, false, false, false, false, false, false, false, false, false, true , false, false, false, false},
		{true , true , false, true , false, false, true , true , false, false, true , false, false, false, false, false, false, true , false, false, true , true , false, true , false}
	};
	copy_mine_layout(has_mine_sol, has_mine_copy);

	game_stats_sol[0] = game_stats_sol[1] = 25;
	game_stats_sol[2] = 125;
	game_stats_sol[3] = game_stats_sol[0] * game_stats_sol[1] - game_stats_sol[2];
	game_stats_sol[4] = 0;
	mine_exploded_sol = false;

	//copy_sol_to_current_state();

	// Partially reveal the grid.
	reveal_sol(2, 2);
	reveal_sol(0, 12);
	reveal_sol(0, 24);
	reveal_sol(12, 24);
	reveal_sol(24, 12);
	copy_sol_to_current_state();

	// Variables Setup.
	int constrained_cells[MAX_CELLS][2] = {};
	int unconstrained_cells[MAX_CELLS][2] = {};
	int num_cells[2] = {};
	classify_hidden_cells_sol(constrained_cells, unconstrained_cells, num_cells);

	int num_flags_bounds_used_sol[4] = {};
	int num_flags_bounds_used[4] = {};
	num_flags_bounds_used_sol[0] = num_flags_bounds_used_sol[3] = num_flags_bounds_used[0] = num_flags_bounds_used[3] = game_stats_sol[2] - num_cells[1];
	num_flags_bounds_used_sol[1] = num_flags_bounds_used_sol[2] = num_flags_bounds_used[1] = num_flags_bounds_used[2] = game_stats_sol[2];

	int num_safe_config_records_sol[MAX_CELLS] = {};
	int num_flagged_config_records_sol[MAX_CELLS] = {};
	int num_safe_config_records[MAX_CELLS] = {};
	int num_flagged_config_records[MAX_CELLS] = {};

	// Function call with chrono, repeated for averaging.
	using clock = std::chrono::high_resolution_clock;
	using ms = std::chrono::duration<double, std::milli>;
	const int time_factor = 10;
	const int num_repeat = 100;

	const auto start_time_sol = clock::now();
	for (int i = 0; i < num_repeat; i += 1) {
		enumerate_possibilities_sol(constrained_cells, 0, num_cells[0], num_flags_bounds_used_sol, num_safe_config_records_sol, num_flagged_config_records_sol);
	}
	const ms runtime_sol = clock::now() - start_time_sol;
	//std::cout << "runtime_sol (ms): " << runtime_sol.count() << std::endl;

	const auto start_time = clock::now();
	for (int i = 0; i < num_repeat; i += 1) {
		enumerate_possibilities(constrained_cells, 0, num_cells[0], num_flags_bounds_used, num_safe_config_records, num_flagged_config_records);
	}
	const ms runtime = clock::now() - start_time;
	//std::cout << "runtime (ms): " << runtime.count() << std::endl;

	// Compare runtime against solution, within the specified time_factor.
	EXPECT_LE(runtime.count(), time_factor * runtime_sol.count());
}

TEST(EnumeratePossibilities, GeneralGrid) {
	// Grid Setup.
	reset_all();

	bool has_mine_copy[MAX_ROWS][MAX_COLS] = {
		{false, false, false, true , false, false, true , false, false, true , false, false, false, false, false, false, true , false, false, true , false, false, false, false, false},
		{false, false, false, false, false, true , false, true , true , false, false, false, false, false, false, false, true , false, false, false, false, false, false, false, false},
		{true , false, false, false, false, false, false, false, false, false, false, false, false, true , true , false, false, false, false, true , false, false, false, false, false},
		{false, false, false, false, true , false, true , true , true , false, false, false, false, false, false, true , false, true , false, false, true , false, false, false, false},
		{false, false, false, false, false, false, false, false, false, false, false, true , false, true , false, true , false, false, false, false, true , false, false, false, true },
		{false, false, false, false, false, true , false, true , false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, false, true , false, false, false, false, true , false, false, false, true , false, false, false, false, false, false},
		{true , false, false, false, false, false, true , true , false, false, true , false, false, false, false, false, false, false, false, false, false, true , false, false, false},
		{false, true , false, false, false, false, false, false, false, false, false, false, true , false, false, false, true , false, false, false, false, false, false, true , false},
		{true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true , true , false},
		{false, false, false, false, false, false, false, false, true , false, false, false, false, false, true , false, true , false, false, false, false, false, true , true , false},
		{false, false, false, false, false, false, false, false, false, false, true , false, false, false, false, false, true , false, true , false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, true , false, false, true , false, false, false, false, true , false, false, false, true , false, false, false, false},
		{false, true , true , false, false, false, false, false, false, false, false, false, false, true , false, false, false, true , false, true , false, false, false, false, false},
		{false, false, false, false, false, false, true , false, false, false, false, false, true , true , false, false, false, false, false, true , false, false, false, false, true },
		{false, false, false, false, false, false, false, false, false, false, false, false, true , false, false, false, false, true , false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, true , false, false, false, false, false, false, true , false, true , false, true , false, false, false, false, false, true },
		{true , false, true , false, false, false, false, false, false, false, false, false, false, false, true , false, false, true , false, false, false, true , false, false, false},
		{false, true , true , true , false, false, false, false, false, true , true , false, false, true , true , false, true , false, true , false, true , true , false, false, false},
		{false, false, false, false, true , false, false, false, false, false, false, false, false, false, false, false, false, false, true , false, false, true , false, false, false},
		{false, false, true , true , false, false, true , true , false, true , false, true , false, false, false, false, false, false, false, false, false, false, false, true , false},
		{false, false, false, true , false, false, true , false, false, true , true , false, false, false, true , false, false, true , false, true , false, false, false, true , true },
		{false, false, false, false, false, true , true , true , false, false, true , false, false, false, false, false, false, true , false, false, true , false, false, false, false},
		{false, false, false, false, false, false, false, true , true , false, false, false, false, false, false, false, false, false, false, false, true , false, false, false, false},
		{true , true , false, true , false, false, true , true , false, false, true , false, false, false, false, false, false, true , false, false, true , true , false, true , false}
	};
	copy_mine_layout(has_mine_sol, has_mine_copy);

	game_stats_sol[0] = game_stats_sol[1] = 25;
	game_stats_sol[2] = 125;
	game_stats_sol[3] = game_stats_sol[0] * game_stats_sol[1] - game_stats_sol[2];
	game_stats_sol[4] = 0;
	mine_exploded_sol = false;

	//copy_sol_to_current_state();

	// Partially reveal the grid.
	reveal_sol(2, 2);
	reveal_sol(0, 12);
	reveal_sol(0, 24);
	reveal_sol(12, 24);
	reveal_sol(24, 12);
	copy_sol_to_current_state();

	// Variables Setup and function call.
	int constrained_cells[MAX_CELLS][2] = {};
	int unconstrained_cells[MAX_CELLS][2] = {};
	int num_cells[2] = {};
	classify_hidden_cells_sol(constrained_cells, unconstrained_cells, num_cells);

	int num_flags_bounds_used_sol[4] = {};
	int num_flags_bounds_used[4] = {};
	num_flags_bounds_used_sol[0] = num_flags_bounds_used_sol[3] = num_flags_bounds_used[0] = num_flags_bounds_used[3] = game_stats_sol[2] - num_cells[1];
	num_flags_bounds_used_sol[1] = num_flags_bounds_used_sol[2] = num_flags_bounds_used[1] = num_flags_bounds_used[2] = game_stats_sol[2];

	int num_safe_config_records_sol[MAX_CELLS] = {};
	int num_flagged_config_records_sol[MAX_CELLS] = {};
	enumerate_possibilities_sol(constrained_cells, 0, num_cells[0], num_flags_bounds_used_sol, num_safe_config_records_sol, num_flagged_config_records_sol);

	int num_safe_config_records[MAX_CELLS] = {};
	int num_flagged_config_records[MAX_CELLS] = {};
	enumerate_possibilities(constrained_cells, 0, num_cells[0], num_flags_bounds_used, num_safe_config_records, num_flagged_config_records);

	// Compare with solution.
	EXPECT_EQ(num_flags_bounds_used[2], num_flags_bounds_used_sol[2]);
	EXPECT_EQ(num_flags_bounds_used[3], num_flags_bounds_used_sol[3]);

	for (int i = 0; i < num_cells[0]; i += 1) {
		EXPECT_EQ(num_safe_config_records[i], num_safe_config_records_sol[i]);
		EXPECT_EQ(num_flagged_config_records[i], num_flagged_config_records_sol[i]);
	}
}



/**************************************
 * Task 8: handle_constrained_cells() *
 **************************************/
TEST(HandleConstrainedCells, RevealAndOrFlag) {
	// Generate a random set of constrained cells with no duplicates.
	srand(static_cast<unsigned int>(time(nullptr)));
	set<pair<int, int>> constrained_cells_set;
	int constrained_cells[MAX_CELLS][2] = {};
	int num_constrained_cells = 0;

	for (int i = 0; i < MAX_CELLS; i += 1) {
		int row = rand() % MAX_ROWS;
		int col = rand() % MAX_COLS;
		auto return_value = constrained_cells_set.emplace(row, col); // STL Set automatically checks for duplicates.

		// The return_value is a pair of iterator and bool. bool is true if the insertion was successful.
		if (return_value.second) {
			constrained_cells[i][0] = row;
			constrained_cells[i][1] = col;
			num_constrained_cells += 1;
		}
	}

	// Randomly assign the records to imply safe, flag, or neither. Arbitrary number of recorded configurations.
	const int NUM_RECORDED_CONFIGS = 1024;
	int num_safe_config_records[MAX_CELLS] = {};
	int num_flagged_config_records[MAX_CELLS] = {};
	for (int i = 0; i < num_constrained_cells; i += 1) {
		int flag_safe_neither = rand() % 3;
		switch (flag_safe_neither) {
		case 0: // Safe.
			num_safe_config_records[i] = NUM_RECORDED_CONFIGS;
			num_flagged_config_records[i] = 0;
			break;

		case 1: // Flagged.
			num_safe_config_records[i] = 0;
			num_flagged_config_records[i] = NUM_RECORDED_CONFIGS;
			break;

		case 2: // Neither. Case 2 and default are the same.
		default:
			num_safe_config_records[i] = NUM_RECORDED_CONFIGS/2;
			num_flagged_config_records[i] = NUM_RECORDED_CONFIGS - num_safe_config_records[i];
			break;
		}
	}

	// Generate test and solution output.
	int cells_to_reveal_sol[MAX_CELLS][2] = {};
	int cells_to_flag_sol[MAX_CELLS][2] = {};
	int num_cells_sol[2] = {};
	handle_constrained_cells_sol(constrained_cells, num_constrained_cells, num_safe_config_records, num_flagged_config_records, cells_to_reveal_sol, cells_to_flag_sol, num_cells_sol);

	int cells_to_reveal[MAX_CELLS][2] = {};
	int cells_to_flag[MAX_CELLS][2] = {};
	int num_cells[2] = {};
	handle_constrained_cells(constrained_cells, num_constrained_cells, num_safe_config_records, num_flagged_config_records, cells_to_reveal, cells_to_flag, num_cells);

	EXPECT_EQ(num_cells[0], num_cells_sol[0]);
	EXPECT_EQ(num_cells[1], num_cells_sol[1]);

	// Compare cells to reveal.
	set<pair<int, int>> cells_to_reveal_set_sol;
	for (int i = 0; i < num_cells_sol[0]; i += 1) {
		cells_to_reveal_set_sol.emplace(cells_to_reveal_sol[i][0], cells_to_reveal_sol[i][1]);
	}

	set<pair<int, int>> cells_to_reveal_set;
	for (int i = 0; i < num_cells_sol[0]; i += 1) {
		cells_to_reveal_set.emplace(cells_to_reveal[i][0], cells_to_reveal[i][1]);
	}

	EXPECT_EQ(cells_to_reveal_set, cells_to_reveal_set_sol);
	for (auto c_iter = cells_to_reveal_set.cbegin(), c_iter_sol = cells_to_reveal_set_sol.cbegin();
			c_iter != cells_to_reveal_set.end() && c_iter_sol != cells_to_reveal_set_sol.end();
			++c_iter, ++c_iter_sol) {
		EXPECT_EQ(*c_iter, *c_iter_sol);
	}

	// Compare cells to flag.
	set<pair<int, int>> cells_to_flag_set_sol;
	for (int i = 0; i < num_cells_sol[1]; i += 1) {
		cells_to_flag_set_sol.emplace(cells_to_flag_sol[i][0], cells_to_flag_sol[i][1]);
	}

	set<pair<int, int>> cells_to_flag_set;
	for (int i = 0; i < num_cells_sol[1]; i += 1) {
		cells_to_flag_set.emplace(cells_to_flag[i][0], cells_to_flag[i][1]);
	}

	EXPECT_EQ(cells_to_flag_set, cells_to_flag_set_sol);
	for (auto c_iter = cells_to_flag_set.cbegin(), c_iter_sol = cells_to_flag_set_sol.cbegin();
			c_iter != cells_to_flag_set.end() && c_iter_sol != cells_to_flag_set_sol.end();
			++c_iter, ++c_iter_sol) {
		EXPECT_EQ(*c_iter, *c_iter_sol);
	}
}



/****************************************
 * Task 9: handle_unconstrained_cells() *
 ****************************************/
TEST(HandleUnconstrainedCells, RevealAndOrFlag) {
	// Generate a random set of unconstrained cells with no duplicates.
	srand(static_cast<unsigned int>(time(nullptr)));
	set<pair<int, int>> unconstrained_cells_set;
	int unconstrained_cells[MAX_CELLS][2] = {};
	int num_unconstrained_cells = 0;

	for (int i = 0; i < MAX_CELLS; i += 1) {
		int row = rand() % MAX_ROWS;
		int col = rand() % MAX_COLS;
		auto return_value = unconstrained_cells_set.emplace(row, col); // STL Set automatically checks for duplicates.

		// The return_value is a pair of iterator and bool. bool is true if the insertion was successful.
		if (return_value.second) {
			unconstrained_cells[i][0] = row;
			unconstrained_cells[i][1] = col;
			num_unconstrained_cells += 1;
		}
	}

	// Repeat tests for reveal all, flag all, or neither.
	int num_flags_bounds_used[4] = {};
	num_flags_bounds_used[0] = 0;
	num_flags_bounds_used[1] = num_unconstrained_cells;

	for (int x = 0; x < 3; x += 1) {
		switch (x) {
		case 0: // Reveal all.
			num_flags_bounds_used[2] = num_flags_bounds_used[3] = num_flags_bounds_used[1];
			break;

		case 1: // Flag all.
			num_flags_bounds_used[2] = num_flags_bounds_used[3] = num_flags_bounds_used[0];
			break;

		case 2: // Neither. Purposefully same as default.
		default:
			num_flags_bounds_used[2] = num_flags_bounds_used[1]/4;
			num_flags_bounds_used[3] = num_flags_bounds_used[1]/2;
			break;
		}

		// Generate test and solution output.
		int cells_to_reveal_sol[MAX_CELLS][2] = {};
		int cells_to_flag_sol[MAX_CELLS][2] = {};
		int num_cells_sol[2] = {};
		handle_unconstrained_cells_sol(unconstrained_cells, num_unconstrained_cells, num_flags_bounds_used, cells_to_reveal_sol, cells_to_flag_sol, num_cells_sol);

		int cells_to_reveal[MAX_CELLS][2] = {};
		int cells_to_flag[MAX_CELLS][2] = {};
		int num_cells[2] = {};
		handle_unconstrained_cells(unconstrained_cells, num_unconstrained_cells, num_flags_bounds_used, cells_to_reveal, cells_to_flag, num_cells);

		EXPECT_EQ(num_cells[0], num_cells_sol[0]);
		EXPECT_EQ(num_cells[1], num_cells_sol[1]);

		// Compare cells to reveal.
		set<pair<int, int>> cells_to_reveal_set_sol;
		for (int i = 0; i < num_cells_sol[0]; i += 1) {
			cells_to_reveal_set_sol.emplace(cells_to_reveal_sol[i][0], cells_to_reveal_sol[i][1]);
		}

		set<pair<int, int>> cells_to_reveal_set;
		for (int i = 0; i < num_cells_sol[0]; i += 1) {
			cells_to_reveal_set.emplace(cells_to_reveal[i][0], cells_to_reveal[i][1]);
		}

		EXPECT_EQ(cells_to_reveal_set, cells_to_reveal_set_sol);
		for (auto c_iter = cells_to_reveal_set.cbegin(), c_iter_sol = cells_to_reveal_set_sol.cbegin();
				c_iter != cells_to_reveal_set.end() && c_iter_sol != cells_to_reveal_set_sol.end();
				++c_iter, ++c_iter_sol) {
			EXPECT_EQ(*c_iter, *c_iter_sol);
		}

		// Compare cells to flag.
		set<pair<int, int>> cells_to_flag_set_sol;
		for (int i = 0; i < num_cells_sol[1]; i += 1) {
			cells_to_flag_set_sol.emplace(cells_to_flag_sol[i][0], cells_to_flag_sol[i][1]);
		}

		set<pair<int, int>> cells_to_flag_set;
		for (int i = 0; i < num_cells_sol[1]; i += 1) {
			cells_to_flag_set.emplace(cells_to_flag[i][0], cells_to_flag[i][1]);
		}

		EXPECT_EQ(cells_to_flag_set, cells_to_flag_set_sol);
		for (auto c_iter = cells_to_flag_set.cbegin(), c_iter_sol = cells_to_flag_set_sol.cbegin();
				c_iter != cells_to_flag_set.end() && c_iter_sol != cells_to_flag_set_sol.end();
				++c_iter, ++c_iter_sol) {
			EXPECT_EQ(*c_iter, *c_iter_sol);
		}
	}
}



/****************************
 * Task 10: global_solver() *
 ****************************/
TEST(GlobalSolver, GeneralGrid) {
	// Grid Setup.
	reset_all();

	bool has_mine_copy[MAX_ROWS][MAX_COLS] = {
		{false, false, false, true , false, false, true , false, false, true , false, false, false, false, false, false, true , false, false, true , false, false, false, false, false},
		{false, false, false, false, false, true , false, true , true , false, false, false, false, false, false, false, true , false, false, false, false, false, false, false, false},
		{true , false, false, false, false, false, false, false, false, false, false, false, false, true , true , false, false, false, false, true , false, false, false, false, false},
		{false, false, false, false, true , false, true , true , true , false, false, false, false, false, false, true , false, true , false, false, true , false, false, false, false},
		{false, false, false, false, false, false, false, false, false, false, false, true , false, true , false, true , false, false, false, false, true , false, false, false, true },
		{false, false, false, false, false, true , false, true , false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, false, true , false, false, false, false, true , false, false, false, true , false, false, false, false, false, false},
		{true , false, false, false, false, false, true , true , false, false, true , false, false, false, false, false, false, false, false, false, false, true , false, false, false},
		{false, true , false, false, false, false, false, false, false, false, false, false, true , false, false, false, true , false, false, false, false, false, false, true , false},
		{true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true , true , false},
		{false, false, false, false, false, false, false, false, true , false, false, false, false, false, true , false, true , false, false, false, false, false, true , true , false},
		{false, false, false, false, false, false, false, false, false, false, true , false, false, false, false, false, true , false, true , false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, true , false, false, true , false, false, false, false, true , false, false, false, true , false, false, false, false},
		{false, true , true , false, false, false, false, false, false, false, false, false, false, true , false, false, false, true , false, true , false, false, false, false, false},
		{false, false, false, false, false, false, true , false, false, false, false, false, true , true , false, false, false, false, false, true , false, false, false, false, true },
		{false, false, false, false, false, false, false, false, false, false, false, false, true , false, false, false, false, true , false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, true , false, false, false, false, false, false, true , false, true , false, true , false, false, false, false, false, true },
		{true , false, true , false, false, false, false, false, false, false, false, false, false, false, true , false, false, true , false, false, false, true , false, false, false},
		{false, true , true , true , false, false, false, false, false, true , true , false, false, true , true , false, true , false, true , false, true , true , false, false, false},
		{false, false, false, false, true , false, false, false, false, false, false, false, false, false, false, false, false, false, true , false, false, true , false, false, false},
		{false, false, true , true , false, false, true , true , false, true , false, true , false, false, false, false, false, false, false, false, false, false, false, true , false},
		{false, false, false, true , false, false, true , false, false, true , true , false, false, false, true , false, false, true , false, true , false, false, false, true , true },
		{false, false, false, false, false, true , true , true , false, false, true , false, false, false, false, false, false, true , false, false, true , false, false, false, false},
		{false, false, false, false, false, false, false, true , true , false, false, false, false, false, false, false, false, false, false, false, true , false, false, false, false},
		{true , true , false, true , false, false, true , true , false, false, true , false, false, false, false, false, false, true , false, false, true , true , false, true , false}
	};
	copy_mine_layout(has_mine_sol, has_mine_copy);

	game_stats_sol[0] = game_stats_sol[1] = 25;
	game_stats_sol[2] = 125;
	game_stats_sol[3] = game_stats_sol[0] * game_stats_sol[1] - game_stats_sol[2];
	game_stats_sol[4] = 0;
	mine_exploded_sol = false;

	//copy_sol_to_current_state();

	// Reveal part of the grid and run global_solver().
	//reveal(0, 0);
	reveal_sol(0, 0);
	copy_sol_to_current_state();

	int cells_to_reveal_sol[MAX_CELLS][2] = {};
	int cells_to_flag_sol[MAX_CELLS][2] = {};
	int num_cells_sol[2] = {};

	int cells_to_reveal[MAX_CELLS][2] = {};
	int cells_to_flag[MAX_CELLS][2] = {};
	int num_cells[2] = {};

	bool global_solver_return_sol = true;
	while (global_solver_return_sol) {
		global_solver_return_sol = global_solver_sol(cells_to_reveal_sol, cells_to_flag_sol, num_cells_sol);
		bool global_solver_return = global_solver(cells_to_reveal, cells_to_flag, num_cells);

		// Compare return value and num cells.
		EXPECT_EQ(global_solver_return, global_solver_return_sol);
		EXPECT_EQ(num_cells[0], num_cells_sol[0]);
		EXPECT_EQ(num_cells[1], num_cells_sol[1]);

		// Compare cells to reveal.
		set<pair<int, int>> cells_to_reveal_set_sol;
		for (int i = 0; i < num_cells_sol[0]; i += 1) {
			cells_to_reveal_set_sol.emplace(cells_to_reveal_sol[i][0], cells_to_reveal_sol[i][1]);
		}

		set<pair<int, int>> cells_to_reveal_set;
		for (int i = 0; i < num_cells_sol[0]; i += 1) {
			cells_to_reveal_set.emplace(cells_to_reveal[i][0], cells_to_reveal[i][1]);
		}

		EXPECT_EQ(cells_to_reveal_set, cells_to_reveal_set_sol);
		for (auto c_iter = cells_to_reveal_set.cbegin(), c_iter_sol = cells_to_reveal_set_sol.cbegin();
				c_iter != cells_to_reveal_set.end() && c_iter_sol != cells_to_reveal_set_sol.end();
				++c_iter, ++c_iter_sol) {
			EXPECT_EQ(*c_iter, *c_iter_sol);
		}

		// Compare cells to flag.
		set<pair<int, int>> cells_to_flag_set_sol;
		for (int i = 0; i < num_cells_sol[1]; i += 1) {
			cells_to_flag_set_sol.emplace(cells_to_flag_sol[i][0], cells_to_flag_sol[i][1]);
		}

		set<pair<int, int>> cells_to_flag_set;
		for (int i = 0; i < num_cells_sol[1]; i += 1) {
			cells_to_flag_set.emplace(cells_to_flag[i][0], cells_to_flag[i][1]);
		}

		EXPECT_EQ(cells_to_flag_set, cells_to_flag_set_sol);
		for (auto c_iter = cells_to_flag_set.cbegin(), c_iter_sol = cells_to_flag_set_sol.cbegin();
				c_iter != cells_to_flag_set.end() && c_iter_sol != cells_to_flag_set_sol.end();
				++c_iter, ++c_iter_sol) {
			EXPECT_EQ(*c_iter, *c_iter_sol);
		}

		// Reveal and Flag each iteration.
		for (int i = 0; i < num_cells_sol[0]; i += 1) {
			//reveal(cells_to_reveal[i][0], cells_to_reveal[i][1]);
			reveal_sol(cells_to_reveal_sol[i][0], cells_to_reveal_sol[i][1]);
		}
		for (int i = 0; i < num_cells_sol[1]; i += 1) {
			//flag(cells_to_flag[i][0], cells_to_flag[i][1]);
			flag_sol(cells_to_flag_sol[i][0], cells_to_flag_sol[i][1]);
		}
		copy_sol_to_current_state();

		// Uncomment to display grid and sol at each iteration.
//		cout << '\n';
//		cout << "Actual Grid: ";
//		display_grid_or_sol(grid, game_stats);
//		cout << "Grid Solution: ";
//		display_grid_or_sol(grid_sol, game_stats_sol);
//		cout << '\n';
	}
}
