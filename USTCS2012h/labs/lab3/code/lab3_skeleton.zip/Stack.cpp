#include "Stack.h"

void reallocate_stack_array(Stack &stack, unsigned int stack_capacity)
{
    // TODO
}

void stack_push(Stack &stack, Document *document)
{
    // TODO
}

void stack_pop(Stack &stack)
{
    // TODO
}

const Document *stack_peek(const Stack &stack)
{
    return nullptr; // TODO
}

bool stack_is_empty(const Stack &stack)
{
    return false; // TODO
}

void destroy_stack(Stack &stack)
{
    // TODO
}
