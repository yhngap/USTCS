#include "Document.h"

// Task 1 - Passing arguments by reference and as pointers
void initialize_document_by_reference(Document &document, string name, string description, int num_pages)
{
    // TODO
}
void initialize_document_by_pointer(Document *document, string name, string description, int num_pages)
{
    // TODO
}
void swap_documents_by_reference(Document &document1, Document &document2)
{
    // TODO
}
void swap_documents_by_pointer(Document *document1, Document *document2)
{
    // TODO
}

// Task 2 - Dynamically create Document objects using operator new
Document *create_document(string name, string description, int num_pages)
{
    return nullptr; // TODO
}
void destroy_document(Document *document)
{
    // TODO
}
