#ifndef NODE_H_
#define NODE_H_

template<typename T>
class Node {
public:
	T content;
	Node *next { nullptr };
	Node *prev { nullptr };
	Node() = default;
	Node(T _content) :
			content(_content) {
	}
};

#endif /* NODE_H_ */
