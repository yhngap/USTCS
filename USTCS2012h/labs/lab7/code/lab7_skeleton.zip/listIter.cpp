#include "listIter.h"

template<typename T>
bool listIter<T>::operator==(const listIter<T> &rhs) {
	return ptr == rhs.ptr;
}

template<typename T>
bool listIter<T>::operator!=(const listIter<T> &rhs) {
	return ptr != rhs.ptr;
}

template<typename T>
T& listIter<T>::operator *() {
	return ptr->content;
}

//Task 2: Iterator for myList
template<typename T>
listIter<T>& listIter<T>::operator++() {
	// TODO
}

template<typename T>
listIter<T>& listIter<T>::operator--() {
	// TODO
}

template<typename T>
listIter<T> listIter<T>::operator++(int) {
	// TODO
}

template<typename T>
listIter<T> listIter<T>::operator--(int) {
	// TODO
}
