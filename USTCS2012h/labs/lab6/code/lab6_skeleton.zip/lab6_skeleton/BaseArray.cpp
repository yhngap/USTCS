#include <iostream>
using std::cout;
using std::endl;

#include "BaseArray.h"

// TODO: Use Initializer Lists if appropriate.
BaseArray::BaseArray() {}
BaseArray::BaseArray(const BaseArray& rhs) {}
BaseArray::~BaseArray() {}

BaseArray& BaseArray::operator=(const BaseArray& rhs) {
	return *this; // TODO
}

const int& BaseArray::operator[](int index) const { return internal_array[index]; }
int& BaseArray::operator[](int index) { return internal_array[index]; }

int BaseArray::get_capacity() const {
	return -1; // TODO
}

void BaseArray::reallocate_capacity(int new_capacity) {
	// TODO
}

void BaseArray::print() const {
	if (size == 0) {
		cout << "Empty." << endl;
		return;
	}

	for (int i = 0; i < size; i += 1) {
		cout << internal_array[(head_index + i) % capacity] << ' ';
	}
	cout << endl;
}
