#include "Stack.h"

// TODO: Use Initializer Lists if appropriate.
Stack::Stack() {}
Stack::Stack(const Stack& rhs){}
Stack::~Stack() {}

Stack& Stack::operator=(const Stack& rhs) {
	return *this; // TODO
}

int Stack::get_size() const {
	return -1; // TODO
}

bool Stack::is_empty() const {
	return false; // TODO
}

const int& Stack::peek() const {
	return -1; // TODO
}

void Stack::push(int data) {
	// TODO
}

void Stack::pop() {
	// TODO
}

void Stack::print() const { BaseArray::print(); }
