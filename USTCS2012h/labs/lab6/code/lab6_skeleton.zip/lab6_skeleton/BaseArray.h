#ifndef BASEARRAY_H_
#define BASEARRAY_H_

class BaseArray {
protected:
	BaseArray();
	BaseArray(const BaseArray& rhs);
	~BaseArray();

	BaseArray& operator=(const BaseArray& rhs);
	const int& operator[](int index) const;
	int& operator[](int index);

	int get_capacity() const;
	void reallocate_capacity(int new_capacity);
	void print() const;

	int size;
	int head_index;

private:
	static const int INITIAL_CAPACITY = 8;
	int capacity;
	int* internal_array;
};

#endif /* BASEARRAY_H_ */
