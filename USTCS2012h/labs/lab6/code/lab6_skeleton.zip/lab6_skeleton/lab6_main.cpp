#include <iostream>
using std::cin;
using std::cout;
using std::endl;
using std::boolalpha;
using std::noboolalpha;

#include "Queue.h"
#include "Stack.h"

// Revealed Tests.
void reallocate_capacity_test() {
	Stack stack_test;
	Queue queue_test;

	cout << "Insertion Stress Test:" << endl;
	for (int i = 0; i < 256; i += 1) {
		stack_test.push(i);
		queue_test.enqueue(i);
	}
	cout << "stack_test: ";
	stack_test.print();
	cout << "queue_test: ";
	queue_test.print();
	cout << endl;

	cout << "Removal Stress Test:" << endl;
	while (stack_test.get_size() > 1) { stack_test.pop(); }
	while (queue_test.get_size() > 1) { queue_test.dequeue(); }
	cout << "stack_test: ";
	stack_test.print();
	cout << "queue_test: ";
	queue_test.print();
	cout << endl;
}

void ctor_test() {
	Stack stack1;
	Queue queue1;
	for (int i = 0; i < 8; i += 1) {
		stack1.push(i);
		queue1.enqueue(i);
	}

	cout << "Copy-Constructor Test:" << endl;
	Stack stack2(stack1);
	Queue queue2(queue1);
	cout << "stack1: ";
	stack1.print();
	cout << "stack2: ";
	stack2.print();
	cout << "queue1: ";
	queue1.print();
	cout << "queue2: ";
	queue2.print();
	cout << endl;

	cout << "Modification:" << endl;
	for (int i = 0; i < 4; i += 1) {
		stack2.pop();
		queue2.dequeue();
	}
	for (int i = 0; i < 4; i += 1) {
		stack2.push(i * 10);
		queue2.enqueue(i * 10);
	}
	cout << "stack2: ";
	stack2.print();
	cout << "queue2: ";
	queue2.print();
	cout << endl;

	cout << "Copy-Assignment Operator Test:" << endl;
	stack2 = stack1;
	queue2 = queue1;
	cout << "stack1: ";
	stack1.print();
	cout << "stack2: ";
	stack2.print();
	cout << "queue1: ";
	queue1.print();
	cout << "queue2: ";
	queue2.print();
	cout << endl;
}



// Helper main loops.
void queue_main(Queue& queue_test) {
	char user_input;
	int data_input;
	do {
		cout << "1. Queue print" << '\n';
		cout << "2. Queue size" << '\n';
		cout << "3. Queue empty" << '\n';
		cout << "4. Queue peek" << '\n';
		cout << "5. Queue enqueue" << '\n';
		cout << "6. Queue dequeue" << '\n';
		cout << "B. Back" << endl;
		cin >> user_input;

		switch (user_input) {
		case '1':
			queue_test.print();
			break;

		case '2':
			cout << queue_test.get_size() << endl;
			break;

		case '3':
			cout << queue_test.is_empty() << endl;
			break;

		case '4':
			if (queue_test.is_empty()) {
				cout << "Empty peek." << endl;
			} else {
				cout << queue_test.peek() << endl;
			}
			break;

		case '5':
			cout << "Input data: ";
			cin >> data_input;
			queue_test.enqueue(data_input);
			break;

		case '6':
			queue_test.dequeue();
			cout << "Queue dequeue executed." << endl;
			break;

		default:
			break;
		}
		cout << endl;
	} while ((user_input != 'B') && (user_input != 'b'));
}

void stack_main(Stack& stack_test) {
	char user_input;
	int data_input;
	do {
		cout << "1. Stack print" << '\n';
		cout << "2. Stack size" << '\n';
		cout << "3. Stack empty" << '\n';
		cout << "4. Stack peek" << '\n';
		cout << "5. Stack push" << '\n';
		cout << "6. Stack pop" << '\n';
		cout << "B. Back" << endl;
		cin >> user_input;

		switch (user_input) {
		case '1':
			stack_test.print();
			break;

		case '2':
			cout << stack_test.get_size() << endl;
			break;

		case '3':
			cout << stack_test.is_empty() << endl;
			break;

		case '4':
			if (stack_test.is_empty()) {
				cout << "Empty peek." << endl;
			} else {
				cout << stack_test.peek() << endl;
			}
			break;

		case '5':
			cout << "Input data: ";
			cin >> data_input;
			stack_test.push(data_input);
			break;

		case '6':
			stack_test.pop();
			cout << "Stack pop executed." << endl;
			break;

		default:
			break;
		}
		cout << endl;
	} while ((user_input != 'B') && (user_input != 'b'));
}



int main() {
	cout << boolalpha;

	cout << "One Stack object and one Queue object have been prepared for you to test." << endl;
	cout << endl;

	Stack stack_test;
	Queue queue_test;

	char user_input;
	do {
		cout << "1. Stack" << '\n';
		cout << "2. Queue" << '\n';
		cout << "3. Copy Constructor and Copy-Assignment Operator test" << '\n';
		cout << "4. Reallocate Capacity test" << '\n';
		cout << "Q. Quit" << endl;
		cin >> user_input;
		cout << endl;

		switch (user_input) {
		case '1':
			stack_main(stack_test);
			break;

		case '2':
			queue_main(queue_test);
			break;

		case '3':
			ctor_test();
			break;

		case '4':
			reallocate_capacity_test();
			break;

		default:
			break;
		}
	} while ((user_input != 'Q') && (user_input != 'q'));

	cout << noboolalpha;

	return 0;
}
