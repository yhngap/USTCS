#include "Node.h"
Node* create_node(int data) { /* TODO */ return nullptr; }
Node* create_node(int data, Node* prev, Node* next) { /* TODO */ return nullptr; }
void destroy_node(Node* node) { /* TODO */ }
