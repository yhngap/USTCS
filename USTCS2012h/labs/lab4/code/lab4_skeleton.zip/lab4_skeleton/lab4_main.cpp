#include <iostream>
using std::cout;
using std::endl;
using std::boolalpha;
using std::noboolalpha;

#include "Deque.h"

// Helper stdio Functions.
void print_node(const Node* node) {
	if (node == nullptr) {
		cout << "nullptr" << endl;
	} else {
		cout << node->data << endl;
	}
}

void print_doubly_linked_list(const Node* node) {
	if (node == nullptr) {
		cout << "nullptr" << endl;
		return;
	}

	for (; node != nullptr; node = node->next) {
		cout << node->data << ' ';
	}
	cout << endl;
}

void print_deque(const Deque& deque) {
	if (is_empty(deque)) {
		cout << "<empty>" << endl;
		return;
	}

	print_doubly_linked_list(peek_front(deque));
}

// Tests.
void task1_tests() {
	cout << "Task 1 tests:" << endl;

	Node* node1 = new Node{37};
	print_doubly_linked_list(node1);

	Node* node2 = new Node{42, nullptr, node1};
	node1->prev = node2;
	print_doubly_linked_list(node2);

	Node* node3 = new Node{47, node1, nullptr};
	node1->next = node3;
	print_doubly_linked_list(node2);

	Node* node4 = new Node{52, node2, node1};
	node2->next = node4;
	node1->prev = node4;
	print_doubly_linked_list(node2);

	destroy_node(node3);
	node3 = nullptr;
	node1->next = nullptr;
	print_doubly_linked_list(node2);

	cout << endl;

	Deque deque = create_deque();
	print_doubly_linked_list(deque.front);
	print_doubly_linked_list(deque.back);
	deque.front = node2;
	deque.back = node1;
	print_doubly_linked_list(deque.front);

	destroy_deque(deque);
	print_doubly_linked_list(deque.front);
	print_doubly_linked_list(deque.back);

	cout << "Task 1 tests complete.\n\n\n" << endl;
}

void task2_tests() {
	cout << "Task 2 tests:" << endl;
	cout << boolalpha;

	Deque deque = create_deque();
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	push_front(deque, 13);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	push_back(deque, 15);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	push_front(deque, 27);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	push_back(deque, 29);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	pop_front(deque);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	pop_front(deque);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	pop_back(deque);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	pop_back(deque);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	push_front(deque, 100);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	push_front(deque, 200);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	push_back(deque, 300);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	push_front(deque, 400);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	push_back(deque, 500);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	push_back(deque, 600);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	push_front(deque, 700);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	push_back(deque, 800);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	push_back(deque, 900);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	push_front(deque, 1000);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	pop_front(deque);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	pop_front(deque);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	pop_back(deque);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	pop_front(deque);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	pop_back(deque);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	pop_back(deque);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	pop_front(deque);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	pop_back(deque);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	pop_back(deque);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	pop_front(deque);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	pop_front(deque);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;

	pop_back(deque);
	print_node(peek_front(deque));
	print_node(peek_back(deque));
	print_deque(deque);
	cout << is_empty(deque) << '\n' << endl;
	destroy_deque(deque);

	cout << noboolalpha;
	cout << "Task 2 tests complete.\n\n\n" << endl;
}

void task3_tests() {
	cout << "Task 3 tests:" << endl;

	Deque deque = create_deque();

	push_front(deque, 100);
	push_front(deque, 200);
	push_back(deque, 300);
	push_front(deque, 400);
	push_back(deque, 500);
	push_back(deque, 600);
	push_front(deque, 700);
	push_back(deque, 800);
	push_back(deque, 900);
	push_front(deque, 1000);

	print_node(peek(deque, -2012));
	print_node(peek(deque, -1));
	print_node(peek(deque, 0));
	print_node(peek(deque, 1));
	print_node(peek(deque, 2));
	print_node(peek(deque, 3));
	print_node(peek(deque, 4));
	print_node(peek(deque, 5));
	print_node(peek(deque, 6));
	print_node(peek(deque, 7));
	print_node(peek(deque, 8));
	print_node(peek(deque, 9));
	print_node(peek(deque, 10));
	print_node(peek(deque, 2012));

	cout << endl;

	insert(deque, -2012, 1024);
	print_deque(deque);
	insert(deque, -1, 1024);
	print_deque(deque);
	insert(deque, 0, 1024);
	print_deque(deque);
	insert(deque, 5, 1024);
	print_deque(deque);
	insert(deque, 12, 1024);
	print_deque(deque);
	insert(deque, 14, 1024);
	print_deque(deque);
	insert(deque, 2012, 1024);
	print_deque(deque);

	cout << endl;

	remove(deque, -2012);
	print_deque(deque);
	remove(deque, -1);
	print_deque(deque);
	remove(deque, 0);
	print_deque(deque);
	remove(deque, 5);
	print_deque(deque);
	remove(deque, 10);
	print_deque(deque);
	remove(deque, 10);
	print_deque(deque);
	remove(deque, 16);
	print_deque(deque);

	destroy_deque(deque);

	cout << endl;
	cout << "Task 3 tests complete.\n\n\n" << endl;
}

int main() {
	task1_tests();
	task2_tests();
	task3_tests();
	return 0;
}
