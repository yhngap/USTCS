#ifndef NODE_H_
#define NODE_H_

struct Node {
    int data;
    Node* prev;
    Node* next;
};

Node* create_node(int data);
Node* create_node(int data, Node* prev, Node* next);
void destroy_node(Node* node);

#endif /* NODE_H_ */
