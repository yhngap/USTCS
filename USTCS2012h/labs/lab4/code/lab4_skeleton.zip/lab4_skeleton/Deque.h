#ifndef DEQUE_H_
#define DEQUE_H_

#include "Node.h"

struct Deque {
	Node* front;
	Node* back;
};

Deque create_deque();
void destroy_deque(Deque& deque);

void push_front(Deque& deque, int data);
void push_back(Deque& deque, int data);
void pop_front(Deque& deque);
void pop_back(Deque& deque);
const Node* peek_front(const Deque& deque);
const Node* peek_back(const Deque& deque);
bool is_empty(const Deque& deque);

const Node* peek(const Deque& deque, int index);
void insert(Deque& deque, int index, int data);
void remove(Deque& deque, int index);

#endif /* DEQUE_H_ */
