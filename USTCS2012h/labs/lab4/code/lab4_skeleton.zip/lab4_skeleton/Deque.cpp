#include "Deque.h"

Deque create_deque() {
	// TODO
	return Deque{};
}

void destroy_deque(Deque& deque) {
	// TODO
}

void push_front(Deque& deque, int data) {
	// TODO
}

void push_back(Deque& deque, int data) {
	// TODO
}

void pop_front(Deque& deque) {
	// TODO
}

void pop_back(Deque& deque) {
	// TODO
}

const Node* peek_front(const Deque& deque) {
	// TODO
	return nullptr;
}
const Node* peek_back(const Deque& deque) {
	// TODO
	return nullptr;
}

bool is_empty(const Deque& deque) {
	// TODO
	return false;
}

const Node* peek(const Deque& deque, int index) {
	// TODO
	return nullptr;
}

void insert(Deque& deque, int index, int data) {
	// TODO
}

void remove(Deque& deque, int index) {
	// TODO
}
