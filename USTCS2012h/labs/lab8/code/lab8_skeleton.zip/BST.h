#ifndef BST_H_
#define BST_H_

#include <iostream>
#include <queue>
template<typename T>
class BST {
private:
	struct BSTnode {
		T data;
		BSTnode *ls;
		BSTnode *rs;
		BSTnode(T a) :
				data(a), ls(nullptr), rs(nullptr) {
		}
		~BSTnode() {
			delete ls;
			delete rs;
		}
	};
	BSTnode *root = nullptr;
	bool contains(const BSTnode * const & p, const T &x) const;
	bool check_BST(BSTnode *&p, T min, T max);
	void print_node(BSTnode *&p);

	void insert(BSTnode *&p, const T &x);
	void remove(BSTnode *&p, const T &x);

	void in_order_traversal(BSTnode *&p);
	void pre_order_traversal(BSTnode *&p);
	void post_order_traversal(BSTnode *&p);
	
public:
	BST() = default;
	~BST() {
		delete root;
	}
	bool is_empty() const {
		return root == nullptr;
	}
	bool contains(const T &x) const;
	bool check_BST();

	void insert(const T &x);
	void remove(const T &x);

	void in_order_traversal();
	void pre_order_traversal();
	void post_order_traversal();
};

#endif /* BST_H_ */
