#include "BST.h"

template<typename T>
void BST<T>::print_node(BSTnode *&p) {
	std::cout << (p->data) << std::endl;
}

template<typename T>
bool BST<T>::check_BST(BSTnode *&p, T min, T max) {
	if (p == nullptr)
		return true;
	if (p->data < min || p->data > max)
		return false;
	return check_BST(p->ls, min, p->data) && check_BST(p->rs, p->data, max);
}

template<typename T>
bool BST<T>::check_BST() {
	T min { -1 };
	T max { 1 };
	return check_BST(root, min, max);
}

template<typename T>
bool BST<T>::contains(const BSTnode * const &p, const T &x) const {
	if (p == nullptr)
		return false;
	if (!(p->data < x) && !(p->data > x))
		return true;
	if (x < p->data)
		return contains(p->ls, x);
	else
		return contains(p->rs, x);
}

template<typename T>
bool BST<T>::contains(const T &x) const {
	return contains(root, x);
}

//Task 1 & 2: BST insertion and deletion
template<typename T>
void BST<T>::insert(BSTnode *&p, const T &x) {
	// TODO
}

template<typename T>
void BST<T>::remove(BSTnode *&p, const T &x) {
	// TODO
}

template<typename T>
void BST<T>::insert(const T &x) {
	insert(root, x);
}
template<typename T>
void BST<T>::remove(const T &x) {
	remove(root, x);
}

//Task 3: BST traversals
template<typename T>
void BST<T>::in_order_traversal(BSTnode *&p) {
	// TODO
}

template<typename T>
void BST<T>::pre_order_traversal(BSTnode *&p) {
	// TODO
}

template<typename T>
void BST<T>::post_order_traversal(BSTnode *&p) {
	// TODO
}

template<typename T>
void BST<T>::in_order_traversal() {
	in_order_traversal(root);
}

template<typename T>
void BST<T>::pre_order_traversal() {
	pre_order_traversal(root);
}

template<typename T>
void BST<T>::post_order_traversal() {
	post_order_traversal(root);
}
