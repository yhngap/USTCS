#include "Node.h"

bool Node::operator <(const Node &rhs) const {
	return key < rhs.key;
}

bool Node::operator >(const Node &rhs) const {
	return key > rhs.key;
}

