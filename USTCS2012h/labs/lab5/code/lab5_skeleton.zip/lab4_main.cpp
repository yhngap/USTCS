#include <iostream>
// #include <chrono>
#include "Deque.h"

using namespace std;
// using namespace std::chrono;

static unsigned long _rng = 0;

static void _srand(unsigned seed)
{
    _rng = seed;
}

static int _rand()
{
    _rng = (1103515245 * _rng + 12345) % (1 << 31);
    return _rng & 0x7FFFFFFF;
}

void print_doubly_linked_list(const Node *nd)
{
    if (nd == nullptr)
    {
        cout << "nullptr" << endl;
        return;
    }
    while (nd != nullptr)
    {
        cout << nd->data;
        if (nd->next != nullptr)
            cout << " <-> ";
        nd = nd->next;
    }
    cout << endl;
}

void print_deque(const Deque &deque)
{
    if (deque.is_empty())
    {
        cout << "<empty>" << endl;
        return;
    }
    const Node *nd = deque.peek_front();
    while (nd != nullptr)
    {
        cout << nd->data << " ";
        nd = nd->next;
    }
    cout << endl;
}

void print_data_at_node(const Node *nd)
{
    if (nd == nullptr)
        cout << "nil" << endl;
    else
        cout << nd->data << endl;
}

void task1_tests()
{
    cout << "Task 1 tests" << endl;
    Node *nd1 = new Node{37};
    print_doubly_linked_list(nd1);
    Node *nd2 = new Node{42, nullptr, nd1};
    nd1->prev = nd2;
    print_doubly_linked_list(nd2);
    Node *nd3 = new Node{47, nd1, nullptr};
    nd1->next = nd3;
    print_doubly_linked_list(nd2);
    Node *nd4 = new Node{52, nd2, nd1};
    nd2->next = nd4;
    nd1->prev = nd4;
    print_doubly_linked_list(nd2);
    delete nd2;
    cout << "task 1 tests complete" << endl;
}
void task2_tests()
{
    cout << "Task 2 tests" << endl;
    cout << boolalpha;
    Deque deque;
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.push_front(13);
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.push_back(15);
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.push_front(27);
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.push_back(29);
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.pop_front();
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.pop_front();
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.pop_back();
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.pop_back();
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.push_front(100);
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.push_front(200);
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.push_back(300);
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.push_front(400);
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.push_back(500);
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.push_back(600);
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.push_front(700);
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.push_back(800);
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.push_back(900);
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.push_front(1000);
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.pop_front();
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.pop_front();
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.pop_back();
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.pop_front();
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.pop_back();
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.pop_back();
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.pop_front();
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.pop_back();
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.pop_back();
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.pop_front();
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.pop_front();
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    deque.pop_back();
    print_data_at_node(deque.peek_front());
    print_data_at_node(deque.peek_back());
    print_deque(deque);
    cout << deque.is_empty() << endl;
    // high_resolution_clock::time_point start = high_resolution_clock::now();
    _srand(0);
    for (int i = 0; i < 1e7; ++i)
    {
        if (_rand() % 2)
            deque.push_front(0);
        else
            deque.push_back(0);
        if (_rand() % 2)
            deque.peek_front();
        else
            deque.peek_back();
        deque.is_empty();
    }
    for (int i = 0; i < 1e7; ++i)
    {
        if (_rand() % 2)
            deque.pop_front();
        else
            deque.pop_back();
        if (_rand() % 2)
            deque.peek_front();
        else
            deque.peek_back();
        deque.is_empty();
    }
    cout << deque.is_empty() << endl;
    // high_resolution_clock::time_point end = high_resolution_clock::now();
    // cout << "Time elapsed: " << duration_cast<milliseconds>(end - start).count() << "ms" << endl;
    cout << noboolalpha;
    cout << "Task 2 tests complete" << endl;
}
void task3_tests()
{
    cout << "Task 3 tests" << endl;
    Deque deque;
    deque.push_front(100);
    deque.push_front(200);
    deque.push_back(300);
    deque.push_front(400);
    deque.push_back(500);
    deque.push_back(600);
    deque.push_front(700);
    deque.push_back(800);
    deque.push_back(900);
    deque.push_front(1000);
    print_data_at_node(deque.get_node_at(-1237));
    print_data_at_node(deque.get_node_at(-1));
    print_data_at_node(deque.get_node_at(0));
    print_data_at_node(deque.get_node_at(1));
    print_data_at_node(deque.get_node_at(2));
    print_data_at_node(deque.get_node_at(3));
    print_data_at_node(deque.get_node_at(4));
    print_data_at_node(deque.get_node_at(5));
    print_data_at_node(deque.get_node_at(6));
    print_data_at_node(deque.get_node_at(7));
    print_data_at_node(deque.get_node_at(8));
    print_data_at_node(deque.get_node_at(9));
    print_data_at_node(deque.get_node_at(10));
    print_data_at_node(deque.get_node_at(1337));
    deque.insert_data_at(-1237, 1024);
    print_deque(deque);
    deque.insert_data_at(-1, 1024);
    print_deque(deque);
    deque.insert_data_at(0, 1024);
    print_deque(deque);
    deque.insert_data_at(5, 1024);
    print_deque(deque);
    deque.insert_data_at(12, 1024);
    print_deque(deque);
    deque.insert_data_at(14, 1024);
    print_deque(deque);
    deque.insert_data_at(3233, 1024);
    print_deque(deque);
    deque.remove_at(-1237);
    print_deque(deque);
    deque.remove_at(-1);
    print_deque(deque);
    deque.remove_at(0);
    print_deque(deque);
    deque.remove_at(5);
    print_deque(deque);
    deque.remove_at(10);
    print_deque(deque);
    deque.remove_at(10);
    print_deque(deque);
    deque.remove_at(16);
    print_deque(deque);
    cout << "Task 3 tests complete" << endl;
}

int main(int argc, char **argv)
{
    if (argc == 1 || argc > 1 && argv[1][0] == '1')
        task1_tests();
    if (argc == 1 || argc > 1 && argv[1][0] == '2')
        task2_tests();
    if (argc == 1 || argc > 1 && argv[1][0] == '3')
        task3_tests();
    return 0;
}
