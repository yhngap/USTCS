#include "Node.h"

// Task 1 - Constructors and Destructor of Node and Deque
Node::Node(int data)
{
    // TODO
}
Node::Node(int data, Node *prev, Node *next)
{
    // TODO
}
Node::~Node()
{
    // TODO
}
