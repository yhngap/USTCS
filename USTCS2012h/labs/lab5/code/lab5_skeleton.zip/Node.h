struct Node
{
    int data;
    Node *prev;
    Node *next;
    Node(int);
    Node(int, Node *, Node *);
    ~Node();
};
