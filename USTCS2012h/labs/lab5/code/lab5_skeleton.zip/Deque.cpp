#include "Deque.h"

// Task 1 - Constructors and Destructor of Node and Deque
Deque::Deque()
{
    // TODO
}

Deque::~Deque()
{
    // TODO
}

// Task 2 - Essential operations for Deque
bool Deque::is_empty() const
{
    return false; // TODO
}

void Deque::push_front(int data)
{
    // TODO
}

void Deque::push_back(int data)
{
    // TODO
}

void Deque::pop_front()
{
    // TODO
}

void Deque::pop_back()
{
    // TODO
}

const Node *Deque::peek_front() const
{
    return nullptr; // TODO
}

const Node *Deque::peek_back() const
{
    return nullptr; // TODO
}

// Task 3 - Extended operations for Deque
const Node *Deque::get_node_at(int idx) const
{
    return nullptr; // TODO
}

void Deque::insert_data_at(int idx, int data)
{
    // TODO
}

void Deque::remove_at(int idx)
{
    // TODO
}
