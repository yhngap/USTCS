#include <iostream>
using std::cin;
using std::cout;

#include "lab2.h"

int main() {
	cout << "Welcome to COMP 2012H Lab 2!" << '\n';
	cout << "CHAIN REACTION!" << '\n';
	cout << '\n';

	// Set all elements of label to EMPTY_CELL, i.e. a single space.
	for (int i = 0; i < NUM_ROWS; i += 1) {
		for (int j = 0; j < NUM_COLS; j += 1) {
			label[i][j] = EMPTY_CELL;
		}
	}

	// Game Loop.
	int row, col; // Player Input Variables.
	display_grid();
	while (!is_game_over) {
		current_player = ((current_player == PLAYER_O) ? PLAYER_X : PLAYER_O); // Toggle Current Player.
		get_input(row, col);
		place_orb(row, col);
		display_grid();
	}
	cout << "GAME OVER! Player " << current_player << " wins! CONGRATULATIONS!" << '\n';

	// Prevent Immediate Console Exit.
	cout << '\n';
	cout << "Press [ENTER] to exit...";
	cin.ignore(); // Clear the newline character from the input buffer.
	cin.get(); // Wait for a single instance of cin input, but not do anything with it.
	cout << '\n';

	return 0;
}
