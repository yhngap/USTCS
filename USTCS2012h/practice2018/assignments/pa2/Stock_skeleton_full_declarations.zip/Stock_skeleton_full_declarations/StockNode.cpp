#include "StockNode.h"

StockNode* createStockNode(int stockId, double value, StockNode* next) {

}

StockNode* createHeadNode(StockNode* next) {

}

void deleteStockNode(StockNode* node) {

}

int getStockId(const StockNode* const node) {

}

double getTopValue(const StockNode* const node) {

}

double getValueAt(const StockNode* const node, int time) {

}

StockNode* getTopNext(const StockNode* const node) {

}

StockNode* getNextAt(const StockNode* const node, int time) {

}

UpdateNode* getTopUpdateNode(const StockNode* const node) {

}

UpdateNode* getUpdateNodeAt(const StockNode* const node, int time) {

}

void push(StockNode* node, const Update& update) {

}

void pop(StockNode* node) {

}

bool isHead(const StockNode* const node) {
	return node->stock.stockId == -1;
}

double getValue(const StockNode* const node) {
	return isHead(node) ? -1 : node->stock.value;
}
