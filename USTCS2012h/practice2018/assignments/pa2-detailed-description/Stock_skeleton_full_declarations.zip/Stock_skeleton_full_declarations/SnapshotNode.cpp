#include "SnapshotNode.h"

SnapshotNode* createSnapshotNode(const Snapshot& snapshot, SnapshotNode* earlier, SnapshotNode* later) {

}

void deleteSnapshotNode(SnapshotNode* node) {

}
