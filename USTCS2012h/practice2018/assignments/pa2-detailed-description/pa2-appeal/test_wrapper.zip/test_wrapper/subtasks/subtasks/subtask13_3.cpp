
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 1, 1);
	add(snapshot, 2, 2);
	remove(snapshot, 1);
	remove(snapshot, 2);
	Snapshot stamp = stampSnapshot(snapshot);
	bool result = (isHead(stamp.head)) && (stamp.head->head == nullptr) && (stamp.head->next == nullptr);
	deleteSnapshot(stamp);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
