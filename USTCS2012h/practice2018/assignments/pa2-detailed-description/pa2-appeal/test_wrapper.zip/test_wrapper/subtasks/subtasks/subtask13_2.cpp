
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 1, 1);
	add(snapshot, 2, 2);
	Snapshot stamp = stampSnapshot(snapshot);
	bool result = true;
	result &= (isHead(stamp.head)) && (stamp.head->head == nullptr);
	StockNode* node1 = stamp.head->next;
	result &= (node1->stock.stockId == 1) && (node1->head == nullptr);
	StockNode* node2 = node1->next;
	result &= (node2->stock.stockId == 2) && (node2->head == nullptr);
	result &= (node2->next == nullptr);
	deleteSnapshot(stamp);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
