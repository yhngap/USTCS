
#include "../StockNode.h"

int main(){

	StockNode* node = createHeadNode();
	float value = getTopValue(node);
	deleteStockNode(node);
	return value != -1;

}

