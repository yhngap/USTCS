
#include "../StockNode.h"

int main(){

	StockNode* node = createStockNode(2,2);
	Update update1 = Update {10, nullptr, Update::SET, 1};
	Update update2 = Update {20, nullptr, Update::SET, 2};
	Update update3 = Update {30, nullptr, Update::SET, 5};
	UpdateNode* updateNode1 = new UpdateNode {update1, nullptr};
	UpdateNode* updateNode2 = new UpdateNode {update2, updateNode1};
	UpdateNode* updateNode3 = new UpdateNode {update3, updateNode2};
	node->head = updateNode3;
	float value1 = getValueAt(node, 1);
	float value2 = getValueAt(node, 3);
	float value3 = getValueAt(node, 6);
	deleteStockNode(node);
	return !(value1 == 10 && value2 == 20 && value3 == 30);

}
