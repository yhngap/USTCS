
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 1, 1);
	bool result = (getValueAt(snapshot, 1, 1) == 1);
	result &= (getValueAt(snapshot, 1, 0) == -1);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
