
#include "../StockNode.h"

int main(){

	StockNode* node = createHeadNode();

	//Update update = getTopUpdate(node);
	UpdateNode* update = getTopUpdateNode(node);

	deleteStockNode(node);
	return update != nullptr;

}

