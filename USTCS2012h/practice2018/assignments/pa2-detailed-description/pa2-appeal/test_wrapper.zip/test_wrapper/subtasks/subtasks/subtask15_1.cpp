
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 1, 1);
	bool success = remove(snapshot, 1);
	Update update = snapshot.head->head->update;
	bool result = true;
	result &= (update.updatedValue == -1) && (update.type == Update::REMOVE) && (update.time == 2);
	result &= (update.updatedNext == nullptr);
	result &= success && (*currentTime == 2);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
