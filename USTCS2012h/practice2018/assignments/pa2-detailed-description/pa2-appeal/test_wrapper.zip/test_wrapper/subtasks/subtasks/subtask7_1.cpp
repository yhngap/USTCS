
#include "../StockNode.h"

int main(){

	StockNode* node = createHeadNode();
	StockNode* next = getNextAt(node,10);
	deleteStockNode(node);
	return next != nullptr;

}

