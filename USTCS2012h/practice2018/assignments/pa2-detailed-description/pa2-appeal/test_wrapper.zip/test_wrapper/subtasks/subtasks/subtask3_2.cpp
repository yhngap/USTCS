
#include "../StockNode.h"

int main(){

	StockNode* node = createStockNode(10,1.1);
	int id = getStockId(node);
	deleteStockNode(node);
	return id != 10;

}

