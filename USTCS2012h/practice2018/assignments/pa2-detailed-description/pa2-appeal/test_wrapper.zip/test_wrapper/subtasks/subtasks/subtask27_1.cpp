
#include "../Database.h"

int main(){

	Database db = ::createDatabase();
	::reconstruct(db, 4);
	bool result = (db.top == nullptr) && (db.currentTime == 0) && (db.interval == 4);
	::deleteDatabase(db);
	return !result;

}

