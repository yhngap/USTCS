
#include "../StockNode.h"

int main(){

	StockNode* node = createHeadNode();
	Update update1 = Update {-1, nullptr, Update::REMOVE, 1};
	Update update2 = Update {-1, nullptr, Update::REMOVE, 2};
	Update update3 = Update {-1, nullptr, Update::REMOVE, 3};
	UpdateNode* updateNode1 = new UpdateNode {update1, nullptr};
	UpdateNode* updateNode2 = new UpdateNode {update2, updateNode1};
	UpdateNode* updateNode3 = new UpdateNode {update3, updateNode2};
	node->head = updateNode3;

	//Update* update = getTopUpdate(node);
	UpdateNode* update = getTopUpdateNode(node);

	//bool result = (update == update3);
	bool result = (update == updateNode3);

	deleteStockNode(node);
	return !result;

}

