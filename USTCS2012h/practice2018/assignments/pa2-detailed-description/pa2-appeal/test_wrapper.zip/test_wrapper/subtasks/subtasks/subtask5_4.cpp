
#include "../StockNode.h"

int main(){

	StockNode* node = createStockNode(2,2);
	float value = getValueAt(node, 10);
	deleteStockNode(node);
	return value != 2;

}
