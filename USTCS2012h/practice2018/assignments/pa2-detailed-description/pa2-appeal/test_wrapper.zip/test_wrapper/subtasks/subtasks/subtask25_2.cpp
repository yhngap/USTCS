#include "../Database.h"

int main(){

	Database database = createDatabase(3, false);
	bool result = (getValueAt(database, 1, 1) == -1);
	deleteDatabase(database);
	return !result;

}

