#include "../Database.h"

int main(){

	Database database = createDatabase(3, false);
	add(database, 1, 1);
	add(database, 2, 2);
	remove(database, 1);
	set(database, 2, 20);
	add(database, 1, 10);
	remove(database, 1);
	float valuesOfStock1 [] = {-1, 1, 1, -1, -1, 10, -1};
	float valuesOfStock2 [] = {-1, -1, 2, 2, 20, 20, 20};
	bool result = true;
	for(int t = 0; t <= 6; t++){
		result &= (getValueAt(database, 1, t) == valuesOfStock1[t]);
		result &= (getValueAt(database, 2, t) == valuesOfStock2[t]);
	}
	deleteDatabase(database);
	return !result;

}

