#include "../Database.h"

int main(){

	Database database = createDatabase(3, false);
	add(database, 1, 1);
	add(database, 2, 2);
	add(database, 3, 3);
	bool result = (getValueAt(database, 1, -1) == -1) && (getValueAt(database, 1, 4) == -1);
	deleteDatabase(database);
	return !result;

}

