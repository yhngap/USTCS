
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 3, 3);
	add(snapshot, 2, 2);
	add(snapshot, 4, 4);
	add(snapshot, 1, 1);
	int i = 1;
	bool result = true;
	for(StockNode* n = getTopNext(snapshot.head); n != nullptr; n = getTopNext(n), i++)
		result &= (n->stock.stockId == i);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
