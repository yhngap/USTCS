
#include "../StockNode.h"

int main(){

	StockNode* node = createStockNode(3,3);
	StockNode* head = createHeadNode(node);
	StockNode* node2 = createStockNode(2,2);
	StockNode* node1 = createStockNode(1,1);
	Update update1 = Update {-1, node2, Update::ADD, 1};
	Update update2 = Update {-1, node1, Update::ADD, 2};
	UpdateNode* updateNode1 = new UpdateNode {update1, nullptr};
	UpdateNode* updateNode2 = new UpdateNode {update2, updateNode1};
	head->head = updateNode2;
	StockNode* next = getTopNext(head);
	bool result = (next == node1);
	deleteStockNode(node);
	deleteStockNode(head);
	deleteStockNode(node2);
	deleteStockNode(node1);
	return !result;

}

