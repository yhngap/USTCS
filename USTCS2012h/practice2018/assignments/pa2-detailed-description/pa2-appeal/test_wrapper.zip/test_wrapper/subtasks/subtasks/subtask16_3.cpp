
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 3, 3);
	add(snapshot, 2, 2);
	add(snapshot, 1, 1);
	remove(snapshot, 2);
	bool success1 = set(snapshot, 2, 20);
	add(snapshot, 2, 2);
	bool success2 = set(snapshot, 2, 20);
	bool result = (!success1) && success2 ;
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
