
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	bool success1 = add(snapshot, 1, 1);
	bool success2 = add(snapshot, 2, 2);
	Update update1 = snapshot.head->head->update;
	bool result = (update1.updatedValue == -1);
	result &= (update1.type == Update::ADD);
	result &= (update1.time == 1);
	StockNode* node1 = update1.updatedNext;
	Update update2 = node1->head->update;
	result &= (node1->stock.stockId == 1) && (node1->stock.value == 1);
	result &= (node1->next == nullptr);
	result &= (update2.updatedValue == 1);
	result &= (update2.type == Update::ADD);
	result &= (update2.time == 2);
	StockNode* node2 = update2.updatedNext;
	result &= (node2->stock.stockId == 2) && (node2->stock.value == 2);
	result &= (node2->head == nullptr) && (node2->next == nullptr);
	result &= success1 && success2 && (*currentTime == 2);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
