
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 1, 1);
	set(snapshot, 1, 10);
	remove(snapshot, 1);
	bool result = (getValueAt(snapshot, 1, 1) == 1);
	result &= (getValueAt(snapshot, 1, 2) == 10);
	result &= (getValueAt(snapshot, 1, 3) == -1);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
