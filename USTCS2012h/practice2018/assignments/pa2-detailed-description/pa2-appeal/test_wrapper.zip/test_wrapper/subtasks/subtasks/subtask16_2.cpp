
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 3, 3);
	add(snapshot, 2, 2);
	add(snapshot, 1, 1);
	bool success3 = set(snapshot, 3, 30);
	bool success2 = set(snapshot, 2, 20);
	bool success1 = set(snapshot, 1, 10);
	bool result = true;
	int i = 10;
	for(StockNode* n = getTopNext(snapshot.head); n != nullptr; n = getTopNext(n), i += 10)
		result &= (getTopValue(n) == i);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
