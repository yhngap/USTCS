#include <iostream>
#include <string.h>
#include <fstream>
#include <vector>

using namespace std;

const int NUM_OF_TASKS = 27;
const int NUM_OF_SUBTASKS[] = { 1,1,2,4,4,
								2,2,2,3,1,
								1,1,4,6,3,
								3,4,3,1,1,
								1,2,2,2,3,
								1,1 };
const int SCORES[] = {  1,1,2,2,2,
						2,2,2,3,2,
						3,1,4,6,6,
						6,6,3,1,1,
						1,4,4,4,3,
						3,5 };

/*  // original
const int NUM_OF_TASKS = 27;

const int NUM_OF_SUBTASKS [] = {1,1,2,4,4,
								2,2,2,3,1,
								3,1,4,6,3,
								3,4,3,1,1,
								1,2,2,2,3,
								1,7};

const int SCORES [] = { 1,1,2,2,2,
						2,2,2,3,2,
						3,1,4,6,6,
						6,6,3,1,1,
						1,4,4,4,3,
						3,15};
*/
					   
const string NAME_OF_SUBTASK [] = {
	
	"(createStockNode)",  // task1: 1
	"(createHeadNode)",  // 2
	"(getStockId)",  // 3
	"(getTopValue)",  // 4
	"(getValueAt)",  // 5
	"(getTopNext)",  // 6
	"(getNextAt)",  // 7
	"(getTopUpdate)",  // 8
	"(getUpdateAt)",  // 9
	"(push)",  // 10
	"(pop)",  // 11
	"(createSnapshot)",  // task2: 12
	"(stampSnapshot)",  // 13
	"(add)",  // 14
	"(remove)",  // 15
	"(set)",  // 16
	"(undo)",  // 17
	"(getValueAt)",  // 18
	"(createSnapshotNode)",  // task3: 19
	"(createDatabase)",  // task4: 20
	"(needToStamp)",  // 21
	"(add)",  // 22
	"(remove)",  // 23
	"(set)",  // 24
	"(getValueAt)",  // 25
	"(stamp)",  // 26
	"(reconstruct)"  // 27
	
};

void test(int subtask, int number, vector<int>& res){

	string path = "./subtasks/subtasks/";
	string name = "subtask" + to_string(subtask) + "_" + to_string(number);
	cout << "Running " << name << ".exe..." << endl;  // .exe???
	int ret = system((path + name).c_str());
	res.push_back(ret == 0);

}

void output(string num, int wid, ofstream& fout)
{
    fout << num;
    for (int i = 1; i <= wid - num.length(); i++) fout << " ";
}

void export_to_summary(string stuid, int total, int scores[])
{
    string filename = "./results/Summary.txt";
    ofstream fout;
    fout.open(filename, ios::app);
    fout << "  ";
	output(stuid, 12, fout);
    output(to_string(total), 8, fout);
    for (int i = 0; i < NUM_OF_TASKS; i++) {
        output(to_string(scores[i]), 7, fout);
    }
    fout << endl;
}

void generate_report(vector<int> res[], string stuid)
{
	
    int scores[NUM_OF_TASKS] = {0};
    int passed[NUM_OF_TASKS] = {0};
    int fullscore = 0;
    int curscore = 0;
    ofstream fout;
    string filename = "./results/result_" + stuid + ".txt";
    fout.open(filename, ios::out | ios::trunc);
    for (int i = 0; i < NUM_OF_TASKS; i++) {
        fullscore += SCORES[i];
        for (int j = 0; j < res[i].size(); j++) {
            passed[i] += res[i][j];
        }
        scores[i] = (SCORES[i]*passed[i])/NUM_OF_SUBTASKS[i];
        curscore += scores[i];
    }
    fout << "# Grading Report for " << stuid << " [" << curscore << "/" << fullscore << "]" << endl;
    for (int i = 0; i < NUM_OF_TASKS; i++) {
        fout << endl;
        fout << "+ Subtask #" << (i + 1) << ": " << NAME_OF_SUBTASK[i] << endl;
        fout << "\t+ [" << scores[i] << "/" << SCORES[i] << "] | " << NUM_OF_SUBTASKS[i] << " tests, " << passed[i] << " passed." << endl;
        for (int j = 0; j < NUM_OF_SUBTASKS[i]; j++) {
            fout << "\t\t- Test #" << (j + 1) << ": " << (res[i][j] ? "Passed." : "Failed.") << endl;
        }
    }
    fout.close();

   // export_to_summary(stuid, curscore, scores);
	
}

int main(int argc, char** argv){
	
	vector<int> res[NUM_OF_TASKS];
	for(int i = 0; i < NUM_OF_TASKS; i++)
		for(int j = 1; j <= NUM_OF_SUBTASKS[i]; j++)
			test(i+1, j, res[i]);
	generate_report(res, argv[1]);
	
}
