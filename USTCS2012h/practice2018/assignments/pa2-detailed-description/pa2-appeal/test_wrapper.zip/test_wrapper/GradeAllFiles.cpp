#include <iostream>
#include <dirent.h>
#include <string.h>
#include <fstream>

using namespace std;

const int NUM_OF_TASKS = 27; 
const int NUM_OF_SUBTASKS [] = { 1,1,2,4,4,
                                 2,2,2,3,1,
	                             1,1,4,6,3,
	                             3,4,3,1,1,
	                             1,2,2,2,3,  
	                             1,1 };

/*  // original tests
const int NUM_OF_SUBTASKS [] = {1,1,2,4,4,
								2,2,2,3,1,
								3,1,4,6,3,
								3,4,3,1,1,
								1,2,2,2,3,
								1,7};
*/

string files [] = {"Database", "Snapshot", "SnapshotNode", "StockNode"};

bool copyFile(const char *SRC, const char* DEST)
{
	
    ifstream src(SRC, std::ios::in);
    ofstream dest(DEST, std::ios::out | std::ios::trunc);
    dest << src.rdbuf();
    return src && dest;
	
}

void createSummarySheet(){
	
	ofstream sheet("./results/Summary.txt", std::ios::out | std::ios::trunc);
	sheet << "  StudentID   Total";
	string space = "   ";
	for(int i = 1; i <= NUM_OF_TASKS; i++){
		sheet << space << "Sub" << i;
		if(i == 10) space = "  ";
	}
	sheet << endl;
	sheet.close();
	
}

string getStudentId(string name){

	return name.substr(name.find_last_of("_") + 1);

}

void compile(){
	
	for(int i = 1; i <= NUM_OF_TASKS; i++){
		for(int j = 1; j <= NUM_OF_SUBTASKS[i-1]; j++){
			string name = "subtask" + to_string(i) + "_" + to_string(j);
			cout << "Compiling " << name << ".cpp..." << endl;
			system(("make -C ./subtasks " + name).c_str());
			cout << endl;
		}
	}
	cout << "Compiling grader.cpp..." << endl;

	system("g++ -o grader grader.cpp -std=c++11");

	// g++ -o GradeAllFiles GradeAllFiles.cpp -std=c++11
		
}

int main() {
	
	dirent* dp;
    // the folder containing the students' submissions
	string dir_files = "./files_zero";  // files_one, files_all, files_zero
	DIR *dir = opendir(dir_files.c_str());
	string stuid;

	//createSummarySheet();
	
	int count = 0;

	while((dp=readdir(dir))){
		
		cout << "name = " << dp->d_name << endl;

		if (strcmp(dp->d_name, ".") != 0 && strcmp(dp->d_name, "..") != 0){
			
			string name = dp->d_name;
			
			stuid = getStudentId(name);
			cout << "stuid = " << stuid << endl;

			string path = dir_files + "/" + name + "/";


			for (string s : files) {
				string from = path + s + ".cpp";
				string to = "./subtasks/" + s + ".cpp";
				copyFile(from.c_str(), to.c_str());
				cout << "from = " << from << endl;
				cout << "to = " << to << endl;
			}
				
			
			compile();

			system(("./grader " + stuid).c_str());

			cout << "Finish grading. Cleaning..." << endl;
			
			system("make -C ./subtasks clean");
			
			count += 1;
		}
			

	}
	
	/*
	cout << "Press [ENTER] to quit: "; 
	string empty;
	while(getline(cin, empty)){
		if(empty.empty()) return 0;
	}
	*/
		
}
