
#include "../StockNode.h"

int main(){

	StockNode* node = createStockNode(2,2);
	float value = getTopValue(node);
	deleteStockNode(node);
	return value != 2;

}

