
#include "../StockNode.h"

int main(){

	StockNode* node = createHeadNode();
	Update update1 = Update {-1, nullptr, Update::REMOVE, 1};
	Update update2 = Update {-1, nullptr, Update::REMOVE, 2};
	Update update3 = Update {-1, nullptr, Update::REMOVE, 3};
	UpdateNode* updateNode1 = new UpdateNode {update1, nullptr};
	UpdateNode* updateNode2 = new UpdateNode {update2, updateNode1};
	UpdateNode* updateNode3 = new UpdateNode {update3, updateNode2};
	node->head = updateNode3;
	UpdateNode* u1 = getUpdateNodeAt(node, 1);
	UpdateNode* u2 = getUpdateNodeAt(node, 2);
	UpdateNode* u3 = getUpdateNodeAt(node, 3);
	bool result = (u1 == updateNode1) && (u2 == updateNode2) && (u3 == updateNode3);
	deleteStockNode(node);
	return !result;

}

