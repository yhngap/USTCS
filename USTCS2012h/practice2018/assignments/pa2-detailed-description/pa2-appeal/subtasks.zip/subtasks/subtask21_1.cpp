#include "../Database.h"

int main(){

	Database database = createDatabase(3, false);
	add(database, 1, 1);
	bool result = (!needToStamp(database));
	add(database, 2, 2);
	result &= (!needToStamp(database));
	add(database, 3, 3);
	result &= (needToStamp(database));
	deleteDatabase(database);
	return !result;

}

