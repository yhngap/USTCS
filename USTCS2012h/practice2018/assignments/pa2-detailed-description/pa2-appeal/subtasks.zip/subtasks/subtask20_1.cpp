#include "../Database.h"

int main(){

	Database database = createDatabase(3, false);
	bool result = (database.interval == 3);
	result &= (database.top == nullptr) && (database.bottom == nullptr);
	result &= (database.currentTime == 0) && (database.enableLog == false);
	deleteDatabase(database);
	return !result;

}

