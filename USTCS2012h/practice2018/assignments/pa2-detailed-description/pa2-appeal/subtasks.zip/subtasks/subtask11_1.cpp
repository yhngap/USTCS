
#include "../StockNode.h"

int main(){

	StockNode* node = createStockNode(1,1);
	Update update1 = Update {2, nullptr, Update::SET, 1};
	Update update2 = Update {3, nullptr, Update::SET, 2};
	push(node, update1);
	push(node, update2);
	pop(node);

	// no match for �operator==� (operand types are �Update� and �Update�)
	bool result = (node->head->update.updatedValue == update1.updatedValue);

	deleteStockNode(node);
	return !result;

}

