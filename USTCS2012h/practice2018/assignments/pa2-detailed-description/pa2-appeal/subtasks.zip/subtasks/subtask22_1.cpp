#include "../Database.h"

int main(){

	Database database = createDatabase(5, false);
	add(database, 1, 1);
	SnapshotNode* snapshotNode = database.top;
	bool result = (snapshotNode != nullptr) && (database.bottom == snapshotNode);
	deleteDatabase(database);
	return !result;

}

