
#include "../StockNode.h"

int main(){

	StockNode* node = createHeadNode();
	float value = getValueAt(node, 10);
	deleteStockNode(node);
	return value != -1;

}
