
#include "../StockNode.h"

int main(){

	StockNode* node = createHeadNode();
	Update update = Update {-1, nullptr, Update::REMOVE, 1};
	UpdateNode* updateNode = new UpdateNode {update, nullptr};
	float value = getValueAt(node, 1);
	deleteStockNode(node);
	return value != -1;

}

