
#include "../StockNode.h"

int main(){

	StockNode* node = createStockNode(2,2);
	Update update1 = Update {10, nullptr, Update::SET, 1};
	Update update2 = Update {20, nullptr, Update::SET, 2};
	UpdateNode* updateNode1 = new UpdateNode {update1, nullptr};
	UpdateNode* updateNode2 = new UpdateNode {update2, updateNode1};
	node->head = updateNode2;
	float value = getTopValue(node);
	deleteStockNode(node);
	return value != 20;
}

