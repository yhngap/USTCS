
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 1, 1);
	bool success = set(snapshot, 1, 2);

	Update update = snapshot.head->head->update;

	bool result = true;
	result &= (update.updatedValue == 2) && (update.updatedNext == nullptr);
	result &= (update.type == Update::SET) && (update.time == 2);
	result &= (getTopNext(snapshot.head)->stock.value == 1);
	result &= success && (*currentTime == 2);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
