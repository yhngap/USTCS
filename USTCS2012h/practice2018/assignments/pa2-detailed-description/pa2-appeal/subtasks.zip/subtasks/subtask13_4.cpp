
#include "../Snapshot.h"

//Example from website
int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 1, 1);
	add(snapshot, 2, 2);
	add(snapshot, 3, 3);
	remove(snapshot, 2);
	set(snapshot, 1, 9);
	add(snapshot, 2, 2);
	Snapshot stamp = stampSnapshot(snapshot);
	bool result = true;
	result &= (isHead(stamp.head)) && (stamp.head->head == nullptr);
	StockNode* node1 = stamp.head->next;
	result &= (node1->stock.stockId == 1) && (node1->stock.value == 9) && (node1->head == nullptr);
	StockNode* node2 = node1->next;
	result &= (node2->stock.stockId == 2) && (node2->head == nullptr);
	StockNode* node3 = node2->next;
	result &= (node3->stock.stockId == 3) && (node3->head == nullptr) && (node3->next == nullptr);
	result &= (stamp.time == 6);
	deleteSnapshot(stamp);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
