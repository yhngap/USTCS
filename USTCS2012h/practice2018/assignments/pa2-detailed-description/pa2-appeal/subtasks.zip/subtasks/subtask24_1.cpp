#include "../Database.h"

int main(){

	Database database = createDatabase(5, false);
	set(database, 1, 10);
	bool result = (database.top == nullptr);
	deleteDatabase(database);
	return !result;

}

