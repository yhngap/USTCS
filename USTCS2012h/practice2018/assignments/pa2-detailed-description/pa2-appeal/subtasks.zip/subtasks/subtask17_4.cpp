
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 1, 1);
	add(snapshot, 2, 2);
	add(snapshot, 3, 3);
	Snapshot stamp = stampSnapshot(snapshot);
	bool success = undo(stamp);
	deleteSnapshot(stamp);
	deleteSnapshot(snapshot);
	delete currentTime;
	return success;

}
