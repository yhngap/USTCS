
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	bool success = add(snapshot, 1, 1);
	Update update = snapshot.head->head->update;
	bool result = (update.updatedValue == -1);
	result &= (update.type == Update::ADD);
	result &= (update.time == 1);
	StockNode* node1 = update.updatedNext;
	result &= (node1->stock.stockId == 1) && (node1->stock.value == 1);
	result &= (node1->head == nullptr) && (node1->next == nullptr);
	result &= success && (*currentTime == 1);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
