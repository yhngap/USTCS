
#include "../StockNode.h"

int main(){

	StockNode* node = createHeadNode();
	int id = getStockId(node);
	deleteStockNode(node);
	return id != -1;

}

