
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 2, 2);
	add(snapshot, 1, 1);
	Snapshot stamp = stampSnapshot(snapshot);
	StockNode* node1 = stamp.head->next;
	StockNode* node2 = node1->next;
	bool result = (node1->stock.stockId == 1) && (node2->stock.stockId == 2);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
