
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 1, 1);
	add(snapshot, 2, 2);
	add(snapshot, 3, 3);
	remove(snapshot, 2);
	remove(snapshot, 1);

	Update update = snapshot.head->head->update;
	bool result = (getTopNext(snapshot.head)->stock.stockId == 3);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
