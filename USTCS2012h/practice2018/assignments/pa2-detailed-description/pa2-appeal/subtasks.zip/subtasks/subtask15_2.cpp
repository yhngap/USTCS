
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 1, 1);
	add(snapshot, 2, 2);
	add(snapshot, 3, 3);
	bool success = remove(snapshot, 4);
	bool result = (!success) && (*currentTime == 3);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
