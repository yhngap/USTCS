
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (5);
	Snapshot snapshot = createSnapshot(currentTime);
	bool result = (isHead(snapshot.head)) && 
		(snapshot.currentTime == currentTime) &&
		(snapshot.time == 5);
	delete currentTime;
	deleteStockNode(snapshot.head);
	return !result;

}
