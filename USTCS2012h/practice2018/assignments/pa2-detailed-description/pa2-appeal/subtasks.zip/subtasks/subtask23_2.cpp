#include "../Database.h"

int main(){

	Database database = createDatabase(1, false);
	add(database, 1, 1);
	remove(database, 1);
	bool result = (database.top != database.bottom);
	deleteDatabase(database);
	return !result;

}

