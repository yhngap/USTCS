
#include "../StockNode.h"

int main(){

	StockNode* node = createHeadNode();
	StockNode* next = getTopNext(node);
	deleteStockNode(node);
	return next != nullptr;

}

