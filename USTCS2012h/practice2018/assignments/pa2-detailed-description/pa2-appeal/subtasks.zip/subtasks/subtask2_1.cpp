
#include "../StockNode.h"

int main(){

	StockNode* node = createHeadNode();
	StockNode* head = createHeadNode(node);

	//bool result = head->head == nullptr && head->stock == nullptr && head->next == node;
	bool result = head->head == nullptr && head->stock.stockId == -1 && head->next == node;

	deleteStockNode(node);
	deleteStockNode(head);
	return !result;

}

