#include "../Database.h"

int main(){

	Database database = createDatabase(100, false);
	add(database, 1, 1);
	SnapshotNode* node1 = database.top;
	add(database, 2, 2);
	add(database, 3, 3);
	stamp(database);
	SnapshotNode* node2 = database.top;
	bool result = (node1->earlier == nullptr) && (node1->later == node2);
	result &= (node2->earlier == node1) && (node2->later == nullptr);
	Snapshot snapshot = node2->snapshot;
	int i = 1;
	for(StockNode* n = getTopNext(snapshot.head); n != nullptr; n = getTopNext(n), i++)
		result &= (getTopValue(n) == i);
	deleteDatabase(database);
	return !result;

}

