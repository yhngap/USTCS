
#include "../StockNode.h"

int main(){

	StockNode* node = createHeadNode();
	Update update = Update {-1, nullptr, Update::REMOVE, 1};
	UpdateNode* updateNode = new UpdateNode {update, nullptr};
	node->head = updateNode;
	float value = getTopValue(node);
	deleteStockNode(node);
	return value != -1;

}

