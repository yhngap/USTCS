
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 1, 1);
	bool success1 = undo(snapshot);
	bool success2 = undo(snapshot);
	bool result = success1 && !success2;
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
