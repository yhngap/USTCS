
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 1, 1);
	set(snapshot, 1, 10);
	remove(snapshot, 1);
	undo(snapshot);
	StockNode* node1 = getTopNext(snapshot.head);
	bool result = (getTopValue(node1) == 10) && (*currentTime == 2);
	undo(snapshot);
	result &= (getTopValue(node1) == 1) && (*currentTime == 1);
	undo(snapshot);
	result &= (snapshot.head->head == nullptr) && (*currentTime == 0);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
