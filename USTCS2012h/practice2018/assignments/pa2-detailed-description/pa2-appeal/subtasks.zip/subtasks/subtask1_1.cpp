
#include "../StockNode.h"

int main(){

	StockNode* n = createStockNode(2,2);
	StockNode* node = createStockNode(1,1,n);

	//Stock* stock = node->stock;
	Stock& stock = node->stock;

	//bool result = stock->stockId == 1 && stock->value == 1 && node->next == n && node->head == nullptr;
	bool result = stock.stockId == 1 && stock.value == 1 && node->next == n && node->head == nullptr;

	deleteStockNode(n);
	deleteStockNode(node);
	return !result;

}
