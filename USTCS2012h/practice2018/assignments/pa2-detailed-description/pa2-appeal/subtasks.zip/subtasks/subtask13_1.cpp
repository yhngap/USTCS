
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (5);
	Snapshot snapshot = createSnapshot(currentTime);
	Snapshot stamp = stampSnapshot(snapshot);
	bool result = (isHead(stamp.head)) && (stamp.currentTime == snapshot.currentTime) &&
				  (stamp.time == 5) && (stamp.head->next == nullptr);
	deleteSnapshot(stamp);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !result;

}
