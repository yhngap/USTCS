#include "../Database.h"

int main(){

	Database database = createDatabase(5, false);
	remove(database, 1);
	bool result = (database.top == nullptr);
	deleteDatabase(database);
	return !result;

}

