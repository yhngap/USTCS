
#include "../StockNode.h"

int main(){

	StockNode* node = createHeadNode();
	UpdateNode* update = getUpdateNodeAt(node, 10);
	deleteStockNode(node);
	return update != nullptr;

}

