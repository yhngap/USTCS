
#include "../SnapshotNode.h"

int main(){

	int* currentTime = new int(0);
	Snapshot snapshot = createSnapshot(currentTime);
	SnapshotNode* snapshotNode = createSnapshotNode(snapshot);

	// no match for �operator==� (operand types are �Snapshot� and �Snapshot�)
	//bool result = (snapshotNode->snapshot == snapshot);
	bool result = (snapshotNode->snapshot.head == snapshot.head)  && 
		(*(snapshotNode->snapshot.currentTime) == *(snapshot.currentTime))  &&
		(snapshotNode->snapshot.time == snapshot.time);

	result &= (snapshotNode->earlier == nullptr) && (snapshotNode->later == nullptr);
	deleteSnapshotNode(snapshotNode);
	delete currentTime;
	return !result;

}


