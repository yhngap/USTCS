#include "../Database.h"

int main(){

	Database database = createDatabase(3, false);
	add(database, 1, 1);
	SnapshotNode* node1 = database.top;
	remove(database, 1);
	add(database, 1, 5);
	set(database, 1, 10);
	SnapshotNode* node2 = database.top;
	bool result = (node1 != node2);
	float value = getValueAt(node2->snapshot, 1, 4);
	result &= (value == 10);
	deleteDatabase(database);
	return !result;

}

