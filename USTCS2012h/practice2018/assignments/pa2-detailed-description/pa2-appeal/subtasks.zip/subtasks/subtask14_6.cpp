
#include "../Snapshot.h"

int main(){

	int* currentTime = new int (0);
	Snapshot snapshot = createSnapshot(currentTime);
	add(snapshot, 1, 1);
	remove(snapshot, 1);
	bool success = add(snapshot, 1, 2);
	deleteSnapshot(snapshot);
	delete currentTime;
	return !success;

}
