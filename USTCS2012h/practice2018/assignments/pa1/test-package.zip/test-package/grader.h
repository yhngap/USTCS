#ifndef GRADER_H
#define GRADER_H

#include <iostream>
#include <cstdlib>
#include <fstream>
//#include <algorithm>
#include <time.h>
#include "helper.h"
using namespace std;

// Correct Implementations

/***********************************************************************
 * TODO_1: Check if the inserted value is valid
 ************************************************************************/

bool grader_input_is_valid(const char grid[][9], int value, int row, int col) {
	// indices are invalid, exceptions occurred
	if (row < 0 || row > 8 || col < 0 || col > 8) {
		cout << "indices are invalid, exceptions occurred" << endl;
		exit(1);
	}

    // Make sure value is within legal range
    if (value < 1 || value > 9)
        return false;

    char input = value + '0';
    // Check within row
    for (int i = 0; i < 9; i++) {
        if (grid[row][i] == input)
            return false;
    }
    // Check within column
    for (int i = 0; i < 9; i++) {
        if (grid[i][col] == input)
            return false;
    }

    // Check within subgrid
    for (int i = 3 * int(row/3); i < 3 * int(row/3) + 3; i++) {
        for (int j = 3 * int(col/3); j < 3 * int(col/3) + 3; j++) {
            if (grid[i][j] == input)
                return false;
        }
    }
    return true;
 } 


/***********************************************************************
 * TODO_2: Edits one cell of the table based on the coordinates
 *        entered by the user.
 ************************************************************************/
void grader_edit_cell(const char initial_grid[][9], char grid[][9]) {
    // Declare variables
    char letter;
    int number;
    int value = 0;

    // Get letter/number coordinates
    cout << "Enter the coordinates of the cell: ";
    get_coordinate(letter, number);

    // Convert letter to uppercase
    letter = toupper(letter);

    // Convert letter/number to row number/column number
    int col = (letter - '0') - 17;
    int row = number - 1;  // 1-9 -> 0-8 

    // If cell is full initially, display "read only" message
    if (initial_grid[row][col] != ' ') {
        cout << "ERROR: Cell \'" << letter << number << "\' is read-only" << endl;
        cout << endl;
    }
    else {
        // Gets value to place in specified coordinates
        cout << "Enter the value at \'" << letter << number << "\': ";
        get_value(value);

        // Check if input is valid
        if (grader_input_is_valid(grid, value, row, col))
            grid[row][col] = value + '0';
        else
            cout << "ERROR: Value \'" << value << "\' in cell \'" << letter << number << "\' is invalid" << endl;
    }
}



/***********************************************************************
 * TODO_3: Removes one cell of the grid based on the coordinates
 *         entered by the user.
 ************************************************************************/
void grader_remove_cell(const char initial_grid[][9], char grid[][9]) {
    // Declare variables
    char letter;
    int number;

    // Gets letter/number coordinates
    cout << "Enter the coordinates of the cell: ";
    get_coordinate(letter,  number);

    // Converts letter to uppercase
    letter = toupper(letter);

    // Convert letter/number to row/column number
    int col = (letter - '0') - 17;
    int row = number - 1;

    // If cell is full initially, display "read only" message
    if (initial_grid[row][col] != ' ')
        cout << "ERROR: Cell \'" << letter << number << "\' is read-only" << endl;
    else
        grid[row][col] = ' ';
}


/***********************************************************************
 * TODO_4: Check if user has fininshed solving the grid
 ************************************************************************/
bool grader_check_end_game(const char grid[][9]) {
    for (int row = 0; row < 9; row++) {
        for (int col = 0; col < 9; col++) {
            if (grid[col][row] == ' ')
                return false;
        }
    }
    return true;
}



/***********************************************************************
 * TODO_5: Automatic Sudoku Solver
 ************************************************************************/
bool grader_empty_cell(char grid[][9], int& row, int& col) {
    // Check if there is any empty cell.
    // If so, return true. Otherwise, return false.
    for (row = 0; row < 9; row++) {
        for (col = 0; col < 9; col++) {
            if (grid[row][col] == ' ')
                return true;
        }
    }
    return false;
}


bool grader_sudoku_solver(char grid[][9]) {
    int row, col;
    // If there is no unassigned location, we are done
    if (!grader_empty_cell(grid, row, col))
        return true; // Success!

    // Consider digits 1 to 9
    for (int num = 1; num <= 9; num++) {
        // If it looks promising
        if (grader_input_is_valid(grid, num, row, col))
        {
            // Make tentative assignment
            grid[row][col] = num + '0';

            // Return, if success, yay!
            if (grader_sudoku_solver(grid))
                return true;

            // Failure, undo & try again
            grid[row][col] = ' ';
        }
    }

    return false;
}

/***********************************************************************
 * TODO_6: Generate Complete Valid Board
 ************************************************************************/
// use function:
// bool valid_grid(char grid[][9]) 
// to check the correctness of
// generate_board
// implemented by the submissions


// **********************************************************************
//  * TODO_7: Generate Puzzles with Unique Solutions
//  ***********************************************************************
// use function
// void count_solution(char grid[][9], int &number){
// to check the correctness of 
// generate_unique_puzzle
// implemented by the submissions


// Helper functions 

bool equal_grid(char a[][9], char b[][9]){
	for(int i = 0; i < 81; i++){
		int x = i / 9;
		int y = i % 9;
		if(a[x][y] != b[x][y]){
			return false;
		}
	}
	return true;
}

int sum_array(int a[], int n){
	int sum = 0;
    for(int i = 0; i < n; i++){
		sum += a[i];
	}
	return sum;
}

bool valid_grid(char grid[][9]){
	int exists[] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
	// check row
	for (int row = 0; row < 9; row++){
		int exists[] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
		for (int col = 0; col < 9; col++){
			int value = grid[row][col] - '0';
			exists[value - 1] = 1;
		}
		if(sum_array(exists, 9) != 9){
			return false;
		}
	}

	// check column
	for (int col = 0; col < 9; col++){
		int exists[] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
		for (int row = 0; row < 9; row++){
			int value = grid[row][col] - '0';
			exists[value - 1] = 1;
		}
		if(sum_array(exists, 9) != 9){
			return false;
		}
	}

	return true;
}

bool empty(char grid[][9], int &row, int &col) {
    for (row = 0; row < 9; row++) {
        for (col = 0; col < 9; col++) {
            if (grid[row][col] == ' ') {
                return true;
            }
        }
    }
    return false;
}

void count_solution(char grid[][9], int &number){
    int row, col;

    if(!empty(grid, row, col)){
        number++;
        return ;
    }

    for(int i=1; i<=9 && number<2; i++){
        if(grader_input_is_valid(grid, i, row, col)){
            grid[row][col] = i + '0';
            count_solution(grid, number);
        }

        grid[row][col] = ' ';
    }

}

void assign_grid(char a[][9], char b[][9]){
	for(int i = 0; i < 81; i++){
		int x = i / 9;
		int y = i % 9;
		a[x][y] = b[x][y];
	}
	return;
}

#endif
