//
//  main.cpp
//  sudoku
//
//  Created by Frank Yang on 2018/7/10.
//  Updated by hu on 2018/11/17.
//  Copyright © 2018年 Frank Yang. All rights reserved.
//

#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
//#include <algorithm>
#include <time.h>
#include <iomanip>
#include "helper.h"
#include "todo.h"
#include "grader.h"
using namespace std;

int main() {
    std::cout.setstate(std::ios_base::failbit);
    // Declare Array
    char initial_grid[9][9];
    char grid[9][9];
    char operation;
    read_file(initial_grid, "grid.txt");
    initialize_grid(grid);
    duplicate_grid(initial_grid, grid);

    ofstream fout;
    fout.open("results.txt");

	int total_trials = 0;
	int total_corrects = 0;

    // Task 1
    // Number out of range & Nan
    fout << "Task 1: input_is_valid()" << endl;
	printf("Task 1: input_is_valid()\n");

    fout << "------------------------" << endl;
    int TRIALS = 10;
    int correct = 0;

    for(int trial = 0; trial < TRIALS; trial++){
		int number = trial % 9 + 1;  // 1-9
		int row = trial % 9;  // 0-8
		int col = trial % 9;  // 0-8
        bool result = (input_is_valid(grid, number, row, col) == grader_input_is_valid(grid, number, row, col));
        if (result){
            correct++;
        }
    }
    total_corrects += correct;
    total_trials += TRIALS;
    fout << TRIALS << " tests, " << correct << " passed." << endl;
    fout << endl;

    // Task 2
    // Edit Cell
    TRIALS = 20;
    fout << "Task 2: edit_cell()" << endl;
    fout << "------------------------" << endl;
	printf("Task 2: edit_cell()\n");

    correct = 0;
    for(int trial = 0; trial < TRIALS; trial++){
        char grader_grid[9][9];
        assign_grid(grader_grid, grid);
        edit_cell(initial_grid, grid);
        grader_edit_cell(initial_grid, grader_grid);
        bool result = (equal_grid(grader_grid, grid));
        if (result){
            correct++;
        }
    }
    total_corrects += correct;
    total_trials += TRIALS;
    fout << TRIALS << " tests, " << correct << " passed." << endl;
    fout << endl;

    // Task 3
    // Remove Cell
    fout << "Task 3: remove_cell()" << endl;
    fout << "------------------------" << endl;
	printf("Task 3: remove_cell()\n");

    correct = 0;

    for(int trial = 0; trial < TRIALS; trial++){
        char grader_grid[9][9];
        assign_grid(grader_grid, grid);
        remove_cell(initial_grid, grid);
        grader_remove_cell(initial_grid, grader_grid);
        bool result = (equal_grid(grader_grid, grid));
        if (result){
            correct++;
        }
    }

    total_corrects += correct;
    total_trials += TRIALS;
    fout << TRIALS << " tests, " << correct << " passed." << endl;
    fout << endl;

    // Task 4
    // Gameover
    TRIALS = 10;
    fout << "Task 4: gameover()" << endl;
    fout << "------------------------" << endl;
	printf("Task 4: gameover()\n");

    correct = 0;
    fout << "Subtask 1: Gameover" << endl;
	printf("Subtask 1: Gameover\n");

    for(int trial = 0; trial < TRIALS; trial++){
        initialize_grid(grid);
        generate_board(grid);
        bool result = (check_end_game(grid) == grader_check_end_game(grid));
        if (result){
            correct++;
        }
    }
    fout << TRIALS << " tests, " << correct << " passed." << endl;
    fout << endl;
    total_corrects += correct;
    total_trials += TRIALS;
    correct = 0;
    fout << "Subtask 2: Game not over" << endl;
	printf("Subtask 2: Game not over\n");

    for(int trial = 0; trial < TRIALS; trial++){
        initialize_grid(grid);
        generate_board(grid);
        for(int i = 0; i < 10; i++){
            int x = i / 9;
            int y = i % 9;
            grid[x][y] = ' ';
        }
        bool result = (check_end_game(grid) == grader_check_end_game(grid));
        if (result){
            correct++;
        }
    }
    total_corrects += correct;
    total_trials += TRIALS;
    fout << TRIALS << " tests, " << correct << " passed." << endl;
    fout << endl;

    // Task 5
    // Sudoku Solver
    TRIALS = 20;
    fout << "Task 5: sudoku_solver()" << endl;
    fout << "------------------------" << endl;
	printf("Task 5: sudoku_solver()\n");

    correct = 0;
    for(int trial = 0; trial < TRIALS; trial++){
        initialize_grid(grid);
        generate_board(grid);
        generate_unique_puzzle(grid);
        char grader_grid[9][9];
        assign_grid(grader_grid, grid);
        sudoku_solver(grid);
        grader_sudoku_solver(grader_grid);
        bool result = (equal_grid(grader_grid, grid));
        if (result){
            correct++;
        }
    }
    total_corrects += correct;
    total_trials += TRIALS;
    fout << TRIALS << " tests, " << correct << " passed." << endl;
    fout << endl;

    // Task 6
    // Generate Complete Board
    fout << "Task 6: generate_board()" << endl;
    fout << "------------------------" << endl;
	printf("Task 6: generate_board()\n");

    correct = 0;
    for(int trial = 0; trial < TRIALS; trial++){
        initialize_grid(grid);
        generate_board(grid);
        if(valid_grid(grid)){
            correct++;
        }
    }
    total_corrects += correct;
    total_trials += TRIALS;
    fout << TRIALS << " tests, " << correct << " passed." << endl;
    fout << endl;

    // Task 7
    // Generate Puzzle
    fout << "Task 7: generate_unique_puzzle() " << endl;
    fout << "------------------------" << endl;
	printf("Task 7: generate_unique_puzzle()\n");

    correct = 0;
    for(int trial = 0; trial < TRIALS; trial++){
        initialize_grid(grid);
        generate_board(grid);
        generate_unique_puzzle(grid);
        int solutions = 0;
        count_solution(grid, solutions);
        bool result = (solutions == 1);
        if (result){
            correct++;
        }
    }
    total_corrects += correct;
    total_trials += TRIALS;
    fout << TRIALS << " tests, " << correct << " passed." << endl;
    fout << endl;
    fout << "------------------------" << endl;
    double percentage = total_corrects / (total_trials * 1.0);
    fout << fixed;
    fout << setprecision(2);
    fout << "Total Score: " << total_corrects << " / " << total_trials << " = " << percentage*100 << " %" << endl;
	printf("Total Score: %d / %d = %f\%\n", total_corrects, total_trials, percentage * 100);

    fout.close();

    return 0;
}

