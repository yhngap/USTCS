//
//  COMP 2012H Programming Assignment 1: Sudoku
//  Filename: todo.cpp
//  - This is the file you need to submit to Canvas.
//  - Remember to create a zip file with this file.
//  - The zip file should be named todo_<STUDENTID>.zip.
//

#include "helper.h"
#include "todo.h"

/***********************************************************************
 * TODO_1: Check whether the inserted value is compliant
 *         with the rules of Sudoku.
 ***********************************************************************/

bool input_is_valid(const char grid[][9], int value, int row, int col) {
	/// ADD YOUR CODE HERE
}

/***********************************************************************
 * TODO_2: Ask coordinate inputs from the user, and a value to insert.
 *         Check whether the user's input is valid. If the user's input
 *         is valid, insert the value and update the current grid.
 *         Otherwise, print an error message.
 ***********************************************************************/

void edit_cell(const char initial_grid[][9], char grid[][9]) {
	/// ADD YOUR CODE HERE
}

/***********************************************************************
 * TODO_3: Ask coordinate inputs from the user. Remove the value from
 *         the current grid if the cell has not been filled in the
 *         beginning.
 ***********************************************************************/

void remove_cell(const char initial_grid[][9], char grid[][9]) {
	/// ADD YOUR CODE HERE
}

/***********************************************************************
 * TODO_4: Check whether all the cells in the grid have been
 *         correctly filled.
 ***********************************************************************/

bool check_end_game(const char grid[][9]) {
	/// ADD YOUR CODE HERE
}

/***********************************************************************
 * TODO_5: Automatic Sudoku solver.
 *         Complete all the empty cells with the
 *         correct solution if it exists.
 ***********************************************************************/

bool sudoku_solver(char grid[][9]) {
	/// ADD YOUR CODE HERE
}

/***********************************************************************
 * TODO_6: Generate a complete valid board.
 ***********************************************************************/

bool generate_board(char grid[][9]) {
	/// ADD YOUR CODE HERE
}

/***********************************************************************
 * TODO_7: Generate a Sudoku puzzle with unique solution.
 ***********************************************************************/

void generate_unique_puzzle(char grid[][9]) {			
	/// ADD YOUR CODE HERE
}
