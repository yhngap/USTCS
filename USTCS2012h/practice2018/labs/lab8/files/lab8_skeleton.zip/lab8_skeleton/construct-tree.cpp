#include <iostream>
#include <vector>
#include <iterator>   // For ostream_iteartor
#include <algorithm>  // For find and copy algorithm
#include "btree.h"
using namespace std;

/*
   A function template to construct a unique binary tree based on
   inorder and preorder traversal sequences.
*/
template <typename Iterator, typename T = char>
BTnode<T>* buildTreeInPre(Iterator inStart, Iterator inEnd,
                          Iterator preStart, Iterator preEnd, Iterator* preIndex)
{ 
  /* YOUR IMPLEMENTATION HERE */
} 

/*
   A function template to construct a unique binary tree based on
   inorder and postorder traversal sequences.
*/
template <typename Iterator, typename T = char>
BTnode<T>* buildTreeInPost(Iterator inStart, Iterator inEnd,
                           Iterator postStart, Iterator postEnd, Iterator* postIndex)
{ 
  /* YOUR IMPLEMENTATION HERE */  
} 

/*
   A function template to print a binary tree rotated -90 degrees.
*/
template <typename T>
void print(BTnode<T>* root, int depth)
{
  if(!root) return;
  print(root->get_right(), depth + 1);
  for(int j = 0; j < depth; ++j)
    cout << '\t';
  cout << root->get_data() << endl;
  print(root->get_left(), depth + 1);
}

template <typename T>
void print_data(BTnode<T>* root)
{
  cout << root->get_data() << " ";
}

/*
   A function template to print node data of a binary tree.
*/
template <typename T>
void print(BTnode<T>* root)
{
  print(root, 0);
}

/*
   An overloaded operator<< to print the data in a vector container.
*/
template <typename T>
ostream& operator<< (ostream& os, const vector<T>& v)
{
  if ( !v.empty() ) {
    os << '[';
    copy(v.begin(), v.end(), ostream_iterator<T>(os, ", "));
    os << "\b\b]";
  }
  return os;
}

int main()
{
  /* Containers of inorder, preorder and postorder traversal sequences */ 
  vector<char> in { 'G', 'D', 'H', 'B', 'E', 'I', 'A', 'F', 'J', 'C' };
  vector<char> pre { 'A', 'B', 'D', 'G', 'H', 'E', 'I', 'C', 'F', 'J' };
  vector<char> post { 'G', 'H', 'D', 'I', 'E', 'B', 'J', 'F', 'C', 'A' };

  vector<char>::iterator preIndex = pre.begin();
  BTnode<char>* rootInPre = buildTreeInPre(in.begin(), in.end(), pre.begin(), pre.end(), &preIndex);  
  
  cout << "-----------------------------------------------------------------------------" << endl;
  cout << " Construct unique binary tree using inorder and preorder traversal sequences " << endl;
  cout << "-----------------------------------------------------------------------------" << endl;
  cout << endl;
  cout << "--- Input ---" << endl << endl;
  cout << "Inorder: " << in << endl;  
  cout << "Preorder: " << pre << endl;
  cout << endl;

  /* Print the constructed tree */
  cout << "--- Constructed Tree ---" << endl << endl;
  print(rootInPre);
  cout << endl;

  /* Print inorder and preorder traversal sequences of the constructed tree */
  cout << "Inorder traversal of the constructed tree is ";
  btree_inorder(rootInPre, print_data);
  cout << endl;
  cout << "Preorder traversal of the constructed tree is ";
  btree_preorder(rootInPre, print_data);
  cout << endl << endl;
  
  delete rootInPre;

  // ====

  vector<char>::iterator postIndex = post.end() - 1;
  BTnode<char>* rootInPost = buildTreeInPost(in.begin(), in.end(), post.begin(), post.end(), &postIndex);

  cout << endl << endl;
  cout << "------------------------------------------------------------------------------" << endl;
  cout << " Construct unique binary tree using inorder and postorder traversal sequences " << endl;
  cout << "------------------------------------------------------------------------------" << endl;
  cout << endl;
  cout << "--- Input ---" << endl << endl;
  cout << "Inorder: " << in << endl;  
  cout << "Postorder: " << post << endl;
  cout << endl;

  /* Print the constructed tree */
  cout << "--- Constructed Tree ---" << endl << endl;
  print(rootInPost);
  cout << endl;

  /* Print inorder and postorder traversal sequences of the constructed tree */
  cout << "Inorder traversal of the constructed tree is ";
  btree_inorder(rootInPost, print_data);
  cout << endl;
  cout << "Postorder traversal of the constructed tree is ";
  btree_postorder(rootInPost, print_data);
  cout << endl << endl;
  
  delete rootInPost;
}
