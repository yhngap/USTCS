#include "componentmanager.h"

componentManager::componentManager()
{

}
