#include <Components/resistor.h>

#include <string>

#include <QDebug>

Resistor::Resistor(const std::string &name, Impl *hostImpl, QWidget *parent, double value)
    : CircuitComponent(name, hostImpl, parent)
{
    setImage(Helper::getImagePath("Resistance"));
    setR(value);
}

std::string
Resistor::getType()
{
    return "Resistance";
}

void
Resistor::displayInfo()
{
    // TODO: display V, I and R
}
