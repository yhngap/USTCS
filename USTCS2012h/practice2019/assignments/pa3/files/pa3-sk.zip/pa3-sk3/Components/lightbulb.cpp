#include <Components/lightbulb.h>

#include <string>

LightBulb::LightBulb(const std::string &name, Impl *hostImpl, QWidget *parent)
    : CircuitComponent(name, hostImpl, parent)
{
    setImage(Helper::getImagePath("LightBulb"));
    setR(10);
}

std::string
LightBulb::getType()
{
    return "LightBulb";
}

void
LightBulb::setI(double I_)
{
    CircuitComponent::setI(I_);

    if (I_ < 0.1) {
        setImage(Helper::getImagePath("LightBulb", 0));
    }
    // TODO: set the image of the lightbulb for other illumination level
}

void
LightBulb::displayInfo()
{
    // TODO: display V, I and R
}
