#include "ProcessQueue.h"

#include <iostream>
using std::cout;
using std::endl;

ProcessQueue::ProcessQueue() : sentinel{new ProcessNode{}} {
	sentinel->prev = sentinel->next = sentinel; // Need to do this on a separate line, otherwise sentinel doesn't exist yet to point to itself.
}

ProcessQueue::~ProcessQueue() {
	for (ProcessNode* current_node{sentinel->next}; current_node != sentinel; current_node = current_node->next, delete current_node->prev) {}
	delete sentinel;
}

void ProcessQueue::print() const {
	cout << "================================================================================" << endl;
	if (is_empty()) {
		cout << "This ProcessQueue is empty." << endl;
	}
	else {
		for (ProcessNode* current_node{sentinel->next}; current_node != sentinel->prev; current_node = current_node->next) {
			current_node->process->print();
			cout << "--------------------------------------------------------------------------------" << endl;
		}
		sentinel->prev->process->print();
	}
	cout << "================================================================================" << endl;
}

ProcessQueue* ProcessQueue::perform_aging(unsigned int time, const unsigned int aging_threshold) {
	ProcessQueue* process_queue{new ProcessQueue{}};
	for (ProcessNode* current_node{sentinel->next}; current_node != sentinel; current_node = current_node->next) {
		current_node->process->wait(time);
		if (current_node->process->get_aging_counter() >= aging_threshold) {
			current_node->process->promote_priority();
			current_node = current_node->prev;
			process_queue->enqueue(remove(current_node->next));
		}
	}
	return process_queue;
}

void ProcessQueue::merge_back(ProcessQueue* process_queue) {
	while (!process_queue->is_empty()) {
		enqueue(process_queue->dequeue());
	}
	delete process_queue;
}

void ProcessQueue::enqueue(Process* process) {
	sentinel->prev->next = new ProcessNode{process, sentinel, sentinel->prev};
	sentinel->prev = sentinel->prev->next;
}

Process* ProcessQueue::dequeue() { return remove(sentinel->next); }

bool ProcessQueue::is_empty() const { return sentinel->next == sentinel; }

// Be very careful when deleting the ProcessNode, don't accidentally delete the Process that we actually want to extract and return.
Process* ProcessQueue::remove(ProcessNode* process_node) {
	if (process_node == sentinel) { return nullptr; }

	process_node->prev->next = process_node->next;
	process_node->next->prev = process_node->prev;
	Process* process{process_node->process};
	process_node->process = nullptr;
	delete process_node;
	return process;
}
