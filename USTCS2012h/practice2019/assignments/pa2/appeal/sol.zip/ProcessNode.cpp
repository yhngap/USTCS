#include "ProcessNode.h"

ProcessNode::ProcessNode() {}

ProcessNode::ProcessNode(Process* process, ProcessNode* next, ProcessNode* prev) : process{process}, next{next}, prev{prev} {}

ProcessNode::~ProcessNode() { delete process; }
