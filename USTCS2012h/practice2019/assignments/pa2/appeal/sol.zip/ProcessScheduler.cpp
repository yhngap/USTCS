#include "ProcessScheduler.h"

#include <iostream>
using std::cout;
using std::endl;

ProcessScheduler::ProcessScheduler(const unsigned int quantum_threshold, const unsigned int max_priority, const unsigned int aging_threshold)
	: quantum_threshold{quantum_threshold}, max_priority{max_priority}, aging_threshold{aging_threshold}, priority_queues{new ProcessQueue[max_priority + 1]} {
}

ProcessScheduler::~ProcessScheduler() {
	delete current_process;
	delete[] priority_queues;
}

void ProcessScheduler::print() const {
	cout << "################################################################################" << endl;

	cout << "Scheduler Configuration: \n"
			<< "* Quantum Threshold: " << quantum_threshold << "\n"
			<< "* Max Priority: " << max_priority << "\n"
			<< "* Aging Threshold: " << aging_threshold << "\n"
			<< endl;

	cout << "State: \n"
			<< "* Quantum Counter: " << quantum_counter << "\n"
			<< "* Next Process ID: " << next_pid << "\n"
			<< endl;

	cout << "Current Process: ";
	if (has_current_process()) {
		cout << "\n----------------------------------------\n";
		current_process->print();
		cout << "----------------------------------------" << endl;
	}
	else {
		cout << "N/A" << endl;
	}

	for (unsigned int i{max_priority + 1}; i > 0; --i) {
		cout << endl;
		cout << "Priority Queue " << i - 1 << ": \n";
		priority_queues[i - 1].print();

	}
	cout << "################################################################################" << endl;
}

bool ProcessScheduler::has_current_process() const { return current_process != nullptr; }

// Swap out Current Process and reset the quantum_counter, if no Current Process or the newly added Process has higher priority.
void ProcessScheduler::add_process(unsigned int execute_time, unsigned int priority) {
	Process* new_process{new Process{next_pid, execute_time, priority}};
	if (has_current_process()) {
		if (new_process->get_priority() > current_process->get_priority()) {
			priority_queues[current_process->get_priority()].enqueue(current_process);
			current_process = new_process;
			quantum_counter = 0;
		}
		else {
			priority_queues[new_process->get_priority()].enqueue(new_process);
		}
	}
	else {
		current_process = new_process;
	}
	next_pid += 1;
}

/*
 * Simulate 1ms at a time.
 * First execute Current Process and tick-up Quantum Counter (if Quantum Threshold is zero, ignore Quantum Counter steps),
 * Delete Current Process and reset Quantum Counter if it has finished execution,
 * Then perform Aging (if Aging Threshold is zero, ignore Aging steps),
 * Swap to next highest priority Process if Current Process has finished execution,
 * Otherwise, swap out Current Process and reset Quantum Counter, if have a higher priority Process or reached/exceeded Quantum Threshold.
 * Repeat for every ms.
 * Do nothing if no Process to execute.
 */
void ProcessScheduler::simulate(unsigned int time) {
	if (!has_current_process()) { return; } // Do nothing if no Process to execute.

	for (unsigned int t{0}; t < time; ++t) {
		// Execute Current Process. Tick-up Quantum Counter if Quantum Threshold is not zero.
		current_process->execute(1);
		if (quantum_threshold > 0) {
			quantum_counter += 1;
		}

		// Delete Current Process and reset Quantum Counter if it has finished execution.
		if (current_process->get_execute_time() <= 0) {
			delete current_process;
			current_process = nullptr;
			quantum_counter = 0;
		}

		// Perform Aging if Aging Threshold is not zero.
		if (aging_threshold > 0) {
			for (unsigned int i{max_priority}; i > 0; --i) {
				priority_queues[i].merge_back(priority_queues[i - 1].perform_aging(1, aging_threshold));
			}
		}

		// Swap to next highest priority Process if Current Process has finished executing.
		if (!has_current_process()) {
			for (unsigned int i{max_priority + 1}; i > 0; i--) {
				if (!priority_queues[i - 1].is_empty()) {
					current_process = priority_queues[i - 1].dequeue();
					current_process->reset_aging_counter();
					quantum_counter = 0;
					break;
				}
			}

			// If no more Processes, stop simulation.
			if (!has_current_process()) {
				return;
			}
		}
		// Otherwise, swap out Current Process if have a higher priority Process or reached Quantum Threshold.
		else {
			// Check if have higher priority Process.
			for (unsigned int i{max_priority}; i > current_process->get_priority(); i--) {
				if (!priority_queues[i].is_empty()) {
					priority_queues[current_process->get_priority()].enqueue(current_process);
					current_process = priority_queues[i].dequeue();
					current_process->reset_aging_counter();
					quantum_counter = 0;
					break;
				}
			}

			// Check if Quantum Counter reached Quantum Threshold, but only if Quantum Threshold is not zero.
			if ((quantum_threshold > 0) && (quantum_counter >= quantum_threshold)) {
				priority_queues[current_process->get_priority()].enqueue(current_process);
				current_process = priority_queues[current_process->get_priority()].dequeue();
				current_process->reset_aging_counter();
				quantum_counter = 0;
			}
		}
	}
}
