#include <random>
using std::default_random_engine;
using std::uniform_int_distribution;

#include "ProcessScheduler.h"

int main() {
	default_random_engine generator;
	uniform_int_distribution<unsigned int> execute_time_distribution{100, 10000};
	uniform_int_distribution<unsigned int> priority_distribution{0, 31};

	ProcessScheduler* memory_leak_tester = new ProcessScheduler{1000000, 31, 1000000};

	for (unsigned int i{0}; i < 1024; ++i) {
		unsigned int execute_time = execute_time_distribution(generator);
		unsigned int priority = priority_distribution(generator);

		memory_leak_tester->add_process(execute_time, priority);
	}

	delete memory_leak_tester;

	return 0;
}
