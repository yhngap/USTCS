#include "catch.hpp"

#include <iostream>
#include <sstream>
#include <string>
using std::cout;
using std::stringstream;
using std::string;

#include <random>
using std::default_random_engine;
using std::uniform_int_distribution;

#include "ProcessScheduler.h"
#include "ProcessSchedulerGrader.h"

TEST_CASE("Process") {
	Process process{1000, 1000, 1000};

	SECTION("get_pid()") {
		CHECK(process.get_pid() == 1000);
	}

	SECTION("execute()") {
		CHECK(process.get_execute_time() == 1000);
		process.execute(1);
		CHECK(process.get_execute_time() == 999);
	}

	SECTION("wait() and reset_aging_counter()") {
		CHECK(process.get_aging_counter() == 0);
		process.wait(1);
		CHECK(process.get_aging_counter() == 1);
		process.reset_aging_counter();
		CHECK(process.get_aging_counter() == 0);
	}

	SECTION("promote_priority()") {
		CHECK(process.get_priority() == 1000);
		process.promote_priority();
		CHECK(process.get_priority() == 1001);
	}
}

TEST_CASE("ProcessQueue enqueue() and dequeue()") {
	ProcessQueue processQueue;
	Process* process1{new Process{1, 1, 1}};
	Process* process2{new Process{2, 2, 2}};
	Process* process3{new Process{3, 3, 3}};

	processQueue.enqueue(process2);
	processQueue.enqueue(process1);
	processQueue.enqueue(process3);

	Process* process2_dequeue = processQueue.dequeue();
	Process* process1_dequeue = processQueue.dequeue();
	Process* process3_dequeue = processQueue.dequeue();

	CHECK(process2_dequeue == process2);
	CHECK(process1_dequeue == process1);
	CHECK(process3_dequeue == process3);

	// Lenient memory management here to reduce crashing. Check for memory leak separately with Dr Memory.
	//delete process1;
	//delete process2;
	//delete process3;
}

TEST_CASE("ProcessQueue is_empty()") {
	ProcessQueue processQueue;
	Process* process1{new Process{1, 1, 1}};
	CHECK(processQueue.is_empty() == true);
	processQueue.enqueue(process1);
	CHECK(processQueue.is_empty() == false);
	processQueue.dequeue();
	CHECK(processQueue.is_empty() == true);
	//delete process1;
}

TEST_CASE("AddProcess1") {
	stringstream ss;
	auto old_buf = cout.rdbuf(ss.rdbuf());
	string tester_output;
	string grader_output;

	ProcessScheduler tester{1000000, 7, 1000000};
	ProcessSchedulerGrader grader{1000000, 7, 1000000};

	SECTION("New Processes added to the back of the correct Priority Queue if not higher priority than Current Process.") {
		for (unsigned int i{0}; i <= 7; ++i) {
			tester.add_process((7-i)*1000 + 101, (7-i));
			tester.add_process((7-i)*1000 + 102, (7-i));
			grader.add_process((7-i)*1000 + 101, (7-i));
			grader.add_process((7-i)*1000 + 102, (7-i));
		}

		tester.print();
		tester_output = ss.str();
		ss.str(string{});
		grader.print();
		grader_output = ss.str();
		ss.str(string{});
		CHECK(tester_output == grader_output);
	}

	cout.rdbuf(old_buf);
}

TEST_CASE("AddProcess2") {
	stringstream ss;
	auto old_buf = cout.rdbuf(ss.rdbuf());
	string tester_output;
	string grader_output;

	ProcessScheduler tester{1000000, 7, 1000000};
	ProcessSchedulerGrader grader{1000000, 7, 1000000};

	SECTION("New Process pushes out Current Process if have higher priority.") {
		for (unsigned int i{0}; i <= 7; ++i) {
			tester.add_process(i*1000 + 100, i);
			grader.add_process(i*1000 + 100, i);
			tester.simulate(1);
			grader.simulate(1);

			tester.print();
			tester_output = ss.str();
			ss.str(string{});
			grader.print();
			grader_output = ss.str();
			ss.str(string{});
			CHECK(tester_output == grader_output);
		}
	}

	cout.rdbuf(old_buf);
}

TEST_CASE("RemoveProcess") {
	stringstream ss;
	auto old_buf = cout.rdbuf(ss.rdbuf());
	string tester_output;
	string grader_output;

	ProcessScheduler tester{1000000, 0, 1000000};
	ProcessSchedulerGrader grader{1000000, 0, 1000000};

	SECTION("Processes that finish execution are removed.") {
		for (unsigned int i{0}; i <= 7; ++i) {
			tester.add_process(i*100 + 100, 0);
			grader.add_process(i*100 + 100, 0);
		}

		tester.print();
		tester_output = ss.str();
		ss.str(string{});
		grader.print();
		grader_output = ss.str();
		ss.str(string{});
		CHECK(tester_output == grader_output);

		for (unsigned int i{0}; i <= 7; ++i) {
			tester.simulate(i*100 + 100);
			grader.simulate(i*100 + 100);

			tester.print();
			tester_output = ss.str();
			ss.str(string{});
			grader.print();
			grader_output = ss.str();
			ss.str(string{});
			CHECK(tester_output == grader_output);
		}
	}

	cout.rdbuf(old_buf);
}

TEST_CASE("Quantum") {
	stringstream ss;
	auto old_buf = cout.rdbuf(ss.rdbuf());
	string tester_output;
	string grader_output;

	ProcessScheduler tester{100, 0, 1000000};
	ProcessSchedulerGrader grader{100, 0, 1000000};

	SECTION("Quantum Counter reaching Quantum Threshold pushes Current Process to the back of its queue.") {
		for (unsigned int i{0}; i <= 7; ++i) {
			tester.add_process(i*100000 + 10000, 0);
			grader.add_process(i*100000 + 10000, 0);
		}

		tester.print();
		tester_output = ss.str();
		ss.str(string{});
		grader.print();
		grader_output = ss.str();
		ss.str(string{});
		CHECK(tester_output == grader_output);

		for (unsigned int i{0}; i < 100; ++i) {
			tester.simulate(100);
			grader.simulate(100);
			tester.print();
			tester_output = ss.str();
			ss.str(string{});
			grader.print();
			grader_output = ss.str();
			ss.str(string{});
			CHECK(tester_output == grader_output);
		}
	}

	cout.rdbuf(old_buf);
}

TEST_CASE("Aging1") {
	stringstream ss;
	auto old_buf = cout.rdbuf(ss.rdbuf());
	string tester_output;
	string grader_output;

	ProcessScheduler tester{1000000, 7, 100};
	ProcessSchedulerGrader grader{1000000, 7, 100};

	SECTION("Processes promote priority when Aging Counter reaches Aging Threshold.") {
		tester.add_process(100000, 7);
		grader.add_process(100000, 7);
		for (unsigned int i{0}; i <= 7; ++i) {
			tester.add_process(i*100000 + 10000, 0);
			grader.add_process(i*100000 + 10000, 0);
		}

		tester.print();
		tester_output = ss.str();
		ss.str(string{});
		grader.print();
		grader_output = ss.str();
		ss.str(string{});
		CHECK(tester_output == grader_output);

		for (unsigned int i{0}; i < 100; ++i) {
			tester.simulate(100);
			grader.simulate(100);
			tester.print();
			tester_output = ss.str();
			ss.str(string{});
			grader.print();
			grader_output = ss.str();
			ss.str(string{});
			CHECK(tester_output == grader_output);
		}
	}

	cout.rdbuf(old_buf);
}

TEST_CASE("Aging2") {
	stringstream ss;
	auto old_buf = cout.rdbuf(ss.rdbuf());
	string tester_output;
	string grader_output;

	ProcessScheduler tester{1000000, 7, 100};
	ProcessSchedulerGrader grader{1000000, 7, 100};

	SECTION("Process with promoted priority pushes out Current Process if have higher priority.") {
		for (unsigned int i{0}; i <= 7; ++i) {
			tester.add_process(i*100000 + 10000, 0);
			grader.add_process(i*100000 + 10000, 0);
		}

		tester.print();
		tester_output = ss.str();
		ss.str(string{});
		grader.print();
		grader_output = ss.str();
		ss.str(string{});
		CHECK(tester_output == grader_output);

		for (unsigned int i{0}; i < 100; ++i) {
			tester.simulate(100);
			grader.simulate(100);
			tester.print();
			tester_output = ss.str();
			ss.str(string{});
			grader.print();
			grader_output = ss.str();
			ss.str(string{});
			CHECK(tester_output == grader_output);
		}
	}

	cout.rdbuf(old_buf);
}

TEST_CASE("Randomized Stress Test") {
	stringstream ss;
	auto old_buf = cout.rdbuf(ss.rdbuf());
	string tester_output;
	string grader_output;

	default_random_engine generator;
	uniform_int_distribution<unsigned int> execute_time_distribution{100, 1000};
	uniform_int_distribution<unsigned int> priority_distribution{0, 31};
	uniform_int_distribution<unsigned int> simulate_interval_distribution{10, 50};

	SECTION("Begin Test") {
		ProcessScheduler tester{100, 31, 1000};
		ProcessSchedulerGrader grader{100, 31, 1000};

		unsigned int total_execute_time{0};
		unsigned int simulate_time_elapsed{0};

		for (unsigned int i{0}; i < 1024; ++i) {
			unsigned int execute_time = execute_time_distribution(generator);
			unsigned int priority = priority_distribution(generator);
			unsigned int simulate_interval = simulate_interval_distribution(generator);

			tester.add_process(execute_time, priority);
			grader.add_process(execute_time, priority);
			total_execute_time += execute_time;

			tester.simulate(simulate_interval);
			grader.simulate(simulate_interval);
			simulate_time_elapsed += simulate_interval;
		}

		tester.print();
		tester_output = ss.str();
		ss.str(string{});
		grader.print();
		grader_output = ss.str();
		ss.str(string{});
		CHECK(tester_output == grader_output);

		unsigned int remaining_time = total_execute_time - simulate_time_elapsed;
		bool early_finish = false;

		while (remaining_time >= 150) {
			if (!tester.has_current_process()) {
				early_finish = true;
				break;
			}
			tester.simulate(100);
			grader.simulate(100);
			remaining_time -= 100;
		}
		CHECK(early_finish == false);

		while (remaining_time > 0) {
			if (!tester.has_current_process()) {
				early_finish = true;
				break;
			}
			tester.simulate(1);
			grader.simulate(1);
			remaining_time -= 1;
		}
		CHECK(early_finish == false);
		CHECK(tester.has_current_process() == false);

		tester.print();
		tester_output = ss.str();
		ss.str(string{});
		grader.print();
		grader_output = ss.str();
		ss.str(string{});
		CHECK(tester_output == grader_output);
	}

	cout.rdbuf(old_buf);
}
