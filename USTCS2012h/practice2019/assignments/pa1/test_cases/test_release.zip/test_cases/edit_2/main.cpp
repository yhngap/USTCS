//
//  COMP 2012H Programming Assignment 1: Go
//  Filename: main.cpp
//

#include <iostream>
#include <cstring>
#include <algorithm>
#include <vector>
#include "Helper.h"
#include "sol_Todo.h"
#include "Todo.h"
#include "grade.h"
using namespace std;

int main() {

    Stone board[19][19];
    initialize_board(board);
    read_partial_board(board, "test_cases/edit_2/board.txt");
    int record[10][2];
    fill(&record[0][0], &record[9][1]+1, false);
    int counter = 0, max_steps = 0;
    int edit_check = edit(board, Black, 0, 0, record, counter, max_steps);

    Stone board_sol[19][19];
    initialize_board(board_sol);
    read_partial_board(board_sol, "test_cases/edit_2/board.txt");
    int record_sol[10][2];
    fill(&record_sol[0][0], &record_sol[9][1]+1, false);
    int counter_sol = 0, max_steps_sol = 0;
    int edit_check_sol = sol::edit(board_sol, Black, 0, 0, record_sol, counter_sol, max_steps_sol);
    
    bool correct = true;
    correct = correct && edit_check==edit_check_sol;
    correct = correct && equal(&board_sol[0][0], &board_sol[18][18]+1, &board[0][0]);
    //correct = correct && equal(&record_sol[0][0], &record_sol[18][18]+1, &record[0][0]);
	//correct = correct && counter == counter_sol;
    //correct = correct && max_steps == max_steps_sol;
    cout << correct;

	return 0;
}