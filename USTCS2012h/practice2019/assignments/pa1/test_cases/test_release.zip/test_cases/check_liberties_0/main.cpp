//
//  COMP 2012H Programming Assignment 1: Go
//  Filename: main.cpp
//

#include <iostream>
#include <cstring>
#include <algorithm>
#include <vector>
#include "Helper.h"
#include "sol_Todo.h"
#include "Todo.h"
#include "grade.h"
using namespace std;

int main() {

    Stone board[19][19];
    initialize_board(board);
    read_partial_board(board, "test_cases/check_liberties_0/board.txt");
    bool connected_part[19][19], liberties[19][19];
    fill(&connected_part[0][0], &connected_part[18][18]+1, false);
    fill(&liberties[0][0], &liberties[18][18]+1, false);
    int num_lib = check_liberties(board, 2, 2, connected_part, liberties);

    Stone board_sol[19][19];
    initialize_board(board_sol);
    read_partial_board(board_sol, "test_cases/check_liberties_0/board.txt");
    bool connected_part_sol[19][19], liberties_sol[19][19];
    fill(&connected_part_sol[0][0], &connected_part_sol[18][18]+1, false);
    fill(&liberties_sol[0][0], &liberties_sol[18][18]+1, false);
    int num_lib_sol = sol::check_liberties(board_sol, 2, 2, connected_part_sol, liberties_sol);
    
    bool correct = true;
    correct = correct && num_lib==num_lib_sol;
    correct = correct && equal(&connected_part_sol[0][0], &connected_part_sol[18][18]+1, &connected_part[0][0]);
    correct = correct && equal(&liberties_sol[0][0], &liberties_sol[18][18]+1, &liberties[0][0]);
	
    cout << correct;

	return 0;
}