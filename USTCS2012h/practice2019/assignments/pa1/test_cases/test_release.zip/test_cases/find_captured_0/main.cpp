//
//  COMP 2012H Programming Assignment 1: Go
//  Filename: main.cpp
//

#include <iostream>
#include <cstring>
#include <algorithm>
#include <vector>
#include "Helper.h"
#include "sol_Todo.h"
#include "Todo.h"
#include "grade.h"
using namespace std;

int main() {

    Stone board[19][19];
    initialize_board(board);
    read_partial_board(board, "test_cases/find_captured_0/board.txt");
    bool captured[19][19];
    fill(&captured[0][0], &captured[18][18]+1, false);
    bool has_captured = find_captured(board, Black, captured);

    Stone board_sol[19][19];
    initialize_board(board_sol);
    read_partial_board(board_sol, "test_cases/find_captured_0/board.txt");
    bool captured_sol[19][19];
    fill(&captured_sol[0][0], &captured_sol[18][18]+1, false);
    int has_captured_sol = sol::find_captured(board_sol, Black, captured_sol);
    
    bool correct = true;
    correct = correct && has_captured==has_captured_sol;
    correct = correct && equal(&captured_sol[0][0], &captured_sol[18][18]+1, &captured[0][0]);
	
    cout << correct;

	return 0;
}