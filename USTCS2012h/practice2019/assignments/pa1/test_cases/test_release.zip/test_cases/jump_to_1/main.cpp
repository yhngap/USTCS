//
//  COMP 2012H Programming Assignment 1: Go
//  Filename: main.cpp
//

#include <iostream>
#include <cstring>
#include <algorithm>
#include <vector>
#include "Helper.h"
#include "sol_Todo.h"
#include "Todo.h"
#include "grade.h"
using namespace std;

int main() {

    Stone board[19][19];
    int counter, max_steps, record[361][2];
    initialize_board(board);
    read_file(board, record, counter, max_steps, "test_cases/jump_to_1/record.txt");
    for (auto& row: board) {
        for (auto& it: row) {
            cout << it;
        }
        cout << endl;
    }
    jump_to(board, 38, record, counter, max_steps);
    cout << endl;
    for (auto& row: board) {
        for (auto& it: row) {
            cout << it;
        }
        cout << endl;
    }

    Stone board_sol[19][19];
    int counter_sol, max_steps_sol, record_sol[361][2];
    initialize_board(board_sol);
    read_file(board_sol, record_sol, counter_sol, max_steps_sol, "test_cases/jump_to_1/record.txt");
    sol::jump_to(board_sol, 38, record_sol, counter_sol, max_steps_sol);

    bool correct = true;
    correct = correct && equal(&board_sol[0][0], &board_sol[18][18], &board[0][0]);
    correct = correct && counter_sol==counter;
    correct = correct && max_steps_sol==max_steps;
    //correct = correct && equal(&record_sol[0][0], &record_sol[max_steps-1][1], &record[0][0]);
	
    cout << correct;

	return 0;
}