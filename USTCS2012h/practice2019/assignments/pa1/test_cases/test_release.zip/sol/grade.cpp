#include <fstream>
#include <iostream>
#include <vector>
#include "grade.h"
#include "sol_Todo.h"

using namespace std;

void read_partial_board(Stone board[][19], string filename) {
    ifstream fin(filename);
    int row, col, cell;
    fin >> row >> col;
    for (int i=0; i<row; i++) {
        for (int j=0; j<col; j++) {
            fin >> cell;
            board[i][j] = Stone(cell);
        }
    }
}

void gen_dummy_record(Stone board[][19], int record[][2], int & counter, int& max_steps) {
    vector<pair<int, int>> sparse[2];
    for (int i=0; i<19; i++) {
        for (int j=0; j<19; j++) {
            if (board[i][j] != Empty) {
                sparse[int(board[i][j]) - 1].push_back(pair<int, int>{i, j});
            }
        }
    }
    vector<pair<int, int>>::iterator iter[2] = {sparse[0].begin(), sparse[1].begin()};
    counter = 0;
    while (iter[0]!=sparse[0].end() || iter[1]!=sparse[1].end()) {
        int curr = counter % 2;
        record[counter][0] = iter[curr]!=sparse[curr].end() ? iter[curr]->first : -1;
        record[counter][1] = iter[curr]!=sparse[curr].end() ? iter[curr]->second : -1;
        counter++;
        if (iter[curr]!=sparse[curr].end()) iter[curr]++;
    }
    max_steps = counter;
}
