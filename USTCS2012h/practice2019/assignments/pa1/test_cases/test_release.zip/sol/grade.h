#ifndef GRADE_H
#define GRADE_H

#include <string>
#include "sol_Todo.h"

void read_partial_board(Stone board[][19], std::string filename);
void gen_dummy_record(Stone board[][19], int record[][2], int & counter, int& max_steps);

#endif /* GRADE_H */