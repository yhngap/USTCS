#include "linked_list.h"

using namespace std;

// TODO
LinkedList::LinkedList() {
}

// TODO
LinkedList::~LinkedList() {
}

// TODO
void LinkedList::insert(Node* prev, Node* ins) {
}

// TODO
void LinkedList::remove(Node* prev, Node* del) {
}
