#include "course.h"

#include <iostream>

using namespace std;

// TODO
Course::Course(const string &courseName, int quota)
{
}

Course::~Course()
{
    cout << courseName << " : "
        << "Enrolled " << getEnrolled()
        << ", Waitlisted " << getWaitlisted()
        << endl;
}

// TODO
string Course::enroll(const string &studentName)
{
    return "Existed";
}

// TODO
string Course::drop(const string &studentName)
{
    return "Not existed";
}

// TODO
int Course::getWaitlisted()
{
    return 0;
}

// TODO
int Course::getEnrolled()
{
    return 0;
}

// TODO
string Course::queryStatus(const string &studentName)
{
    return "Not existed";
}
