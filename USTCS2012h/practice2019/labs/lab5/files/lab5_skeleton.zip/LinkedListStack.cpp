#include "LinkedListStack.h"

// TODO
LinkedListStack::LinkedListStack() {}

// TODO
LinkedListStack::LinkedListStack(const LinkedListStack& linkedListStack) /* : */ {}

LinkedListStack& LinkedListStack::operator=(const LinkedListStack& rhs) {
	return *this; // TODO
}

// TODO
LinkedListStack::~LinkedListStack() {}

const UselessDataObject& LinkedListStack::peek() const {
	return UselessDataObject{}; // TODO
}

void LinkedListStack::insertElement(const UselessDataObject& element) {
	// TODO
}

UselessDataObject LinkedListStack::removeElement() {
	return UselessDataObject{}; // TODO
}

void LinkedListStack::removeAll(UselessDataObject data[]) {
	// TODO
}
