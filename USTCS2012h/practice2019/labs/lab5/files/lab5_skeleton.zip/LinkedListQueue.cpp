#include "LinkedListQueue.h"

LinkedListQueue::LinkedListQueue() {}

LinkedListQueue::LinkedListQueue(const LinkedListQueue& linkedListQueue) : LinkedListAbstractSequentialContainer(linkedListQueue) {}

LinkedListQueue& LinkedListQueue::operator=(const LinkedListQueue& rhs) {
	this->LinkedListAbstractSequentialContainer::operator=(rhs);
	return *this;
}

LinkedListQueue::~LinkedListQueue() {}

const UselessDataObject& LinkedListQueue::peek() const {
	return UselessDataObject{}; // TODO
}

void LinkedListQueue::insertElement(const UselessDataObject& element) {
	// TODO
}

UselessDataObject LinkedListQueue::removeElement() {
	return UselessDataObject{}; // TODO
}

void LinkedListQueue::removeAll(UselessDataObject data[]) {
	// TODO
}
