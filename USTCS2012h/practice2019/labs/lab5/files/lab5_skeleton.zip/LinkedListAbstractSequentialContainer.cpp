#include "LinkedListAbstractSequentialContainer.h"

/*******************************************************
 * Constructors, Destructors, and Assignment Operators *
 *******************************************************/

// TODO
LinkedListAbstractSequentialContainer::LinkedListAbstractSequentialContainer() /* : */ {

}

// TODO
LinkedListAbstractSequentialContainer::LinkedListAbstractSequentialContainer(const LinkedListAbstractSequentialContainer& linkedListAbstractContainer) /* : */ {

}

LinkedListAbstractSequentialContainer& LinkedListAbstractSequentialContainer::operator=(const LinkedListAbstractSequentialContainer& rhs) {
	if (this == &rhs) { return *this; }

	// TODO

	return *this;
}

LinkedListAbstractSequentialContainer::~LinkedListAbstractSequentialContainer() {
	// TODO
}



/*******************************************
 * Abstract Sequential Container Overrides *
 *******************************************/

void LinkedListAbstractSequentialContainer::print(ostream& out) const {
	for (LinkedListNode* current{sentinel->next}; current != sentinel; current = current->next) {
		out << current->data << " ";
	}
}

bool LinkedListAbstractSequentialContainer::isEmpty() const {
	return true; // TODO
}

unsigned int LinkedListAbstractSequentialContainer::getNumElements() const {
	return 0; // TODO
}



/***********************************
 * Linked List Protected Functions *
 ***********************************/

// Return sentinel garbage data if index out-of-range.
const UselessDataObject& LinkedListAbstractSequentialContainer::getElementAtIndex(unsigned int index) const {
	return UselessDataObject{}; // TODO
}

// Do nothing if index out-of-range.
void LinkedListAbstractSequentialContainer::insertAtIndex(const UselessDataObject& element, unsigned int index) {
	// TODO
}

// Don't remove any node, and return sentinel garbage data, if index out-of-range.
UselessDataObject LinkedListAbstractSequentialContainer::removeAtIndex(unsigned int index) {
	return UselessDataObject{}; // TODO
}



/*********************************
 * Linked List Private Functions *
 *********************************/

// Return sentinel if index out-of-range.
LinkedListAbstractSequentialContainer::LinkedListNode* LinkedListAbstractSequentialContainer::getNodeAtIndex(unsigned int index) const {
	return nullptr; // TODO
}
