#ifndef LAMP_H
#define LAMP_H
// object declarations, class definitions, functions
#endif  // LAMP_H
