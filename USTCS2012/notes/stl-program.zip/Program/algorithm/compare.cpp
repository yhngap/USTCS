int Compare_Integer(int* i, int* j) { return((*i) - (*j)); } /* File: compare.cpp */
