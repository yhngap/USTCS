// Create a Greater_Than temporary function object g
Greater_Than g(350); // a temporary object
p = find_if( x.begin(), x.end(), g );
