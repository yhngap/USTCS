/* File: apple-utils.h */
class Stack      { /* incomplete */ };
class Some_Class { /* incomplete */ };
void safari()    { cout << "Apple's browser" << endl; };
void app(int x)  { cout << "Apple's app: " << x << endl; };
