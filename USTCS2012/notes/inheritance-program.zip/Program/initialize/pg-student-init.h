PG_Student::PG_Student(string n, Department d, float x) :
    Student(n, d, x), research_topic("") { }
