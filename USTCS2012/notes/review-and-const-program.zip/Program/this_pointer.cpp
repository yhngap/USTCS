void Person::have_child(Person* this, Person* baby)
{
    this->_child = baby;
}
