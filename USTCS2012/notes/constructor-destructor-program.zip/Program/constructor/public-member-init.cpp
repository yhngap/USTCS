class Word              /* File: public-member-init.cpp */
{
  public:
    int frequency;
    const char* str;
};

int main() { Word movie = {1, "Titanic"}; }
