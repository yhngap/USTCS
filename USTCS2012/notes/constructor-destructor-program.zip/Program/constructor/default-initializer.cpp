class Word              /* File: default-initializer.cpp */
{   // Implicitly private members
    int frequency {0};
    const char* str {nullptr};
};

int main() { Word movie; }
