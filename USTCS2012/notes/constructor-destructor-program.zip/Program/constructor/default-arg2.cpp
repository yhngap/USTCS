void download(char* program, char os = LINUX, char format = BINARY);
void download(char os = LINUX, char* program, char format = BINARY);
