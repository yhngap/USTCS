class Word  // File: word.h
{
    ...
  public: 
    Word(const char* s, int k = 1);
}
