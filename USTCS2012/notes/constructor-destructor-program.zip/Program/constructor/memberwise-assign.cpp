Word x("Titanic", 1);	// Word(const char*, int) constructor
Word y;			// Word() constructor
y = x;			// default memberwise assignment
