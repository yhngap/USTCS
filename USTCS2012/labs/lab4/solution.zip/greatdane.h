#ifndef __GREATDANE_H__
#define __GREATDANE_H__

#include "dog.h"

class GreatDane : public Dog
{
public:
    GreatDane(string name);
    void bark() const;
};

#endif // __GREATDANE_H__