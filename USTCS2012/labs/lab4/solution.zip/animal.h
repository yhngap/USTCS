#ifndef __ANIMAL_H__
#define __ANIMAL_H__

#include <string>
using std::string; //declare that string is under the std namespace

class Animal
{
public:
    Animal(string name);
    void talk() const;
    void eat() const;
    string getName() const;
private:
    string name;
};

#endif // __ANIMAL_H__