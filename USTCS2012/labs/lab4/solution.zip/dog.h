#ifndef __DOG_H__
#define __DOG_H__

#include "animal.h"

class Dog : public Animal
{
public:
    Dog(string name) ;
    // Dog(const char* c):Animal("hi") {};
    void talk() const;
    void eat() const;
    void bark() const;
};

#endif // __DOG_H__