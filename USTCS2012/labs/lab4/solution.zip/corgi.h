#ifndef __CORGI_H__
#define __CORGI_H__

#include "dog.h"

class Corgi : public Dog
{
public:
    Corgi(string name);
    void bark() const;
};


#endif // __CORGI_H__