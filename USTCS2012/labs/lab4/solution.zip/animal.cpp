
#include "animal.h"
#include <iostream>
using namespace std;

Animal::Animal(string name) : name(name)
{
    
}

void Animal::talk() const
{
    cout << "My name is " << name << "! I am just an animal!" << endl;
}

void Animal::eat() const
{
    cout << "I eat something... nom nom nom" << endl;
}

string Animal::getName() const
{
    return name;
}

