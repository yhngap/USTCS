#include "muffin.h"
#include <iostream>
using namespace std;

Muffin::Muffin() {
    cout << "Make Muffin!" << endl << endl;
}
