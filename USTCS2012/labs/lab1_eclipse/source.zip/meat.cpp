#include "meat.h"
#include <iostream>
using namespace std;
Meat::Meat() {
    cout << "Frozen Meat! " << endl;
}
