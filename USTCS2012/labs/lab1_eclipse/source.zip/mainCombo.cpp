#include "burger.h"
#include "chocolate.h"
#include "muffin.h"
#include <iostream>
using namespace std;


int main() {

    cout << "Have a combo! " << endl;

    Burger b;
    Muffin m;
    cout << endl;
    Chocolate c;

    return 0;
}

