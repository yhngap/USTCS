#include "bread.h"
#include "chocolate.h"

class Muffin {
public: 
    Muffin();
private:
    Chocolate c;
    Bread b;

};
