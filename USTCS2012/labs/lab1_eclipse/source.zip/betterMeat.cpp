#include "meat.h"
#include <iostream>
using namespace std;
Meat::Meat() {
    cout << "Fresh Meat! " << endl;
}
