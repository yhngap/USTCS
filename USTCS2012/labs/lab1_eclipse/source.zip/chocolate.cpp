#include "chocolate.h"
#include <iostream>
using namespace std;

Chocolate::Chocolate() {
    cout << "Chocolate!" << endl;
}
