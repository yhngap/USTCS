class Meat {
public:
    Meat();
};
