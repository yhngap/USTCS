#include <iostream>
#include "Vehicle.h"
using namespace std;


//Todo: Conversion constructor


//Todo: Vehicle's destructor



//Todo: Vehicle's getColor


//Todo: Vehicle's getMileage


//Todo: Vehicle's getEngine


void Vehicle::start() {
	cout << "Vehicle with ";
	Start();
}

//Todo: Vehicle's brake(int distance) use Engine's Stop();


//Todo: Vehicle's print()
