/*
* Engine.cpp
*/

#include <iostream>
#include "Engine.h"
using namespace std;

//Todo: Conversion constructor



//Todo: getNumCylinder() return number of cylinders in the engine


//Start the engine
void Engine::Start(){
	cout << getNumCylinder() << "-cylinder engine started." << endl;
}

//Stop the engine
void Engine::Stop(){
	cout << getNumCylinder() << "-cylinder engine stopped." << endl;
}

