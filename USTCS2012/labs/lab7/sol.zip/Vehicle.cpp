#include <iostream>
#include "Vehicle.h"
using namespace std;


//Todo: Conversion constructor
Vehicle::Vehicle(int nc, Color in_color, int in_mileage): Engine(nc), color(in_color), mileage(in_mileage) {}

//Todo: Vehicle's destructor

Vehicle::~Vehicle() {
	cout << "\nCalling Vehicle's destructor on the following vehicle:" << endl;
	print();
}

//Todo: Vehicle's getColor

Color Vehicle::getColor() const {
	return color;
}

//Todo: Vehicle's getMileage
int Vehicle::getMileage() const {
	return mileage;
}


//Todo: Vehicle's getEngine

int Vehicle::getEngine() const {
	return getNumCylinder();
}


void Vehicle::start() {
	cout << "Vehicle with ";
	Start();
}

//Todo: Vehicle's brake(int distance) use Engine's Stop();

void Vehicle::brake(int distance) {
	mileage += distance;
	cout << "Vehicle with ";
	Stop();
	cout << "Driving distance: " << distance << endl;
}


//Todo: Vehicle's print()

void Vehicle::print() const
{
    char map[][10] = { "Black", "White", "Silver", "Grey", "Red", "Blue" };
    cout << "Engine: " << getNumCylinder()
         << "   Color: " << map[color]
         << "   Current Miles: " << mileage << endl;
}