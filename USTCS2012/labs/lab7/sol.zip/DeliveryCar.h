
#ifndef DELIVERYCAR_H_
#define DELIVERYCAR_H_

#include "Vehicle.h"

class DeliveryCar : protected Vehicle
{
public:
	DeliveryCar(int nc, Color c, int m, int charge);
	~DeliveryCar();

	void setChargePerMile(int charge);
	int getChargePerMile() const;

	void start();
	void brake(int distance);
    virtual void print() const override;


private:
	int chargePerMile;
};




#endif /* DELIVERYCAR_H_ */
