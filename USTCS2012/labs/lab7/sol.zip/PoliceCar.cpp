
#include <iostream>
#include "PoliceCar.h"
using namespace std;

//Constructor
PoliceCar::PoliceCar(int nc, Color c, int m, bool action): Vehicle(nc,c,m), inAction(action) {}

//Destructor
PoliceCar::~PoliceCar(){
	cout << "\nCalling PoliceCar's destructor on the following police car:" << endl;
	print();
}
void PoliceCar::setInAction(bool action){
	inAction = action;
}

bool PoliceCar::getInAction() const {
	return inAction;
}

void PoliceCar::print() const {
	cout << "Information of the police car:" << endl;
    Vehicle::print();
	if (inAction)
		cout << "PoliceCar's state: in action." << endl;
	else
		cout << "PoliceCar's state: not in action" << endl;
}

