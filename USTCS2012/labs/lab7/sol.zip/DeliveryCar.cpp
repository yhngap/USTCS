#include <iostream>
#include "DeliveryCar.h"
using namespace std;

DeliveryCar::DeliveryCar(int nc, Color c, int m, int charge): Vehicle(nc, c, m), chargePerMile(charge) {}
DeliveryCar::~DeliveryCar(){
	cout << "\nCalling DeliveryCar's destructor on the following delivery car:" << endl;
	print();
}

void DeliveryCar::start(){
	Vehicle::start();
}

void DeliveryCar::brake(int distance){
	Vehicle::brake(distance);
}

void DeliveryCar::setChargePerMile(int charge){
	chargePerMile = charge;
}

int DeliveryCar::getChargePerMile() const {
	return chargePerMile;
}

void DeliveryCar::print() const {
	cout << "Information of the delivery car:" << endl;
	Vehicle::print();
	cout << "DeliveryCar's charges per mile: " << chargePerMile << endl;
	cout << "DeliveryCar's calculated charges: " << getMileage()*chargePerMile << endl;
}
