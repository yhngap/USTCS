#include "burger.h"

int main() {

    Burger b;

    return 0;
}
