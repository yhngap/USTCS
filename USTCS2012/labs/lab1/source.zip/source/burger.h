#include "meat.h"
#include "bread.h"

class Burger {
public:
    Burger();
    ~Burger();
private:
    Bread* b;
    Meat* m;
};
