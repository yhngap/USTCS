
class Chocolate {
public:
    Chocolate();
};
