#include "bread.h"
#include <iostream>
using namespace std;
Bread::Bread() {
    cout << "Bread!" << endl;

}
