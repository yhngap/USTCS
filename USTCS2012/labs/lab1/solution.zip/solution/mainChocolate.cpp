#include "chocolate.h"

int main() {
    Chocolate c;
    return 0;
}
