#ifndef CHOCOLATE_H
#define CHOCOLATE_H
using namespace std;

class Chocolate {
public:
    Chocolate();
};
#endif
