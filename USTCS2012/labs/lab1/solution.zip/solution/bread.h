#ifndef BREAD_H
#define BREAD_H
class Bread {
public:
    Bread();
};

#endif
