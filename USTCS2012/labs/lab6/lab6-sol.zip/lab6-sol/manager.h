#ifndef MANAGER_H
#define MANAGER_H

#include "employee.h"

const int MAX_NUM_STAFF = 5;

class Manager : public Employee {
public:
	Manager(const char* name, int base_salary);

	~Manager();

	virtual void print_description() const override;

	virtual void print_salary() const override;

	void hire(Employee *new_staff,int type);

	void pay_salary() const;

private:
	Employee *staff[MAX_NUM_STAFF];
	int num_staff;

	int base_salary;
	int num_cook;
	int num_deliverymen;
};

#endif