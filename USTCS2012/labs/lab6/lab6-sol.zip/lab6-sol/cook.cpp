#include <iostream>

#include "cook.h"

using namespace std;

Cook::Cook(const char* name, int hourly_wage, int hours_worked) :
Employee(name), hourly_wage(hourly_wage), hours_worked(hours_worked)
{

}

Cook::~Cook()
{
	cout << "Cook Dtor" << endl;
}

void Cook::print_description() const 
{
	Employee::print_description();
	cout << " Duty: Cook" << endl;
}

void Cook::print_salary() const
{
	int salary = hours_worked * hourly_wage;

	cout << "Salary: " << salary << endl;
}