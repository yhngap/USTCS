#include <iostream>

#include "DeliveryMen.h"

using namespace std;

DeliveryMen::DeliveryMen(const char* name, int order_wage, int orders_worked) :
Employee(name), order_wage(order_wage), orders_worked(orders_worked)
{

}

DeliveryMen::~DeliveryMen()
{
	cout << "DeliveryMen Dtor" << endl;
}

void DeliveryMen::print_description() const 
{
	Employee::print_description();
	cout << " Duty: DeliveryMen" << endl;
}

void DeliveryMen::print_salary() const
{
	int salary = order_wage * orders_worked;

	cout << "Salary: " << salary << endl;
}