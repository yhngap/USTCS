#ifndef COOK_H
#define COOK_H

#include "employee.h"

class Cook : public Employee {
public:
	Cook(const char* name, int hourly_wage, int hours_worked);

	~Cook();

	virtual void print_description() const override;

	virtual void print_salary() const override;

private:
	int hourly_wage;
	int hours_worked;
};

#endif