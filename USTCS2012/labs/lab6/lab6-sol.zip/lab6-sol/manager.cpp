#include <iostream>

#include "manager.h"

using namespace std;

Manager::Manager(const char* name, int base_salary) :
Employee(name), base_salary(base_salary), num_staff(0), num_cook(0), num_deliverymen(0)
{

}

Manager::~Manager()
{
	for (int i = 0; i < num_staff; ++i) {
		delete staff[i];
	}

	cout << "Manager Dtor" << endl;
}

void Manager::print_description() const
{
	Employee::print_description();
	cout << " Duty: Manager" << endl;
}

void Manager::print_salary() const
{
	int salary = base_salary + 100*num_cook + 50*num_deliverymen;

	cout << "Salary: " << salary << endl;
}

void Manager::hire(Employee *new_staff, int type)
{
	staff[num_staff++] = new_staff;

	if (type == 1){
		num_cook++;
	}
	if (type == 2){
		num_deliverymen++;
	}

}

void Manager::pay_salary() const
{
	for (int i = 0; i < num_staff; ++i) {
		Employee *e = staff[i];
		e->print_description();
		e->print_salary();
	}
	print_description();
	print_salary();
}