#include <iostream>
#include <cstring>

#include "employee.h"

using namespace std;

Employee::Employee(const char* name)
{
	this->name = new char[strlen(name) + 1];
	strcpy(this->name, name);
}

Employee::~Employee()
{
	cout << "Employee Dtor: "<< name << endl;
	
	delete [] name;
}

void Employee::print_description() const
{
	cout << "Employee: " << name;
}