#ifndef __FATCAT_H__
#define __FATCAT_H__

#include "cat.h"

class FatCat : public Cat
{
public:
    FatCat(string name);
    ~FatCat();
    void eatBigFish();
    void play();
};

#endif // __FATCAT_H__