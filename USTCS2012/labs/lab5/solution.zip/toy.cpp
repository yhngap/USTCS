#include "toy.h"
#include "cat.h"
#include <iostream>
using namespace std;

Toy::Toy(Cat* owner) : owner(owner)
{
    cout << owner->getName() << "'s toy is created." << endl;
}

Toy::~Toy() 
{
    cout << owner->getName() << "'s toy is destroyed." << endl;
}
