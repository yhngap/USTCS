#ifndef __ULTRAFATCAT_H__
#define __ULTRAFATCAT_H__

#include "fatcat.h"

class UltraFatCat : public FatCat
{
public:
    UltraFatCat(string name);
    ~UltraFatCat();
    void eatFishBuffet();
    void play();
};

#endif // __ULTRAFATCAT_H__