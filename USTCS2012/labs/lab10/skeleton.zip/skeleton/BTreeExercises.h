//
// Operations on Binary Tree
//

#ifndef BTREEEXERCISES_H
#define BTREEEXERCISES_H

#include <iostream>
#include <queue>
#include "BtreeNode.h"
using namespace std;

template<class T>
int tree_height(BtreeNode<T> *root);

template<class T>
int count_nodes(BtreeNode<T> *root);

template<class T>
BtreeNode<T> *mirror(BtreeNode<T> *root);

template<class T>
bool is_complete(BtreeNode<T> *root);


template <class T>
BtreeNode<T> *lowest_common_ancestor(BtreeNode<T>* root, const T& a, const T& b);

template <class T>
void test_lowest_common_ancestor_output(BtreeNode<T>* root, const T& a, const T& b);

template <class T>
bool is_bst(BtreeNode<T>* root);


// TODO : Tree Height -> Calculate the height of a binary tree

// TODO : Count Nodes -> Calculate the number of nodes of a binary tree.

// TODO : Mirror -> Create a "new" mirror tree

// TODO : Is Complete -> Check whether a binary tree is complete.

// TODO : lowest_common_ancestor -> Find which is the lowest common ancestor of the two binary tree nodes. 
// The functions is_ancestor_of() may be helpful here.

// TODO : is_bst ->  Check whether a binary tree is also a binary search tree
// The functions find_min() and find_max() may be helpful here.

template <class T>
void
test_lowest_common_ancestor_output(BtreeNode<T>* root, const T& a, const T& b)
{
	BtreeNode<T>* lca = lowest_common_ancestor(root, a, b);
	if (lca)
		cout << "Lowest common ancestor of " << a << " and " << b << " is " << lca->get_data() << endl;
	else
		cout << a << " and " << b << " have no common ancestor" << endl;
}


#endif //BTREEEXERCISES_H
