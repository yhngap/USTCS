//
// Binary Search Tree Class
//

#ifndef BINARYSEARCHTREE_H
#define BINARYSEARCHTREE_H

#include <iostream>
#include <iomanip>

template<typename T1, typename T2>
class BinarySearchTree {
private:
    class BinaryNode;

public:
    BinarySearchTree() : root(NULL) {

    }

    // (Deep) Copy constructor
    BinarySearchTree(const BinarySearchTree &src) : root(src.clone(src.root)) {}

    ~BinarySearchTree() {
        make_empty();
    };

    bool isEmpty() const {
        return !root;
    }

    bool contains(const T1 &x, const T2 &y) const {
        return contains(x, y, root);
    }

    void print_max() const;

    void print_tree() const {
        print_tree(root, 0);
    };

    void make_empty() {
        make_empty(root);
    }

    void insert(const T1 &x, const T2 &y) {
        insert(x, y, root);
    }

private:
    class BinaryNode {
    public:
        T1 x;
        T2 y;
        BinaryNode *left;
        BinaryNode *right;

        BinaryNode() :
                left(NULL), right(NULL) {}

        BinaryNode(const T1 &x, const T2 &y, BinaryNode *lt = NULL, BinaryNode *rt = NULL)
                : x(x), y(y), left(lt), right(rt) {}

    };

    BinaryNode *root;

    void insert(const T1 &x, const T2 &y, BinaryNode *&t);

    bool contains(const T1 &x, const T2 &y, BinaryNode *t) const;

    void make_empty(BinaryNode *t);

    void print_tree(BinaryNode *t, int depth) const;

    BinaryNode *clone(BinaryNode *t) const {
        return !t ? NULL :
               new BinaryNode(t->x, t->y, clone(t->left), clone(t->right));
    };
};

template<typename T1, typename T2>
void BinarySearchTree<T1, T2>::insert(const T1 &x, const T2 &y, BinarySearchTree<T1, T2>::BinaryNode *&t) {
    if (t == NULL)
        t = new BinaryNode(x, y);

    else if (x < t->x) insert(x, y, t->left);
    else if (x > t->x) insert(x, y, t->right);
    else if (y < t->y) insert(x, y, t->left);
    else if (y > t->y) insert(x, y, t->right);
    else;
}


template<typename T1, typename T2>
bool BinarySearchTree<T1, T2>::contains(const T1 &x, const T2 &y, BinarySearchTree<T1, T2>::BinaryNode *t) const {
    if (t == NULL) return false;
    if (x < t->x)
        return contains(x, y, t->left);
    else if (x > t->x)
        return contains(x, y, t->right);
    else if (y < t->y)
        return contains(x, y, t->left);
    else if (y > t->y)
        return contains(x, y, t->right);
    else
        return true;
}

template<typename T1, typename T2>
void BinarySearchTree<T1, T2>::print_tree(typename BinarySearchTree<T1, T2>::BinaryNode *t, int depth) const {
    if (t == NULL)
        return;
    const int offset = 6;
    print_tree(t->right, depth + 1);
    std::cout << std::setw(depth * offset);
    std::cout << "(" << t->x << "," << t->y << ")" << std::endl;
    print_tree(t->left, depth + 1);
}

template<typename T1, typename T2>
void BinarySearchTree<T1, T2>::make_empty(BinarySearchTree<T1, T2>::BinaryNode *t) {
    if (t == NULL)
        return;
    make_empty(t->left);
    make_empty(t->right);
    delete t;
    t = NULL;
}

// Print maximum key
template<typename T1, typename T2>
void BinarySearchTree<T1, T2>::print_max() const {
    const BinaryNode *node = root;

    if (root == NULL) {
        std::cout << "The maximum key is undefined." << std::endl;
        return;
    }

    while (node->right != NULL)
        node = node->right;

    std::cout << "The maximum key is (" << node->x << "," << node->y << ")" << std::endl;
}


#endif //BINARYSEARCHTREE_H
