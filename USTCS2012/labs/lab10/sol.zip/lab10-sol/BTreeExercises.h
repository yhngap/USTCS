//
// Operations on Binary Tree
//

#ifndef BTREEEXERCISES_H
#define BTREEEXERCISES_H

#include <iostream>
#include <queue>
#include "BtreeNode.h"
using namespace std;
template<class T>
int tree_height(BtreeNode<T> *root);

template<class T>
int count_nodes(BtreeNode<T> *root);

template<class T>
BtreeNode<T> *mirror(BtreeNode<T> *root);

template<class T>
bool is_complete(BtreeNode<T> *root);


template <class T>
BtreeNode<T> *lowest_common_ancestor(BtreeNode<T>* root, const T& a, const T& b);

template <class T>
void test_lowest_common_ancestor_output(BtreeNode<T>* root, const T& a, const T& b);

template <class T>
bool is_bst(BtreeNode<T>* root);

// Mirror
template<class T>
BtreeNode<T> *mirror(BtreeNode<T> *root) {
    if (root == NULL)
        return NULL;

    else {
        BtreeNode<T> *newNode = new BtreeNode<T>(root->get_data(), mirror(root->get_right()),
                                                 mirror(root->get_left()));
        return newNode;
    }
}

// Tree Height
template<class T>
int tree_height(BtreeNode<T> *root) {
    if (root == NULL) return -1;
    int leftHeight = tree_height(root->get_left());
    int rightHeight = tree_height(root->get_right());
    return (leftHeight > rightHeight) ? leftHeight + 1 : rightHeight + 1;
}

// Count Nodes
template<class T>
int count_nodes(BtreeNode<T> *root) {
    if (!root) return 0;
    int leftCount = count_nodes(root->get_left());
    int rightCount = count_nodes(root->get_right());
    return 1 + leftCount + rightCount;
}

// Is Complete
template<class T>
bool is_complete(BtreeNode<T> *root, int index, int nodes_number) {
    if (root == NULL)
        return true;

    if (index >= nodes_number)
        return false;

    return (is_complete(root->get_left(), index * 2 + 1, nodes_number) &&
            is_complete(root->get_right(), index * 2 + 2, nodes_number));
}

template<class T>
bool is_complete(BtreeNode<T> *root) {
    int node_number = count_nodes(root);
    return is_complete(root, 0, node_number);
}


template <class T>
BtreeNode<T>*
lowest_common_ancestor(BtreeNode<T>* root, const T& a, const T& b)
{
	if (root == nullptr)
		return nullptr;

	if (root->is_ancestor_of(a) && root->is_ancestor_of(b)) {
		BtreeNode<T>* left = root->get_left();
		BtreeNode<T>* right = root->get_right();

		BtreeNode<T>* left_result = lowest_common_ancestor(left, a, b);
		BtreeNode<T>* right_result = lowest_common_ancestor(right, a, b);

		if (left_result)
			return left_result;

		if (right_result)
			return right_result;

		return root;
	}
	else
		return nullptr;
}

template <class T>
void
test_lowest_common_ancestor_output(BtreeNode<T>* root, const T& a, const T& b)
{
	BtreeNode<T>* lca = lowest_common_ancestor(root, a, b);
	if (lca)
		cout << "Lowest common ancestor of " << a << " and " << b << " is " << lca->get_data() << endl;
	else
		cout << a << " and " << b << " have no common ancestor" << endl;
}

template <class T>
bool
is_bst(BtreeNode<T>* root)
{
	if (root == nullptr)
		return true;

	if (root->get_left()) {
		if (root->get_left()->find_max() > root->get_data())
			return false;
	}

	if (root->get_right()) {
		if (root->get_right()->find_min() < root->get_data())
			return false;
	}

	return (is_bst(root->get_left()) && is_bst(root->get_right()));
}


#endif //BTREEEXERCISES_H
