#include "store.h"

#include <iostream>

using namespace std;

Store::Store(string owner, int maxNumBreads, int maxNumMeats, int maxNumBurgers)
{
    this->owner = owner;
    this->numBreads = this->numMeats = this->numBurgers = 0;
    this->maxNumBreads = maxNumBreads;
    this->maxNumMeats = maxNumMeats;
    this->maxNumBurgers = maxNumBurgers;

    // TODO: Allocate memory for meats, breads and burgers.

    // Finish constructing with printing.
    cout << "Store Constructed!" << endl;
}

Store::Store(const Store &other)
{
    // TODO: Copy the owner string. Note: C++ string assignment is deep, you can just do stringA = stringB to copy the content from stringB to stringA.
    

    // TODO: Clone the bread shelf.
    

    // TODO: Clone the meat shelf.
    

    // TODO: Clone the burger shelf.
    

    // Finish copying with printing.
    cout << "Store Copied!" << endl;
}

Store::~Store()
{
    // TODO: Destruct the bread shelf.

    

    // TODO: Destruct the meat shelf.

    

    // TODO: Destruct the burger shelf.
    

    // Finish destructing with printing.
    cout << owner << "'s store Destructed." << endl;
}

void Store::cookBread()
{
    if (numBreads >= maxNumBreads)
    {
        cout << "Error: Bread shelf is full, cooking failed." << endl;
    }
    else
    {
        // TODO: Cook a bread by allocating a Bread object.
    }
}

void Store::cookMeat()
{
    if (numMeats >= maxNumMeats)
    {
        cout << "Error: Meat shelf is full, cooking failed." << endl;
    }
    else
    {
        // TODO: Cook a meat by allocating a Meat object.
    }
}

void Store::cookBurger()
{
    if (numBurgers >= maxNumBurgers)
    {
        cout << "Error: Burger shelf is full, cooking failed." << endl;
    }
    else if (numMeats < 1 || numBreads < 1)
    {
        cout << "Error: Materials are insufficient for a burger." << endl;
    }
    else
    {
        // TODO: Cook a burger by allocating a Burger object,
        // Since the construction of Burger needs bread and meat,
        // it will consume one piece of bread and one piece of meat at the top of both shelves.
        // The ownership of the top bread and top meat are transferred to the burger,
        // which means the burger should destruct its bread and meat when it is being destructed.
        
    }
}

void Store::print() const
{
    // TODO: Print the store summary according to the lab page description.
    // See the given code in destructor to learn how to print a string with cout.
    
}
