#include <algorithm>
#include <iostream>
#include <cstring>
#include <vector>
#include <stack>

using namespace std;

//Checks whether a given string contains only math operators
bool is_operator(const string &str) {
    return str.find_first_not_of("+-*/") == string::npos;
}
 
//Checks whether a given string contains only digits
bool is_digits(const string &str) {
    return str.find_first_not_of("0123456789") == string::npos;
}

//TODO: Returns a vector storing the numbers and operators of the input formula
vector<string> store_the_formula(const string &formula) {
    
}

//TODO: Print the calulation steps of the given formula. You must use iterators to traverse the formula 
//vector and a stack and to evaluate the formula, as explained in the lab description. First you need to determine 
//whether a formula is in Polish or Reverse Polish notation.
//Hint: You may use is_digits and is_operators to tell apart Polish Notation and Reverse Polish Notation.
void calculation_steps(vector<string> sequence) {
    stack<int> stk;
    vector<string>::const_iterator begin;
    vector<string>::const_iterator end;

}

//Calculates and prints the result of evaluating a formula in Polish or Inverse Polish format. The formula may contain +-*/ operators
void calculation_result(const string &formula) {
    // transform the input string into the one with format of the corresponding notation 
    // and store it in a vector
    vector<string> sequence = store_the_formula(formula);

    // print the notation stored in the vector
    cout << "Formula:"<< " ";
    for(vector<string>::const_iterator it = sequence.begin(); it != sequence.end(); ++it) {
        cout << *it << " ";
    }
    // calculate the result and print it out
    cout << endl << "Calculation steps: " << endl;
    calculation_steps(sequence);
}

int main() {
    cout << "Test 1:" << endl;
    string formula1 = "5 1 2 + 4 * + 3 -";
    calculation_result(formula1);
    cout << endl << "Test 2:" << endl;
    string formula2 = "9 3 1 - 3 * 10 2 / + +";
    calculation_result(formula2);
    cout << endl << "Test 3:" << endl;
    string formula3 = "+ + 2 * 3 - 10 4 / 8 4";
    calculation_result(formula3);
    cout << endl << "Test 4:" << endl;
    string formula4 = "- * 2 + 1 5 4";
    calculation_result(formula4);
    return 0;

}
