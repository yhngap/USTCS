#include <algorithm>
#include <iostream>
#include <cstring>
#include <vector>
#include <stack>

using namespace std;

//Checks whether a given string contains only math operators
bool is_operator(const string &str) {
    return str.find_first_not_of("+-*/") == string::npos;
}

//Checks whether a given string contains only digits
bool is_digits(const string &str) {
    return str.find_first_not_of("0123456789") == string::npos;
}

//TODO: Returns a vector storing the numbers and operators of the input formula
vector<string> store_the_formula(const string &formula) {
    vector<string> vec;
    string temp = "";
    for(int i=0; i<formula.size(); ++i) {
        char c = formula[i];
        if(c == ' ') {
            vec.push_back(temp);
            temp = "";
        }else {
            temp += c;
        }
    }
    if(temp != "") {
        vec.push_back(temp);
    }
    return vec;
}

//TODO: Print the calulation steps of the given formula. You must use iterators to traverse the formula 
//vector and a stack and to evaluate the formula, as explained in the lab description. First you need to determine 
//whether a formula is in Polish or Reverse Polish notation.
//Hint: You may use is_digits and is_operators to tell apart Polish Notation and Reverse Polish Notation
void calculation_steps(vector<string> sequence) {
    stack<int> stk;
    vector<string>::const_iterator begin;
    vector<string>::const_iterator end;
    bool is_digit = false;

    if (is_digits(sequence.front())){
        begin = sequence.begin();
        end = sequence.end();
        is_digit = true;
    }else if (is_operator(sequence.front())){
        begin = sequence.end()-1;
        end = sequence.begin()-1;
    }

    for(vector<string>::const_iterator i = begin; i != end;) {
        if(is_digits(*i)) {
            int num = stoi(*i);
            stk.push(num);
            cout << "push " << num << " to the stack." <<endl;
        }else if(is_operator(*i)){
            int op2 = stk.top();
            stk.pop();
            cout << "pop " << op2 << " from the stack." << endl;
            int op1 = stk.top();
            stk.pop();
            cout << "pop " << op1 << " from the stack." << endl;
            int result;
            switch((*i)[0]) {
                case '+':
                    result = op1 + op2;
                    if(is_digit){
	                    cout << op1 << "+" << op2 << "=" << result << endl;
                    }else{
	                    cout << op2 << "+" << op1 << "=" << result << endl;
                    }
                    break;
                case '-':
                    if(is_digit){
                        result = op1 - op2;
	                    cout << op1 << "-" << op2 << "=" << result << endl;
                    }else{
                        result = op2 - op1;
	                    cout << op2 << "-" << op1 << "=" << result << endl;
                    }     
                    break;
                case '*':
	                result = op1 * op2;
                    if(is_digit){
                        cout << op1 << "*" << op2 << "=" << result << endl;
                    }else{
                        cout << op2 << "*" << op1 << "=" << result << endl;
                    }
	                
                    break;
                case '/':
                    if(is_digit){
                        result = op1 / op2;
                        cout << op1 << "/" << op2 << "=" << result << endl;
                    }else{
                        result = op2 / op1;
                        cout << op2 << "/" << op1 << "=" << result << endl;
                    }
            }
        stk.push(result);
        cout << "push " << result << " to the stack." << endl;
        }
        if (is_digit){
            ++i;
        }else{
            --i;
        }
    }
    cout << "Result: "<< stk.top()<<endl;
}

void calculation_result(const string &formula) {
    // transform the input string into the one with format of the corresponding notation 
    // and store it in a vector
    vector<string> sequence = store_the_formula(formula);

    // print the notation stored in the vector
    cout << "Formula:"<< " ";
    for(vector<string>::const_iterator it = sequence.begin(); it != sequence.end(); ++it) {
        cout << *it << " ";
    }
    // calculate the result and print it out
    cout << endl << "Calculation steps: " << endl;
    calculation_steps(sequence);
}

int main() {
    cout << "Test 1:" << endl;
    string formula1 = "5 1 2 + 4 * + 3 -";
    calculation_result(formula1);
    cout << endl << "Test 2:" << endl;
    string formula2 = "9 3 1 - 3 * 10 2 / + +";
    calculation_result(formula2);
    cout << endl << "Test 3:" << endl;
    string formula3 = "+ + 2 * 3 - 10 4 / 8 4";
    calculation_result(formula3);
    cout << endl << "Test 4:" << endl;
    string formula4 = "- * 2 + 1 5 4";
    calculation_result(formula4);
    return 0;

}
