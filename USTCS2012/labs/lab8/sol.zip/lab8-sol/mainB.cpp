#include <set>
#include <algorithm>
#include <string>
#include <iostream>
#include <list>
#include <map>
#include <iterator> 
using namespace std;


 // TODO: Print a set of string using iterator, use "," to separate each object
void printSetUsingIterator(const set<string>& s) {
	set<string>::const_iterator itr = s.begin();
	cout << "{" ;
	while (itr != s.end() ) {
		cout << *itr ;
		itr++;
		if ( itr != s.end() )
			cout << "," ;
	}
	cout << "}" << endl ;
}

// TODO: Print a list of string using iterator, use "," to separate each object
void printListUsingIterator(const list<string>& s) {
	list<string>::const_iterator itr = s.begin();
	cout << "{" ;
	while (itr != s.end() ) {
		cout << *itr ;
		itr++;
		if ( itr != s.end() )
			cout << "," ;
	}
	cout << "}" << endl ;
}

// TODO: Print a map using iterator, use '\t' to separate "key: " and "Value: "
void printMapUsingIterator(const map<string,int>& s) {
	 map<string,int>::const_iterator itr = s.begin();
	 while (itr != s.end() ) {
	 	cout << "key: "<< itr->first << '\t' << "Value: " << itr->second << endl ;
	 	itr++;
	 }
}

//TODO: You may need to define a comparator function yourself here (for the sorting task)
bool cmp(const string &a, const string &b)
{
	return a.length() < b.length();
}


int main() {

	cout << "************************** Part1: set **************************";
	cout << endl;

	set<string> Fictions, Movies;
	Fictions.insert("The Time Machine");
	Fictions.insert("Harry Potter");
	Fictions.insert("The Lord of the Rings");

	Movies.insert("The Shawshank Redemption");
	Movies.insert("City of God");
	Movies.insert("The Lord of the Rings");
	Movies.insert("Harry Potter");

	cout << "Set Fictions Content = " ;
	printSetUsingIterator(Fictions);
	cout << "Set Movies Content = " ;
	printSetUsingIterator(Movies);

	set<string> interSet;

    // Part 1 TODO: Complete the set operations: intersection
	set_intersection(Fictions.begin(), Fictions.end(), Movies.begin(), Movies.end(), inserter(interSet, interSet.begin()));



	cout << "Fictions intersect Movies Content = ";
	printSetUsingIterator(interSet);

    cout << endl;
	cout << "************************** Part2: list **************************";
    cout << endl;

	// Merge Fictions and Movies to listR
	list<string> listR ;

	// Part 2 TODO: Merge Fictions and Movies to listR
	merge(Fictions.begin(), Fictions.end(), Movies.begin(), Movies.end(), back_inserter(listR));


	
	cout << "List R Content = ";
	printListUsingIterator(listR);


    // Part 2 TODO: 
    //Add a new string "Saw" at the end of the list
    //Add a new string "Avenger" at the head of the list
	listR.push_back("Saw");
	listR.push_front("Avenger");
	
	
	cout << "New R Content = ";
	printListUsingIterator(listR);

	//TODO: Sort listR by movie name length ascendingly
	listR.sort(cmp);

	cout << "Sorted R Content = ";
	printListUsingIterator(listR);

    cout << endl;
	cout << "************************** Part3: map **************************";
    cout << endl;

    //map
	map<string,int> mapMovie;
	mapMovie.insert(make_pair("The Shawshank Redemption",1994));
	mapMovie.insert(make_pair("City of God",2002));
	mapMovie.insert(make_pair("The Lord of the Rings", 2002));
	mapMovie.insert(make_pair("Star Wars", 1977));
	mapMovie.insert(make_pair("Forest Gump", 1994));
	cout << "mapMovie Content: "<<endl;
	printMapUsingIterator(mapMovie);




	//Part3 TODO : Complete element search and deletion in mapMovie here
    // search "Star Wars" in map
    // ADD YOUR CODE HERE

	//element search using key in map
	map<string,int>::iterator itr;
	itr = mapMovie.find("Star Wars");
	if(itr != mapMovie.end()){
		cout << "Key found, the value is " << itr->second <<endl;
	}else{
		cout << "Do not find the key." << endl;
	}

    // delete "City of God" in map
    // ADD YOUR CODE HERE
	//element deletion using key in map
	mapMovie.erase("City of God");

	
	cout << "mapMovie Content after deletion: "<<endl;
	printMapUsingIterator(mapMovie);



	return 0;
}
