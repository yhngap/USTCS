#include <set>
#include <algorithm>
#include <string>
#include <iostream>
#include <list>
#include <map>
using namespace std;

void printSetUsingIterator(const set<string>& s) {
   // TODO: Print a set of string using iterator, use "," to separate each object
}

void printListUsingIterator(const list<string>& s) {
   // TODO: Print a list of string using iterator, use "," to separate each object
}

void printMapUsingIterator(const map<string,int>& s) {
   // TODO: Print a map using iterator, use '\t' to separate "key: " and "Value: "
}


//TODO: You may need to define a comparator function yourself here (for the sorting task)

int main() {

	cout << endl;
	cout << "************************** Part1: set **************************";
	cout << endl;

	set<string> Fictions, Movies;
	Fictions.insert("The Time Machine");
	Fictions.insert("Harry Potter");
	Fictions.insert("The Lord of the Rings");

	Movies.insert("The Shawshank Redemption");
	Movies.insert("City of God");
	Movies.insert("The Lord of the Rings");
	Movies.insert("Harry Potter");

	cout << "Set Fictions Content = " ;
	printSetUsingIterator(Fictions);
	cout << "Set Movies Content = " ;
	printSetUsingIterator(Movies);

    // Part 1 TODO: Complete the set operations: intersection
	set<string> interSet;

   // ADD YOUR CODE HERE

   cout << "Fictions intersect Movies Content = ";
   printSetUsingIterator(interSet);

   cout << endl;
	cout << "************************** Part2: list **************************";
   cout << endl;

	// Merge Fictions and Movies to listR
	list<string> listR ;
   
   // Part 2 TODO: Merge Fictions and Movies to listR
   // ADD YOUR CODE HERE

	cout << "List R Content = ";
	printListUsingIterator(listR);

	// Part 2 TODO: 
    //Add a new string "Saw" at the end of the list
    //Add a new string "Avenger" at the head of the list
    // ADD YOUR CODE HERE

	cout << "New R Content = ";
	printListUsingIterator(listR);

	 // Sort listR by movie name length ascendingly
    // ADD YOUR CODE HERE

	cout << "Sorted R Content = ";
	printListUsingIterator(listR);

   cout << endl;
	cout << "************************** Part3: map **************************";
   cout << endl;

    //map
	map<string,int> mapMovie;
	mapMovie.insert(make_pair("The Shawshank Redemption",1994));
	mapMovie.insert(make_pair("City of God",2002));
	mapMovie.insert(make_pair("The Lord of the Rings", 2002));
	mapMovie.insert(make_pair("Star Wars", 1977));
	mapMovie.insert(make_pair("Forest Gump", 1994));
	cout << "mapMovie Content: "<<endl;
	printMapUsingIterator(mapMovie);

    //Part3 TODO : Complete element search and deletion in mapMovie here
    // search "Star Wars" in map
    // ADD YOUR CODE HERE

    // delete "City of God" in map
    // ADD YOUR CODE HERE

	cout << "mapMovie Content after deletion: "<<endl;
	printMapUsingIterator(mapMovie);



	return 0;
}
