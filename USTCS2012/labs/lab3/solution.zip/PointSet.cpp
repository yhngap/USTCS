/*
 * PointSet.cpp
 * 
 */

#include "PointSet.h"
#include <iostream>
using namespace std;


PointSet::PointSet()
{
   cout << "Initialized by PointSet's default constructor" << endl;

   // TODO: add your code here
   numPoints = 0;
   points = nullptr;
}

PointSet::PointSet(const Point3D points[], int numPoints)
{
   cout << "Initialized by PointSet's other constructor" << endl;

   // TODO: add your code here
   this->numPoints = numPoints;
   this->points = new Point3D[numPoints];
   for(int i = 0; i < numPoints; i++)
   {
     this->points[i] = points[i];
   }
}

PointSet::PointSet(const PointSet & s)
{
   cout << "Initialized by PointSet's copy constructor" << endl;

   // TODO: add your code here
   numPoints = s.numPoints;
   points = new Point3D[numPoints];
   for(int i = 0; i < numPoints; i++)
   {
     points[i] = s.points[i];
   }
}

PointSet::~PointSet()
{
    cout<<"PointSet's destructor is called!" <<endl;

     // TODO: add your code here
    if(points != NULL)
      delete[] points;
}


void PointSet::addPoint(const Point3D& p)
{
   // TODO: add your code here
  Point3D *newPoints = new Point3D[++numPoints];

  for(int i = 0; i < numPoints -1; i++){
    newPoints[i] = points[i];
  }
  newPoints[numPoints - 1] = p;

  delete [] points;
  points = newPoints;
}

bool PointSet::contains(const Point3D& p) const
{
   // TODO: add your code here
  for(int i = 0; i < numPoints; i++){
    if(points[i].equal(p))
      return true;
  }

  return false;
}

void PointSet::removeFirstPoint()
{
   // TODO: add your code here
   if (numPoints == 0)
   {
      cout << "No points!" << endl;
   }
   else
   {
      Point3D *newPoints = new Point3D[--numPoints];

    for(int i = 0; i < numPoints; i++){
      newPoints[i] = points[i+1];
    }

    delete [] points;
    points = newPoints;
   }
}

void PointSet::removeLastPoint()
{
   // TODO: add your code here
   if (numPoints == 0)
   {
      cout << "No points!" << endl;
   }
   else
   {
      Point3D *newPoints = new Point3D[--numPoints];

      for(int i = 0; i < numPoints; i++){
         newPoints[i] = points[i];
      }

      delete [] points;
      points = newPoints;
   }
}

void PointSet::print() const
{
   if (numPoints == 0) {
      cout << "Empty!" << endl;
      return;
   }
   for (int i = 0; i < numPoints; i++)
   {
      points[i].print();
      cout << endl;
   }
}

