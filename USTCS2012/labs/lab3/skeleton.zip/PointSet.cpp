/*
 * PointSet.cpp
 * 
 */

#include "PointSet.h"
#include <iostream>
using namespace std;


PointSet::PointSet()
{
   cout << "Initialized by PointSet's default constructor" << endl;

   // TODO: add your code here
}

PointSet::PointSet(const Point3D points[], int numPoints)
{
   cout << "Initialized by PointSet's other constructor" << endl;

   // TODO: add your code here
}

PointSet::PointSet(const PointSet & s)
{
   cout << "Initialized by PointSet's copy constructor" << endl;

   // TODO: add your code here
}

PointSet::~PointSet()
{
    cout<<"PointSet's destructor is called!" <<endl;

     // TODO: add your code here
}


void PointSet::addPoint(const Point3D& p)
{
   // TODO: add your code here
}

bool PointSet::contains(const Point3D& p) const
{
   // TODO: add your code here
}

void PointSet::removeFirstPoint()
{
   // TODO: add your code here
}

void PointSet::removeLastPoint()
{
   // TODO: add your code here
}

void PointSet::print() const
{
   // TODO: add your code here
}

