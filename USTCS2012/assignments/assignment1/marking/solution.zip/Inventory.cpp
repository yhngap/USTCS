#include "Inventory.h"


Inventory::Inventory() 
{
    this->items = nullptr;
    this->itemCount = 0;
}

Inventory::Inventory(const Inventory& another) 
{
    itemCount = another.itemCount;
    items = new Item*[itemCount];
    for(int i=0;i<itemCount;i++)
    {
        items[i] = new Item(*another.items[i]);
    }
}

Inventory::~Inventory() 
{
    emptyInventory();
}

void Inventory::addItem(string name, int quantity) 
{
    int itemIndex = getItemIndex(name);
    if(itemIndex == -1)
    {
        Item* item = new Item(name, quantity);
        Item** newItems = new Item*[itemCount+1];
        for(int i=0;i<itemCount;i++)
            newItems[i] = items[i];
        newItems[itemCount] = item;
        itemCount++;
        delete [] items;
        items = newItems;
    }
    else
    {
        items[itemIndex]->add(quantity);
    }
}

bool Inventory::removeItem(string name, int quantity) 
{
    int itemIndex = getItemIndex(name);
    if(itemIndex == -1)
        return false;
    int current = getQuantity(name);
    if(current - quantity == 0)
    {
        //remove the item completely
        Item** newItems = new Item*[itemCount-1];
        for(int i=0, j=0;i<itemCount;i++, j++)
        {
            if(items[i]->getName() == name)
            {
                delete items[i];
                j--;
            }
            else
                newItems[j] = items[i];
        }
        itemCount--;
        delete [] items;
        items = newItems;
        return true;
    }
    else 
        return items[itemIndex]->remove(quantity);
}

void Inventory::addInventory(const Inventory& another) 
{
    for(int i=0;i<another.itemCount;i++)
    {
        addItem(another.items[i]->getName(), another.items[i]->getQuantity());
    }
}

void Inventory::emptyInventory() 
{
    for(int i=0; i<itemCount; i++)
        delete items[i];
    delete [] items;
    items = nullptr;
    itemCount = 0;
}

int Inventory::getQuantity(string name) const
{
    int itemIndex = getItemIndex(name);
    if(itemIndex == -1)
        return 0;
    return items[itemIndex]->getQuantity();
}

int Inventory::getItemIndex(string name) const
{
    for(int i=0;i<itemCount;i++)
        if(items[i]->getName() == name)
            return i;
    return -1;
}

int Inventory::getTotalUsedSpace() const
{
    int total=0;
    for(int i=0;i<itemCount;i++)
        total += items[i]->getQuantity();
    return total;
}

Inventory* Inventory::getUnion(const Inventory& another) const
{
    Inventory* result = new Inventory(*this);
    for(int i=0;i<another.itemCount;i++)
    {
        string name = another.items[i]->getName();
        int thisQuantity = result->getQuantity(name);
        int anotherQuantity = another.items[i]->getQuantity();
        int diff = anotherQuantity - thisQuantity;
        if(diff>0)
            result->addItem(name, diff);
    }
    return result;
}

Inventory* Inventory::getIntersection(const Inventory& another) const
{
    Inventory* result = new Inventory;
    for(int i=0;i<itemCount;i++)
    {
        string name = items[i]->getName();
        int thisQuantity = this->getQuantity(name);
        int anotherQuantity = another.getQuantity(name);
        if(thisQuantity > 0 && anotherQuantity > 0)
            result->addItem(name, thisQuantity<anotherQuantity?thisQuantity:anotherQuantity);
    }
    return result;
}

Inventory* Inventory::getDifference(const Inventory& another) const
{
    Inventory* result = new Inventory(*this);
    for(int i=0;i<itemCount;i++)
    {
        string name = items[i]->getName();
        int anotherQuantity = another.getQuantity(name);
        if(anotherQuantity > 0)
        {
            int thisQuantity = getQuantity(name);
            if(anotherQuantity > thisQuantity) 
                anotherQuantity = thisQuantity;
            result->removeItem(name, anotherQuantity);
        }   
    }
    return result;
}

void Inventory::print() const
{
    cout << "{";
    for(int i=0;i<itemCount;i++)
    {
        cout << "\"" << items[i]->getName() << "\"";
        cout << ":";
        cout << items[i]->getQuantity();
        if(itemCount-1!=i)
            cout << ",";
    }
    cout << "}" << endl;
}

