#include "Item.h"

Item::Item(string name, int quantity) 
{
    this->name = name;
    this->quantity = quantity;    
}

string Item::getName() const
{
    return name;
}

int Item::getQuantity() const
{
    return quantity;
}

void Item::add(int amount) 
{
    quantity += amount;
}

bool Item::remove(int amount) 
{
    if(quantity - amount >= 0)
    {
        quantity -= amount;
        return true;
    }
    else
        return false;
}
