#include <iostream>
#include "Inventory.h"

using namespace std;

//do NOT modify the given header files and the main*.cpp source files
//check the FAQ section also to see what you are disallowed to do
int main()
{
    cout << boolalpha << endl; //we want to see true/false instead of 1/0 in the console output
    cout << "Wow, so happy to work on a programming assignment again! Yes Yes YES! Let's play with inventories this time! ^_____^" << endl;
    cout << endl;

    cout << "===============================" << endl;
    Inventory a;
    Inventory b;
    for(int i=0;i<26;i++)
    {
        string name1 = string(1, 'a'+ i); //create a string of a single character
        string name2 = string(1, 'z'- i); //create a string of a single character
        a.addItem(name1, i+1);
        if(i%2)
            b.addItem(name2, i*2);
    }
    a.print();
    b.print();
    cout << "===============================" << endl;
    a.getDifference(b)->print();
    b.getDifference(a)->print();
    cout << "===============================" << endl;
    a.getDifference(a)->print();
    b.getDifference(b)->print();
    cout << "===============================" << endl;
    //we do not delete the dynamic objects deliberately
    //just to avoid crashing some of your programs 

    return 0;
}