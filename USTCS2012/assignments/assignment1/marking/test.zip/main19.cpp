#include <iostream>
#include "Inventory.h"

using namespace std;

//do NOT modify the given header files and the main*.cpp source files
//check the FAQ section also to see what you are disallowed to do
int main()
{
    cout << boolalpha << endl; //we want to see true/false instead of 1/0 in the console output
    cout << "Wow, so happy to work on a programming assignment again! Yes Yes YES! Let's play with inventories this time! ^_____^" << endl;
    cout << endl;

    cout << "===============================" << endl;
    Inventory a;
    a.addItem("Apple", 10);
    a.addItem("Banana", 20);
    a.addItem("Orange", 15);
    a.print();
    cout << "===============================" << endl;
    cout << "Remove all apple:" << endl;
    cout << "result=" << a.removeItem("Apple", 10) << endl;
    a.print();
    cout << "Remove all bananas:" << endl;
    cout << "result=" << a.removeItem("Banana", 20) << endl;
    a.print();
    cout << "Remove all oranges:" << endl;
    cout << "result=" << a.removeItem("Orange", 15) << endl;
    a.print();
    cout << "===============================" << endl;
    Inventory b;
    b.addItem("Apple", 10);
    b.addItem("Banana", 20);
    b.addItem("Orange", 15);
    b.print();
    cout << "===============================" << endl;
    cout << "Remove all oranges:" << endl;
    cout << "result=" << b.removeItem("Orange", 15) << endl;
    b.print();
    cout << "Remove all bananas:" << endl;
    cout << "result=" << b.removeItem("Banana", 20) << endl;
    b.print();
    cout << "Remove all apple:" << endl;
    cout << "result=" << b.removeItem("Apple", 10) << endl;
    b.print();
    cout << "===============================" << endl;
    Inventory c;
    c.addItem("Apple", 10);
    c.addItem("Banana", 20);
    c.addItem("Orange", 15);
    c.print();
    cout << "===============================" << endl;
    cout << "Remove all bananas:" << endl;
    cout << "result=" << c.removeItem("Banana", 20) << endl;
    c.print();
    cout << "Remove all apple:" << endl;
    cout << "result=" << c.removeItem("Apple", 10) << endl;
    c.print();
    cout << "Remove all oranges:" << endl;
    cout << "result=" << c.removeItem("Orange", 15) << endl;
    c.print();
    cout << "===============================" << endl;

    return 0;
}