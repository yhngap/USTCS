#ifndef LEDGER_H
#define LEDGER_H
#include "transactions.h"
#include "income.h"
#include "expenses.h"

class Ledger
{
public:
	Ledger(int maxNumTrans, int currNumTrans);
    ~Ledger();
    void addTransaction(Transaction* newTransaction);
    void removeSingleTransaction(int numTransact);
    void printAllTransactions() const;
    void printRecentNTrans(int nTrans) const;
    void printRealizedTransactions(bool realized) const;
    int getCurrNumTrans() const;
    Transaction* getTransactionByNum(int numTransact);
    void updateTransactionInLedger(Transaction* oldTrans, Transaction* newTrans); 
    
    
private:
    Transaction** allTransactions;
    int maxNumTrans;
    int currNumTrans;
};

#endif