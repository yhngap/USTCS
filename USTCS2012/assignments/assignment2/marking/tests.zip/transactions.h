#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <iostream>
#include <string>
// using std::string;
using namespace std;

enum TransactionCategory {SALARY, POCKET_MONEY, INVEST_RETURNS, GIFTS, HEALTH, FOOD, CLOTHS, RENTAL, TRANSPORT, ENTERTAINMENTS};
enum GoesTo {BANK, CASH, CREDIT_CARD};


class Transaction
{
public:
    Transaction(double amount, bool hasRealized, string date, string describe);
    virtual ~Transaction() = 0;
    
	void setAmount(double amount);
    double getAmount() const;
	
    void setHasRealized();
    bool getHasRealized();
	
	void setDate(string str);
	string getDate() const;	
	
	void setDescriptions(string str);
	string getDescriptions() const;
	
	virtual GoesTo getGoesTo() const = 0;
	virtual TransactionCategory getCategory() const = 0;
    virtual ostream& printTransaction(ostream& out) const = 0;
    friend ostream& operator << (ostream &out, const Transaction &trans);
    
protected:
    double amount;
    bool hasRealized;
	string date;
	string descriptions;
};

#endif