#ifndef ACCOUNT_H
#define ACCOUNT_H

#include "ledger.h"

class Account
{
public:
	Account(double bank, double creditCard, double cash);
    ~Account();
    
    void printBalance() const;
    
	void addTransactionToLedger(Transaction* newTransact);	
	void removeTransactionFromLedger(Ledger* led, int numTransact);
	void updateLedger(Transaction* oldTrans, Transaction* newTrans);
    void addBalance(int option, double amount);
    Ledger* getIncomeLedger();
    Ledger* getExpensesLedger();


private:
    Ledger* incomeLedger;
    Ledger* expensesLedger;    

	int maxNumTrans = 100;

	double bankBalance;
	double cashBalance;
	double creditCardBalance;
};

#endif