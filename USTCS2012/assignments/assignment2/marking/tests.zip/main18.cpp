#include "account.h"
using namespace std;

int main()
{
    Ledger* led = new Ledger(100, 0);
	delete led;	
}