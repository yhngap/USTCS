#include <iostream>
#include "account.h"
using namespace std;

int main()
{
    Account ac(3000,3000,3000);
}