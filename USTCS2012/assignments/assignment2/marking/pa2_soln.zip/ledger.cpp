#include "ledger.h"
#include <iostream>
#include <cmath>
using namespace std;
const int MAX_NUM_TRANS = 100;

Ledger::Ledger(int maxNumTrans, int currNumTrans): maxNumTrans(maxNumTrans), currNumTrans(0){
    allTransactions = new Transaction* [maxNumTrans];
}

Ledger::~Ledger(){
    for(int i=0; i<currNumTrans; i++){
        delete allTransactions[i];
    }
    
    delete[] allTransactions;
}

void Ledger::updateTransactionInLedger(Transaction* oldTrans, Transaction* newTrans){

    double transactAmount = oldTrans->getAmount();
    bool transactRealized = oldTrans->getHasRealized();
    string transactDate = oldTrans->getDate();
    
    for(int i=0; i<currNumTrans; i++){
        bool sameAmt = fabs(allTransactions[i]->getAmount()-transactAmount) < 0.00001;
        bool sameRealized = (allTransactions[i]->getHasRealized() == transactRealized);
        bool sameDate = (allTransactions[i]->getDate().compare(transactDate) == 0);
        if(sameAmt && sameRealized && sameDate){
            delete allTransactions[i];
            allTransactions[i] = newTrans;
            return;
        }
    }

    cout << "No matching old transaction found!" <<endl;

}

void Ledger::addTransaction(Transaction* newTransaction){       //added from account
    if(currNumTrans == maxNumTrans){
        cout << "Memory is full. Failed to add transaction!" <<endl; 
        return;
    }
    allTransactions[currNumTrans++] =  newTransaction;
}

void Ledger::printAllTransactions() const{
    if(currNumTrans==0){
        cout << "Sorry, no transaction to print!" <<endl; 
        return;
    }
    
    for (int i = 0; i < currNumTrans; ++i)
    {
        // allTransactions[i]->printTransaction();
        cout << *allTransactions[i];
    }
}

void Ledger::printRecentNTrans(int nTrans) const{
    if(currNumTrans==0){
        cout << "Sorry, no transaction to print!" <<endl; 
        return;
    }    
    
    if(nTrans>currNumTrans){
        return;
    }                            
    for (int i = currNumTrans-1; i >currNumTrans-1-nTrans; i--)
    {
        // allTransactions[i]->printTransaction();
        cout << *allTransactions[i];
    }    
}

void Ledger::removeSingleTransaction(int numTransact){		//start from 0
    if(currNumTrans==0){
        cout << "Sorry, no transaction to remove!" <<endl; 
        return;
    }
    
    if(numTransact >= currNumTrans){
        cout << "Invalid transaction number!" <<endl;
        return;
    }

	delete allTransactions[numTransact];
    allTransactions[numTransact] = nullptr;

	for(int j=numTransact; j<currNumTrans-1; j++){
		allTransactions[j] = &(*allTransactions[j+1]);
	}

    allTransactions[currNumTrans-1] = nullptr;
    
    currNumTrans -= 1;
}

void Ledger::printRealizedTransactions(bool realized) const{
    if(currNumTrans==0){
        cout << "Sorry, no transaction to print!" <<endl; 
        return;
    }
    
    bool any = false; 
    for(int i=0; i<currNumTrans; i++){
        if(allTransactions[i]->getHasRealized() == realized){
            any = true;
            cout << *allTransactions[i];
        }
    }
    if(!any){
        cout << "There is no " << (realized? "":"un") << "realized transaction. " << endl; 
    }
}

Transaction* Ledger::getTransactionByNum(int numTransact){
    if(currNumTrans==0){
        cout << "Sorry, no transaction to retrieve!" <<endl; 
        return nullptr;
    }    
    if(numTransact >= currNumTrans){
        cout << "Wrong transaction number! Cannot retrieve transactions!" << endl;
        return nullptr;
    }
    return allTransactions[numTransact];
}


int Ledger::getCurrNumTrans() const{
    return currNumTrans;
}