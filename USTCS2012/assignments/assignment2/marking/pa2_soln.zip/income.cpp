#include "income.h"
#include <iostream>
using namespace std;

// enum TransactionCategory {SALARY, POCKET_MONEY, INVEST_RETURNS, GIFTS}
// enum GoesTo {BANK, CASH}


Income::Income(double amount, bool hasRealized, string date, TransactionCategory ic, GoesTo gt, string description):
Transaction(amount, hasRealized, date, description), sources(ic), sumToWhere(gt)
{
    cout << "Income with amount " << this->amount << " dated " << this->date << " initialized. " << endl;
}

Income::~Income(){
    cout << "Income with " << amount << " dollars on " << date << " deleted." <<endl;
}

Income* Income::operator*(int salaryMultiplier){
    this->amount *= salaryMultiplier;
    cout << "The transaction amount has been multiplied " << salaryMultiplier << " times." <<endl;
    return this;
}    

void Income::setGoesTo(GoesTo gt){
    sumToWhere = gt;
    cout << "Income has sent to " << sumToWhere << endl;
}

ostream& Income::printTransaction(ostream& out) const{
	out << "=====================================" <<endl;
	out << "Income: " << descriptions <<endl;
	out << "Income Date: " << date <<endl; 
	out << "Amount: " << amount << endl;
	out << "Has been realized?: " << hasRealized << endl;
    string typeToPrint = sumToWhere==BANK ? "Bank":"Cash"; 
    out << "Amount added into: " << typeToPrint <<endl;
	out << "=====================================" <<endl;
    return out;
}

TransactionCategory Income::getCategory() const{
    cout << "Identifying which type of income is this..." << endl; 
    return sources;
}

GoesTo Income::getGoesTo() const{
    cout << "Identify where this income goes to..." << endl; 
    return sumToWhere;
}