#include "account.h"
#include <string>
#include <iostream>
using namespace std;

Account::Account(double bank, double creditCard, double cash): bankBalance(bank), creditCardBalance(creditCard), cashBalance(cash)
{
	incomeLedger = new Ledger(maxNumTrans, 0);
	expensesLedger = new Ledger(maxNumTrans, 0);
    
    cout << "Initialization of account succeed! There are two ledger: Income and Expenses." << endl;
    cout << "==========Account Summary==========" << endl;
    cout << "Maximum #. transactions allowed for each ledger: " << maxNumTrans <<endl;
    cout << "Current #. transactions allowed for each ledger: " << maxNumTrans << endl;
    cout << "Current bank balance: " << bankBalance << endl;
    cout << "Current credit card balance: " << creditCardBalance << endl;
    cout << "Current cash balance: " << cashBalance << endl;
    cout << endl;
    
}

Ledger* Account::getIncomeLedger(){
    return incomeLedger;
}

Ledger* Account::getExpensesLedger(){
    return expensesLedger;
}

void Account::addBalance(int option, double amount){
    if(option==0){
        bankBalance += amount;
    }else if(option==1){
        cashBalance += amount;
    }else if(option==2){
        creditCardBalance += amount;
    }else{
        cout << "Wrong balance option number!" << endl;
    }
}

void Account::updateLedger(Transaction* oldTrans, Transaction* newTrans){
    Income *old_inc = dynamic_cast<Income*>(oldTrans); 
    Expenses *old_exp = dynamic_cast<Expenses*>(oldTrans); 
    Income* new_inc = dynamic_cast<Income*>(newTrans);      //problem
    Expenses* new_exp = dynamic_cast<Expenses*>(newTrans);

    bool areIncomes = (old_inc!=nullptr && new_inc!=nullptr);
    bool areExpenses = (old_exp!=nullptr && new_exp!=nullptr);

    if(!areIncomes && !areExpenses){
        cout << "New and Old transaction types not matching!" << endl;
        cout << "Fail to insert records!" << endl; 
        return;
    }      

    double oldTransAmt = oldTrans->getAmount();
    double newTransAmt = newTrans->getAmount();

    GoesTo oldGT = oldTrans->getGoesTo();
    GoesTo newGT = newTrans->getGoesTo();

    if(oldGT == 0){
        bankBalance -= oldTransAmt;
    }else if(oldGT == 1){
        cashBalance -= oldTransAmt;
    }else if(oldGT == 2){
        creditCardBalance -= oldTransAmt;
    }else{
        return;
    }

    if(newGT == 0){
        bankBalance += newTransAmt;
    }else if(newGT == 1){
        cashBalance += newTransAmt;
    }else if(newGT == 2){
        creditCardBalance += newTransAmt;
    }else{
        return;
    }    
    
    if(areIncomes){
        incomeLedger->updateTransactionInLedger(oldTrans, newTrans);
    }else{
        expensesLedger->updateTransactionInLedger(oldTrans, newTrans);
    }

    cout << "Successfully updated." <<endl;
}

void Account::addTransactionToLedger(Transaction* newTransact){
    Income * inc = dynamic_cast<Income*>(newTransact); 
    Expenses * exp = dynamic_cast<Expenses*>(newTransact); 

    bool isIncome = (inc!=nullptr);
    bool isExpenses = (exp!=nullptr);

    double transactAmount = newTransact->getAmount();
    int gt = newTransact->getGoesTo();

    bool isRealized = newTransact->getHasRealized();
    
    if(isIncome){
        incomeLedger->addTransaction(newTransact);
        if(gt == 0){
            bankBalance += transactAmount;
            cout << transactAmount << " added into Bank. " << endl; 
        }else if(gt == 1){
            cashBalance += transactAmount;
            cout << transactAmount << " added into Cash. " << endl; 
            
        }
        cout << "Transaction amount " << transactAmount << " added" << endl;
        return;
    }
    
    if(isExpenses){
        if(gt == 0 && (transactAmount + bankBalance >= 0)){
            bankBalance += transactAmount;
            cout << transactAmount << " added into Bank. " << endl; 
        } else if(gt == 1 && (transactAmount + cashBalance >= 0)){
            cashBalance += transactAmount;
            cout << transactAmount << " added into Cash. " << endl; 
        } else if(gt == 2 && (transactAmount + creditCardBalance >= 0)){
            creditCardBalance += transactAmount;
            cout << transactAmount << " added into Credit Card. " << endl; 
        } else {
            cout << "Oh no! Not enough money to spend! :(" << endl;
            delete newTransact;
            return;
        }
        expensesLedger->addTransaction(newTransact);
        cout << "Transaction amount " << transactAmount << " added" << endl;
        return;
    }
    
    cout << "Fail to add the transaction! >.<" << endl;
    delete newTransact;
}

void Account::removeTransactionFromLedger(Ledger* led, int numTransact){
    int numTransInLedger = led->getCurrNumTrans();
    if(numTransInLedger == 0){
        cout << "Error! No transactions in this ledger!" <<endl;
        return;
    }

    Transaction* trans = led->getTransactionByNum(numTransact);
    
    if(trans == nullptr){
        return;
    }
    
    double transactAmount = trans->getAmount();
    int gt = trans->getGoesTo();
    
    led->removeSingleTransaction(numTransact);
    if(gt == 0){
        bankBalance -= transactAmount;
    }else if(gt == 1){
        cashBalance -= transactAmount;
    }else if(gt == 2){
        creditCardBalance -= transactAmount;
    }else{
        return;
    }

    cout << "An transaction has been removed successfully. " << endl; 
    
}

void Account::printBalance() const{
    cout << "Printing Balances" << endl;
    cout << "Bank: " << bankBalance << endl;
    cout << "Credit Card: " << creditCardBalance << endl;
    cout << "Cash: " << cashBalance << endl;
}

Account::~Account(){
    
    delete incomeLedger;
    delete expensesLedger; 
    
    cout << "All account records deleted." <<endl; 
}
