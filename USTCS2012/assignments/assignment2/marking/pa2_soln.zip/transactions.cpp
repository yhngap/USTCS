#include "transactions.h"
#include <iostream>
using namespace std;

Transaction::Transaction(double amount, bool hasRealized, string date, string describe){
    this->amount = amount;
    this->hasRealized = hasRealized;
    this->descriptions = describe; 
    this->date = date;
}

Transaction::~Transaction(){
    cout << "Transaction with " << amount << " dollars on " << date << " deleted." <<endl;
}

ostream& operator << (ostream &out, const Transaction &trans){
    return trans.printTransaction(out);
}

void Transaction::setAmount(double amount){
    this->amount = amount;
    cout << "Transaction with " << amount << " dollars on " << date << " added." <<endl;
}

double Transaction::getAmount() const{
    return amount;
}

bool Transaction::getHasRealized(){
    return hasRealized;
}

void Transaction::setHasRealized(){
    if(hasRealized){
		cout << "The transaction has realized already!" << endl;
        return;
	}
	
	hasRealized = true;
}

void Transaction::setDescriptions(string str){
	descriptions = str;
}

void Transaction::setDate(string str){
    date = str;
}


string Transaction::getDescriptions() const{
	return descriptions;
}

string Transaction::getDate() const{
    return date;
}