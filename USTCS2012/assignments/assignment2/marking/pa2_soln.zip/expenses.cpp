#include "expenses.h"
#include <iostream>
using namespace std;

// enum TransactionCategory {SALARY, POCKET_MONEY, INVEST_RETURNS, GIFTS}
// enum GoesTo {BANK, CASH}


Expenses::Expenses(double amount, bool hasRealized, string date, TransactionCategory ic, GoesTo gt, string description):
Transaction(amount, hasRealized, date, description), sources(ic), sumToWhere(gt)
{
    cout << "Expense with amount " << this->amount << " dated " << this->date << " initialized. " << endl;    
}

Expenses::~Expenses(){
    cout << "Expense with " << amount << " dollars on " << date << " deleted." <<endl;
}

void Expenses::setGoesTo(GoesTo gt){
    sumToWhere = gt;
    cout << "Expense has sent to " << sumToWhere << endl;
}

ostream& Expenses::printTransaction(ostream& out) const{
    string sSumToWhere;
    
    if(sumToWhere == BANK)
        sSumToWhere = "Bank";
    else if(sumToWhere == CASH)
        sSumToWhere = "Cash";
    else
        sSumToWhere = "Credit Card"; 
    
	out << "====================================="<<endl;
	out << "Expense: " << descriptions <<endl;
	out << "Expense Date: " << date <<endl; 
	out << "Amount: " << amount << endl;
	out << "Has been realized?: " << hasRealized << endl;
    out << "Amount added into: " << sSumToWhere <<endl;
	out << "=====================================" << endl;
    return out;
}

TransactionCategory Expenses::getCategory() const{
    cout << "Identifying which type of expenses is this..." << endl; 
    return sources;
}

GoesTo Expenses::getGoesTo() const{
    cout << "Identify where this expense goes to..." << endl; 
    return sumToWhere;
}