

void Account::addBalance(int option, double amount){
    if(option==0){
        bankBalance += amount;
    }else if(option==1){
        cashBalance += amount;
    }else if(option==2){
        creditCardBalance += amount;
    }else{
        cout << "Wrong balance option number!" << endl;
    }
}