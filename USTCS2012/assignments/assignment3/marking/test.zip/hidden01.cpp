//do NOT submit this file.
//you may modify it to test your own test cases.
//however, make sure that your code can be compiled with the unmodified version of this file.

#include <iostream>
#include <string>
#include <list>
#include "LibraryItem.h"
#include "Book.h"
#include "BST.h"
#include "HashTable.h"
#include "Library.h"

using namespace std;

template<typename T>
std::ostream &operator<<(std::ostream &os, const BST<T> &t) {
    t.printTree(os);
    return os;
}


std::ostream &operator<<(std::ostream &os, const Library &library) {
    os << "Library: " << library.getName() << ", Number of Library Item: " << library.getNumberOfItems();
    return os;
}

template<typename A, typename B>
std::ostream &operator<<(std::ostream &os, const HashTable<A, B> &ht) {
    ht.print(os);
    return os;
}

std::ostream &operator<<(std::ostream &os, const Mode &m) {
    switch (m) {
        case Mode::LINEAR:
            os << "LINEAR";
            break;

        case Mode::DOUBLE:
            os << "DOUBLE";
            break;

        case Mode::QUADRATIC:
            os << "QUADRATIC";
            break;
    }
    return os;
}

int main() {
    cout << boolalpha;

    //BST Leakage testcase
    int testCase = 101;

    cout << endl << "=== Test case " << testCase << " ===" << endl << endl;
    {
        BST<int> *bst1 = new BST<int>;
        cout << "add..." << endl;
        bst1->add("c", 3);
        bst1->add("a", 1);
        bst1->add("e", 5);
        bst1->add("b", 2);
        bst1->add("d", 4);
        cout << *bst1 << endl;
        cout << "remove..." << endl;
        bst1->remove("c");
        bst1->remove("d");
        cout << *bst1 << endl;
        BST<int> *bst2 = new BST<int>(*bst1);
        BST<int> *bst3 = new BST<int>;
        bst3->add("k", 9);
        cout << "bst2:" << endl;
        cout << *bst2 << endl;
        cout << "bst3:" << endl;
        cout << *bst3 << endl;
        delete bst1;
        delete bst2;
        delete bst3;
        cout << "deletion finishes... then we run valgrind." << endl;
    }//end of test case

    return 0;

}
