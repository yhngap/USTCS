//submit this file
//you do NOT need to include any header in this file
//just write your BST implementation here right away

using namespace std;

template <typename T>
BST<T>::BST(const BST &another)
{
    if (another.isEmpty())
    {
        root = nullptr;
        return;
    }

    root = new BSTNode<T>(*another.root);
}

template <typename T>
bool BST<T>::isEmpty() const
{
    return root == nullptr;
}

template <typename T>
bool BST<T>::add(string key, T value)
{
    if (this->isEmpty())
    {
        this->root = new BSTNode<T>(key, value);
        return true;
    }
    else if (key < this->root->key)
    {
        return this->root->left.add(key, value);
    }
    else if (key > this->root->key)
    {
        return this->root->right.add(key, value);
    }

    return false;
}

template <typename T>
bool BST<T>::remove(string key)
{
    if (this->isEmpty())
        return false;
    else if (key < this->root->key)
    {
        return this->root->left.remove(key);
    }
    else if (key > this->root->key)
    {
        return this->root->right.remove(key);
    }
    else //found key
    {
        bool hasLeftChild = this->root->left.root != nullptr;
        bool hasRightChild = this->root->right.root != nullptr;

        if (!hasLeftChild && !hasRightChild)
        {
            delete this->root;
            this->root = nullptr;
        }
        else if (hasLeftChild && hasRightChild)
        {
            const BST *minBST = this->root->right.findMin();
            this->root->key = minBST->root->key;
            this->root->value = minBST->root->value; //deep assignment
            this->root->right.remove(this->root->key);
        }
        else if (hasLeftChild)
        {
            BSTNode<T> *d = this->root;
            this->root = d->left.root;
            d->left.root = d->right.root = nullptr;
            delete d;
        }
        else if (hasRightChild)
        {
            BSTNode<T> *d = this->root;
            this->root = d->right.root;
            d->left.root = d->right.root = nullptr;
            delete d;
        }

        return true;
    }

    return false;
}

template <typename T>
T *BST<T>::get(string key) const
{
    if (!this->isEmpty())
    {
        if (this->root->key == key)
            return &this->root->value;
        else if (key < this->root->key && !this->root->left.isEmpty())
            return this->root->left.get(key);
        else if (key > this->root->key && !this->root->right.isEmpty())
            return this->root->right.get(key);
    }

    return nullptr;
}

template <typename T>
void BST<T>::getBetweenRangeHelper(const BST<T> *current_bst, string start, string end, list<T> *resultList) const
{
    if (current_bst->isEmpty())
    {
    }
    else
    {
        if (start < current_bst->root->key)
            this->getBetweenRangeHelper(&current_bst->root->left, start, end, resultList);

        if (start <= current_bst->root->key && end >= current_bst->root->key)
            resultList->push_back(current_bst->root->value);

        if (end > current_bst->root->key)
            this->getBetweenRangeHelper(&current_bst->root->right, start, end, resultList);
    }
}

template <typename T>
const BST<T> *BST<T>::findMin() const
{
    if (this->isEmpty())
        return nullptr;
    if (this->root->left.isEmpty())
        return this;
    else
        return this->root->left.findMin();
}
