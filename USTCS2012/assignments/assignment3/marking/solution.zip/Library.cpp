#include "Library.h"



Library::~Library()
{
    for(int i = 0; i<this->numberOfItems;i++){
        if(this->libraryItemArray[i]!=nullptr){
            delete this->libraryItemArray[i];
        }
    }
    cout << "Library " << name << " Destructed" <<endl;
}

void Library::addLibraryItem(LibraryItem *libraryItem) {
    if (numberOfItems >= MAX_NUMBER_ITEM) {
        cout << "Number of Items exceeded" << endl;
        return;
    } else {
        this->libraryItemArray[numberOfItems++] = libraryItem;
        this->bstIndex.add(to_string(libraryItem->getPublishedDate()), libraryItem);
        this->hashTableIndex.add(libraryItem->getName(), libraryItem);
    }
}

LibraryItem *Library::searchLibraryItemByExactName(string name) const {
    return this->hashTableIndex.get(name);
}

LibraryItem *Library::searchLibraryItemByExactPublishedDate(int targetDate) const {
    return *this->bstIndex.get(to_string(targetDate));
}

list<LibraryItem *> *Library::searchLibraryItemByPublishedDateRange(int startDate, int endDate) const {
    return this->bstIndex.getBetweenRange(to_string(startDate), to_string(endDate));
}

bool Library::borrowItem(string name) const {
    LibraryItem *item = this->searchLibraryItemByExactName(name);
    if (item == nullptr) {
        cout << "Item " << name << "was not found" << endl;
        return false;
    } else if (item->getIsInStock() == true) {
        cout << "Borrowed Item " << name << endl;
        item->setIsInStock(false);
        return true;
    } else {
        cout << "Item " << name << "is not in stock currently" <<endl;
        return false;
    }
}

bool Library::returnItem(string name) const {
    LibraryItem *item = this->searchLibraryItemByExactName(name);
    if (item == nullptr) {
        cout << "Item " << name << "was not found" << endl;
        return false;
    } else if (item->getIsInStock() == false) {
        item->setIsInStock(true);
        cout << "Returned Item " << name << endl;
        return true;
    } else {
        cout << "Item " << name << "is in stock currently" <<endl;
        return false;
    }
}
