//submit this file
//you do NOT need to include any header in this file
//just write your HashTable implementation here right away

template <typename K, typename T>
HashTable<K,T>::HashTable(int m, int (*h)(K), int (*h2)(int), Mode mode, double loadLimit, bool isReferenceOnly)
    : m(m), h(h), h2(h2), mode(mode), loadLimit(loadLimit),isReferenceOnly(isReferenceOnly)
{
    count = 0;
    table = new Cell[m];
    for(int i=0;i<m;i++)
    {
        table[i].data = nullptr;
        table[i].status = CellStatus::EMPTY;
    }

    //note: it is probably possible to just use "h2"
    //to represent different modes without actually using "mode"
    //as all modes are (special) cases of double-hashing
}


template <typename K, typename T>
HashTable<K,T>::~HashTable()
{
    if(this->isReferenceOnly==false){
        for(int i=0; i<m; i++){
            if (table[i].status == CellStatus::ACTIVE)
                delete table[i].data;
        }
    }
    delete [] table;
}

template <typename K, typename T>
HashTable<K,T>::HashTable(const HashTable& another)
{
    m = 0;
    table = nullptr;
    *this = another;
}

template <typename K, typename T>
void HashTable<K,T>::operator=(const HashTable& another)
{
    if(this->isReferenceOnly==false){
        for(int i=0; i<m; i++){
            if (table[i].status == CellStatus::ACTIVE)
                delete table[i].data;
        }
    }
    delete [] table;

    count = another.count;
    m = another.m;
    h = another.h;
    h2 = another.h2;
    mode = another.mode;
    loadLimit = another.loadLimit;
    table = new Cell[m];
    for(int i=0;i<m;i++)
    {
        table[i].key = another.table[i].key;
        table[i].data = another.table[i].data==nullptr?nullptr:new T(*another.table[i].data);
        table[i].status = another.table[i].status;
    }
}

//it is a helper function I made myself to shorten the code
template <typename K>
int offset(int i, int (*h2)(int), Mode mode)
{
    if(mode == Mode::LINEAR)
        return i;
    else if(mode == Mode::QUADRATIC)
        return i*i;
    else if(mode == Mode::DOUBLE)
        return i*h2(i);
    return 0;
}


template <typename K, typename T>
int HashTable<K,T>::add(K key, T* data)
{
    int occupied = count;

    if(occupied+1 > loadLimit*m) //if over-load
    {
        //probably another approach is to somehow keep a backup of the original table
        //then enlarge the current table 
        //then use the add function to add the cells from the backup table

        // std::cout << "over-load:" << count+1 << " > " << loadLimit*m << std::endl;

        int newM = m*2;
        Cell* newTable = new Cell[newM];
        for(int i=0;i<newM;i++)
        {
            newTable[i].data = nullptr;
            newTable[i].status = CellStatus::EMPTY;
        }
        count = 0;

        //add from the start of the old table array
        //assumption: do not need to handle any addition failure during the rehashing process
        for(int i=0;i<m;i++)
            if(table[i].status==CellStatus::ACTIVE)
            {
                for(int j=0; j<newM; j++)
                {
                    int os = offset<K>(j, h2, mode);
                    int hi = (h(table[i].key) + os) % newM;
                    if(newTable[hi].status == CellStatus::EMPTY || newTable[hi].status == CellStatus::DELETED)
                    {
                        newTable[hi].key = table[i].key;
                        newTable[hi].data = table[i].data;
                        newTable[hi].status = CellStatus::ACTIVE;
                        count++;
                        break;
                    }
                }
            }

        delete [] table;

        table = newTable;
        m = newM;

        // print(std::cout);
    }

    int collisions = 0;
    for(int i=0; i<m; i++)
    {
        int os = offset<K>(i, h2, mode);
        int hi = (h(key) + os) % m;
        if (table[hi].status == CellStatus::EMPTY || table[hi].status == CellStatus::DELETED) {
            // std::cout << "added at " << hi << " (" << h(key) << "+" << os << ")%" << m << std::endl;
            table[hi].key = key;
            table[hi].data = data;
            table[hi].status = CellStatus::ACTIVE;
            count++;
            return collisions;
        }
        // else std::cout << "collided at " << hi << " (" << h(key) << "+" << os << ")%" << m << std::endl;
        collisions++;
    }

    return -1; //to indicate failure
}


template <typename K, typename T>
bool HashTable<K,T>::remove(K key)
{
    for(int i=0; i<m; i++)
    {
        int os = offset<K>(i, h2, mode);
        int hi = (h(key) + os) % m;

        if(table[hi].status == CellStatus::ACTIVE)
        {
            if(table[hi].key == key) {
                if (this->isReferenceOnly == false) {
                    delete table[hi].data;
                }
                table[hi].data = nullptr;
                table[hi].status = CellStatus::DELETED;
                count--;
                return true;
            }
        }
    }
    return false;
}


template <typename K, typename T>
T* HashTable<K,T>::get(K key) const
{
    for(int i=0; i<m; i++)
    {
        int os = offset<K>(i, h2, mode);
        int hi = (h(key) + os) % m;

        if(table[hi].status == CellStatus::ACTIVE)
        {
            if(table[hi].key == key)
            {
                return table[hi].data;
            }
        }

        // std::cout << "missed at " << hi << std::endl;
    }

    return nullptr;
}
