import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorDemo {

    // Create a fixed thread pool with maximum two threads
    static ExecutorService executor = Executors.newFixedThreadPool(3);

    public static void main(String[] args) {
        // Submit runnable tasks to the executor
        executor.execute(new PrintChar('a', 20));
        executor.execute(new PrintChar('b', 20));
        executor.execute(new PrintChar('c', 20));

        // Shut down the executor
        executor.shutdown();
    }
}