public class TaskThreadJoinDemo {
    public static void main(String[] args) {

        // Create tasks and threads
        var thread1 = new Thread(new PrintChar('a', 20));
        var thread2 = new Thread(new PrintCharJoin('b', 20));
        var thread3 = new Thread(new PrintChar('c', 20));

        // Start threads
        thread1.start();
        thread2.start();
        thread3.start();
    }
}

class PrintCharJoin implements Runnable {
    private char charToPrint; // The character to print
    private int times;        // The times to repeat

    /**
     * Construct a task with specified character and number of
     * times to print the character
     */
    public PrintCharJoin(char c, int t) {
        charToPrint = c;
        times = t;
    }

    /**
     * Override the run() method to tell the system
     * what the task to perform
     */
    @Override
    public void run() {
        Thread thread4 = new Thread(new PrintCharSleep('d', 20));
        thread4.start();
        try {
            for (var i = 0; i < times; i++) {
                System.out.print(charToPrint);
                if (i >= 10) // at least 10 chars printed after thread4 completion
                    thread4.join();
            }
        } catch (InterruptedException ex) {
        }
    }
}