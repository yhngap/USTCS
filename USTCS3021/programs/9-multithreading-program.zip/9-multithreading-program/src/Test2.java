public class Test2 {
    public static void main(String[] args) throws InterruptedException {
        Thread t = new Thread(()->{
            System.out.println("Thread finished");
        });
        t.start(); t.sleep(10000);
        System.out.println("Main finished");
    }
}