public class TaskThreadDemo {
    public static void main(String[] args) {

        // Create tasks and threads
        var thread1 = new Thread(new PrintChar('a', 10));
        var thread2 = new Thread(new PrintChar('b', 20));
        var thread3 = new Thread(new PrintChar('c', 20));

        // Start threads
        thread1.start();
        thread2.start();
        thread3.start();
    }
}

class PrintChar implements Runnable {
    private char charToPrint; // The character to print
    private int times;        // The times to repeat

    /**
     * Construct a task with specified character and number of
     * times to print the character
     */
    public PrintChar(char c, int t) {
        charToPrint = c;
        times = t;
    }

    /**
     * Override the run() method to tell the system
     * what the task to perform
     */
    @Override
    public void run() {
        for (var i = 0; i < times; i++)
            System.out.print(charToPrint);
    }
}