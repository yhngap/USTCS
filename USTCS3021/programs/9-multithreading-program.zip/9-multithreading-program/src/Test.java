public class Test implements Runnable {
        public static void main(String[] args) {
            System.out.println("Main Thread ID: " + Thread.currentThread().getId());
            new Test();
            Base b = new Derived();
            b.g();
        }
        public Test() {
            // What can we put here to display “test” at console?
//            Thread t = new Thread(this); t.start();
//            this.run();
        }
        public void run() { System.out.println("Thread ID: " + Thread.currentThread().getId() + " test"); }
}


/* Test synchronization overriding */
abstract class Base {
        abstract
//        synchronized // 0:
        void f();
        synchronized void g() { notify(); }
}

class Derived extends Base {
        @Override
        public synchronized void f() {}  // 1: synchronized can override non-synchronized

        @Override
        public void g() {  // 2: non-synchronized can override synchronized
                super.g();
//                notify();  // 3: synchronized is not inherited
        }

//        synchronized Derived() {} : 4
}
