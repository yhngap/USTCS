import java.util.Scanner;

public class PalindromeIgnoreNonAlphanumeric {
  public static void main(String[] args) {
    var input = new Scanner(System.in);
    System.out.print("Enter a string: ");
    var s = input.nextLine();
    System.out.println("Is " + s + " a palindrome? " + isPalindrome(s));
  }
	
  // Return true if a string is a palindrome
  public static boolean isPalindrome(String s) {
    // Create a new string by eliminating non-alphanumeric chars
    var s1 = filter(s);
    // Create a new string that is the reversal of s1
    var s2 = reverse(s1);
    // Compare if the reversal is the same as the original string
    return s2.equals(s1);
  }
  
  // Create a new string by eliminating non-alphanumeric chars
  public static String filter(String s) {
    var stringBuilder = new StringBuilder();
    // Examine each char in the string to skip alphanumeric char
    for(var i = 0; i < s.length(); i++) {
      if (Character.isLetterOrDigit(s.charAt(i)))
        stringBuilder.append(s.charAt(i));
    }
    // Return a new filtered string
    return stringBuilder.toString();
  }

  // Create a new string by reversing a specified string
  public static String reverse(String s) {
    var stringBuilder = new StringBuilder(s);
    stringBuilder.reverse(); // Invoke reverse in StringBuilder
    return stringBuilder.toString();
  }
}