// FindCharSubString.java
public class FindCharSubString {
  public static void main(String[] args) {
    var str = "Welcome to Java";
    var ind1 = str.indexOf('W');        // Returns 0
    var ind2 = str.indexOf('x');        // Returns -1, not found
    var ind3 = str.indexOf('o', 5);     // Returns 9
    var ind4 = str.indexOf("come");     // Returns 3
    var ind5 = str.indexOf("Java", 5);  // Returns 11
    var ind6 = str.indexOf("java", 5);  // Returns -1, not found
    var ind7 = str.lastIndexOf('a');    // Returns 14
    var ind8 = str.lastIndexOf('e', 5); // Retrurns 1
    
    System.out.println("ind1: " + ind1 + ", ind2: " + ind2 + ", ind3: " + ind3 +
                       ", ind4: " + ind4 + ", ind5: " + ind5 + ", ind6: " + ind6 +
                       ", ind7: " + ind7 + ", ind8: " + ind8);
  }
}