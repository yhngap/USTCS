// StringLength.java	
public class CharacterExtraction {
  public static void main(String[] args) {
    var message = "Welcome to Java";
    var firstChar = message.charAt(0);
    var secondChar = message.charAt(1);
    var lastChar = message.charAt(message.length()-1);
    System.out.println("Extracted characters: " + 
                       firstChar + secondChar + lastChar);
  }
}