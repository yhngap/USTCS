import java.util.Scanner;
public class CheckPalindrome {
  public static void main(String[] args) {
    var input = new Scanner(System.in);
    System.out.print("Enter a string: ");
    var s = input.nextLine();
    if(isPalindrome(s))
      System.out.println(s + " is a palindrome");
    else
      System.out.println(s + " is not a palindrome");
    input.close();
  }
  // Check if a string is a palindrome
  public static boolean isPalindrome(String s) {
    var low = 0; // The index of the first character in the string
    var high = s.length() - 1; // The index of the last character in the string
    while (low < high) {
      if(s.charAt(low) != s.charAt(high))
        return false; // Not a palindrome
      low++;
      high--;
    }
    return true; // The string is a palindrome
  }
}