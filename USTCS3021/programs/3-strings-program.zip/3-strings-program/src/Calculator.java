public class Calculator {
  public static void main(String[] args) {    
    if(args.length != 1) { // Check number of strings passed
      System.out.println("Usage: java Calculator \"operand1 operator operand2\"");
      System.exit(0);
    }
    var tokens = args[0].split(" "); // The result of the operation
    var result = // The result of the operation
    switch (tokens[1].charAt(0)) {
      case '+' ->
        Integer.parseInt(tokens[0]) + Integer.parseInt(tokens[2]);
      case '-' ->
        Integer.parseInt(tokens[0]) - Integer.parseInt(tokens[2]);
      case '*' ->
        Integer.parseInt(tokens[0]) * Integer.parseInt(tokens[2]);
      case '/' ->
        Integer.parseInt(tokens[0]) / Integer.parseInt(tokens[2]);
      default -> 0;
    };
    System.out.println(tokens[0] + ' ' + tokens[1] + ' ' + tokens[2] + 
                       " = " + result);
  }
}