public class InternedString {
  public static void main(String[] args) {
    var s1 = "Java"; // interned string
    var s2 = new String("Java");
    var s3 = "Java"; // interned string
    System.out.println("s1 == s2 is " + (s1 == s2));
    System.out.println("s1 == s3 is " + (s1 == s3));
  }
}
