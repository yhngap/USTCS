public class FormatString {
  public static void main(String[] args) {
    var one = 20456654;
    var two = 100567890.248907;
    var str = String.format("The rank is %,d out of %,.2f", one, two);
    // Outputs "The rank is 20,456,654 out of 100,567,890.25"
    System.out.println(str);
  }
}