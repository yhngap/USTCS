// TestMain.java
public class TestMain {
  public static void main(String[] args) {
    System.out.println("args.length: " + args.length);
    for (var s: args)
      System.out.print(" " + s);
  }
}