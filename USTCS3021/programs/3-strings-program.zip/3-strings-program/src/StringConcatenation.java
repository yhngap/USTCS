// StringConcatenation.java	
public class StringConcatenation {
  public static void main(String[] args) {
    var str1 = "COMP3021 ";
    var str2 = "Java Programming";
    var str3 = str1.concat(str2);
    var str4 = str1 + str2;
    System.out.println(str3);
    System.out.println(str4);
  }
}