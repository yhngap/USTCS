// StringComparison.java
public class StringComparison {
  public static void main(String[] args) {
    var s1 = new String("Welcome");
    var s2 = "Welcome";

    if (s1.equals(s2))
      System.out.println("s1 and s2 have the same contents");

    if (s1 == s2)
      System.out.println("s1 and s2 have the same reference");

    if (s1.compareTo(s2) > 0)
      System.out.println("s1 is greater than s2");
    else if (s1.compareTo(s2) == 0)
      System.out.println("s1 and s2 have the same contents");
    else
      System.out.println("s1 is less than s2");  
  }
}