// ExtractString.java
public class ConvertReplaceSplitStrings {
  public static void main(String[] args) {
    var str1 = "Welcome all";
    var str2 = str1.toLowerCase(); // Returns a new string "welcome all"
    var str3 = str1.toUpperCase(); // Returns a new string "WELCOME ALL"
    var str4 = str1.substring(0, 8).trim(); // Returns a new string "Welcome"
    var str5 = str1.replace('e', 'A'); // Returns a new string "WAlcomA all"
    // Returns a new string "WABlcome all"
    var str6 = str1.replaceFirst("e", "AB");
    // Returns a new string "WABlcomAB all"
    var str7 = str1.replace("e", "AB");
    // Returns a new string "WABcome all"
    var str8 = str1.replace("el", "AB");
    System.out.println("str2: " + str2 + "\nstr3: " + str3 + "\nstr4: " + str4 + "\nstr5: " + str5 +
        "\nstr6: " + str6 + "\nstr7: " + str7 + "\nstr8: " + str8);

    var seqTokens1 = "COMP3021 is great!".split(" ");
    for (var token: seqTokens1)
      System.out.println(token);
    var seqTokens2 = "COMP3021 is great!".split(" ", 0);
    for (var token: seqTokens2)
      System.out.println(token);
  }
}