// ExtractString.java
public class ExtractString {
  public static void main(String[] args) {
    var str1 = "Welcome to Java";
    var str2 = str1.substring(0,10); // "Welcome to" is extracted
    var str3 = str1.substring(11);   // "Java" is extracted
  }
}