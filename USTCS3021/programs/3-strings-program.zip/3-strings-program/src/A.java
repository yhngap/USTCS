// A.java
public class A {
  public static void main(String[] args) {
    String[] strings = { "New York", "Boston", "Atlanta" };
    B.main(strings);
  }
}	

class B {
  public static void main(String[] args) {
    for (var i: args)
    System.out.println(i);
  }
}
