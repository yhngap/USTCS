// StringLength.java	
public class StringLength {
  public static void main(String[] args) {
    var message = "Welcome to Java";
    var len = message.length(); // returns 15
    System.out.println("Number of characters in message: " + len);
  }
}