public class Person {
  String name = ""; int age;
  public Person(String name, int age) {
    this.name = name;
    this.age = age;
  }
/*
  public String toString(){
    return name + " is a person of " + age + " years old";
  }
*/
  public static void main(String [] args) {
    var p = new Person("Peter Wong", 19);
    System.out.println(p.toString());
    System.out.println(p); // invoke p.toString()
  }
}
