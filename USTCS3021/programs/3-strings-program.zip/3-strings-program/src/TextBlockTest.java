public class TextBlockTest {
    public static void main(String[] args) {
        var html = """
                <html>
                    <body>
                        <p>Hello, world</p>
                    </body>
                </html>
                """;
        System.out.println(html);
    }
}
