// ConvertCharNumberToStrings.java
public class ConvertCharNumberToStrings {
  public static void main(String[] args) {
    var str1 = String.valueOf(true);        // Returns "true"
    var str2 = String.valueOf('a');         // Returns "a"
    char[] chArr = { 'a', 'b', 'c' };
    var str3 = String.valueOf(chArr);       // Returns "abc"
    var str4 = String.valueOf(chArr, 1, 2); // Returns "bc"
    var str5 = String.valueOf(5.44);        // Returns "5.44"
    var str6 = String.valueOf(1.2F);        // Returns "1.2"
    var str7 = String.valueOf(1024);        // Returns "1024"
    var str8 = String.valueOf(32768L);      // Returns "32768"
    
    System.out.println("str1: " + str1 + ", str2: " + str2 + ", str3: " + str3 +
                       "\nstr4: " + str4 + ", str5: " + str5 + ", str6: " + str6 +
                       "\nstr7: " + str7 + ", str8: " + str8);
  }
}