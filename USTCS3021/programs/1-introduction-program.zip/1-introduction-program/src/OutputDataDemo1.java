// Filename: OutputDataDemo1.java
/* An example showing how to output data on screen */
public class OutputDataDemo1 {
  public static void main(String[] args) {
    int val = 9;
    System.out.println(val);
    System.out.print("You should be able to see this text ");
    System.out.println("on screen");
    System.out.print("How about this text?");
    System.out.print("Can you see the effect?");	
  }
}