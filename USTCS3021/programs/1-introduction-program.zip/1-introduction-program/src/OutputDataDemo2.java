// Filename: OutputDataDemo2.java
/* An example showing how to output different types of data on screen */
public class OutputDataDemo2 {
  public static void main(String[] args) {
    String str = "Tom";
    char gender = 'M';
    int age = 18;
    double height = 1.71;
    System.out.println("Hi " + str);
    System.out.println("Your age is " + age);
    System.out.println("Your gender is " + gender);
    System.out.println("Your height is " + height + 'm');
  }
}