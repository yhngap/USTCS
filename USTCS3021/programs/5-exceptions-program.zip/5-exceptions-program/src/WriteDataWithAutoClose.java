// WriteDataWithAutoClose.java
import java.io.File;
import java.io.PrintWriter;
public class WriteDataWithAutoClose {
  public void saveTeachingTeamMemberNames() throws Exception {
    var file = new File("COMP3021-teaching-team.txt");
    try (
      var writer = new PrintWriter(file); // create a file
    ) {
      // Write formatted output to the file
      String[] members = { "Shing-Chi Cheung", "Richard Hu", "Victor Tian" };
      for (int i=0; i<members.length; i++) {
        writer.print(members[i]);  // print the ith member name
        if (i < members.length - 1) // if it is not the last
          writer.print("\n");      // move to the next line
      }
    } // JVM automatically closes the file when exiting the try block
  }
  
  public static void main(String[] args) {
    var demo = new WriteDataWithAutoClose();
    try { demo.saveTeachingTeamMemberNames(); }
    catch (Exception e) {}
  }
}