// ReadFileDemo.java
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class ReadFileDemo {
  public void loadTeachingTeamMemberNames() throws Exception {
// Read a file into a string array
    var path = Paths.get("COMP3021-teaching-team.txt");
    var content = Files.readString(path);
    var members = content.split("\n");

    for (var s: members)
      System.out.println(s);
  }
  public static void main(String[] args) {
    var demo = new ReadFileDemo();
    try { demo.loadTeachingTeamMemberNames(); }
    catch (Exception e) {}
  }
}