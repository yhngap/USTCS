import java.io.IOException;

public class TestInterfaceWithException extends Impl {
  public static void main(String[] args) throws Exception {
    new Impl().n();
  }
}

interface Ifc1 {
  Ifc1 n()
          throws IOException;  // 1: Not throws exception?
}

interface Ifc2 {
//  Ifc2 n() throws NullPointerException;  // 3: throws different exception
//  Ifc2 n() throws Exception;  // 5: Exception is a supertype of IOException
}

class Impl implements Ifc1, Ifc2 {
  public Impl n()
  throws IOException // 2: comments out; 4: keeps 3 and comments out
  {
    return new Impl();
  }
}