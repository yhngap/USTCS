import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class NonNull {
  void notnullf(@NotNull Object o) {} // Stop early at the point of error; prevent further data corruption
  void nullf(@Nullable Object o) {}
  static void catchIllegalArgumentException(NonNull o) {
    try {
      o.notnullf(null);
    } catch (IllegalArgumentException e) {
      System.out.println(e);
    }
  }
  public static void main(String[] args) {
//    var o = new NonNull(); // 2
    NonNull o = new NonNullChild(); // 2
    o.notnullf(null);  // 1
//    catchIllegalArgumentException(o); // 1
  }
}

class NonNullChild extends NonNull {

  @Override // 2: Runtime checking; not compile time checking
  void notnullf(@Nullable Object o) {
    System.out.println(o.toString());
  }

/*  @Override // 3 Created for runtime validation only; no compile time checking
  void nullf(@NotNull Object o) {}*/
}
