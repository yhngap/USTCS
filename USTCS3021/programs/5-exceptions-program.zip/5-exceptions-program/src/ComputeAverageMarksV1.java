// ComputeAverageMarksV1.java
// An example of abusing use of exception
import java.util.Scanner;

public class ComputeAverageMarksV1 {
  public static void main(String[] args) {
    var numOfStudents = 0;
    var totalMarks = 0.0;
    var avgMarks = 0.0;
    var sc = new Scanner(System.in);
    System.out.print("Enter number of students: ");
    numOfStudents = sc.nextInt();

    try {
      if (numOfStudents <= 0)
        throw new Exception("Error: no of students must not equal to 0!");
    } catch (Exception e) {
      System.out.println(e.getMessage());
      System.out.println("Program Terminating!");
      sc.close();
      System.exit(0);
    } finally {
    }
    System.out.print("Enter student marks: ");
      for (var i = 0; i < numOfStudents; i++)
        totalMarks += sc.nextDouble();
      avgMarks = totalMarks / (double) numOfStudents;
      System.out.println("Average marks = " + avgMarks);
      System.out.println("End of program execution!");
      sc.close();
  }
}