// FormatString.java
public class FormatString {
  public static void main(String args[]) {
    var sb = new StringBuilder("Hello ");
    sb.append("COMP3021 Students");
    System.out.println(sb);
  }  
}