import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Motivation {
  String filename;

  public Motivation() {
    // Ask users for the input filename
    System.out.print("Input Filename: ");
    var sc = new Scanner(System.in);
    filename = sc.nextLine();
  }

  public void readMemberNames() throws Exception {

    // Create a File and a Scanner object
    var inputFile = new File(filename);
    var sc = new Scanner(inputFile);
    var members = new String[4];

    // Read the content using a loop
    for (var i=0; i<members.length; i++) {
      members[i] = sc.nextLine();
      System.out.println(members[i]);
    }
    // close the file and print the results
    sc.close();
  }
		
  public static void main(String[] args) {
    Motivation demo = null;
    try {
      demo = new Motivation();
      demo.readMemberNames(
      );
    } catch(Exception e) {
      System.out.println("Please check if " + demo.filename + " is a valid non-empty text file!");
/*
      System.out.println(e.getMessage());
      e.printStackTrace();
*/
    }
  }
} 