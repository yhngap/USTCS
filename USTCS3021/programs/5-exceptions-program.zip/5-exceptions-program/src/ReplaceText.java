// ReplaceText.java
import java.io.*;
import java.util.*;

public class ReplaceText {
  public static void main(String[] args) throws Exception {    
    if (args.length != 4) { // Check command line parameter usage
      System.out.println("Usage: java ReplaceText sourceFile targetFile" + 
                         " oldStr newStr");
      System.exit(1);
    }    
    var sourceFile = new File(args[0]); // Check if source file exists
    if (!sourceFile.exists()) {
      System.out.println("Source file " + args[0] + " does not exist");
      System.exit(2);
    }    
    var targetFile = new File(args[1]); // Check if target file exists
    if (targetFile.exists()) {
      System.out.println("Target file " + args[1] + " already exists");
      System.exit(3);
    }
    try ( // Create input and output files      
      var input = new Scanner(sourceFile);
      var output = new PrintWriter(targetFile);
    ) {
      while (input.hasNext()) {
        var s1 = input.nextLine();
        var s2 = s1.replaceAll(args[2], args[3]);
        output.println(s2);
      }
    }
  }
}	