import java.io.File;
import java.util.Scanner;

public class MotivationRethrow {
  String filename;

  public MotivationRethrow() {
    // Ask users for the input filename
    System.out.print("Input Filename: ");
    Scanner sc = new Scanner(System.in);
    filename = sc.nextLine();
  }

  public void readMemberNames() throws Exception {
    Scanner sc = null;
    try {
      // Create a File and a Scanner object
      var inputFile = new File(filename);
      sc = new Scanner(inputFile);
      String[] members = new String[3];

      // Read the content using a loop
      for(var i=0; i<members.length; i++) {
        members[i] = sc.nextLine();
        System.out.println(members[i]);
      }
      // close the file
      sc.close();
    } catch (Exception e) {
      // Cannot leave file closing to its caller who does not have a reference to the file object
      sc.close();
      /*
       Suppose readMemberNames() is written to be used also by other classes
       The decision of actions to be taken when an exception occurs should be made
       by its caller function, like main() here. So, readMemberNames() needs to rethrow
       the exception to let its caller decide what to do.
     */
      throw e; // rethrow exception
    }
  }
		
  public static void main(String[] args) {
    MotivationRethrow demo = null;
    try {
      demo = new MotivationRethrow();
      demo.readMemberNames();
    } catch(Exception e) {
      System.out.println("Please check if " + demo.filename + " is a valid non-empty text file!");
    }
  }
} 