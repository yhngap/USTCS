// ComputeAverageMarksV1.java
// Better handle simple expected situation directly using if-statement
import java.util.Scanner;

public class ComputeAverageMarksV2 {
  public static void main(String[] args) {
    var numOfStudents = 0;
    var totalMarks = 0.0;
    var avgMarks = 0.0;
    var sc = new Scanner(System.in);
    System.out.print("Enter number of students: ");
    numOfStudents = sc.nextInt();

    if (numOfStudents <= 0) {
      System.out.println("Error: no of students must not equal to 0!");
      System.out.println("Program Terminating!");
    } else {
      System.out.print("Enter student marks: ");
      for (var i = 0; i < numOfStudents; i++)
        totalMarks += sc.nextDouble();
      avgMarks = totalMarks / (double) numOfStudents;
      System.out.println("Average marks = " + avgMarks);
      System.out.println("End of program execution!");
    }
    sc.close();
  }
}