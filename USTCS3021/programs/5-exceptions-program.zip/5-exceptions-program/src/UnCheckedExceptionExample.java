class UnCheckedExceptionExample {
  private double radius;
  private static int numberOfObjects = 0;

  public UnCheckedExceptionExample(double newRadius) {
    setRadius(newRadius);
    numberOfObjects++;
  }

  public double getRadius() {
    return radius;
  }

/*   2: Can we explicitly declare throwing unchecked exception
        If so, does compiler force this exception to be caught*/
  public void setRadius(double newRadius)
//      throws IllegalArgumentException
  {
    if (newRadius >= 0)
      radius = newRadius;
    else // IllegalArgumentException is a subclass of RuntimeException
      throw new IllegalArgumentException("Radius cannot be negative");
  }

  public static int getNumberOfObjects() {
    return numberOfObjects;
  }

//  1: Does compiler forces us to catch the unchecked exception?
  public static void main(String[] args) {
    try {
      new UnCheckedExceptionExample(5);
      new UnCheckedExceptionExample(-5);
      new UnCheckedExceptionExample(0);
    } catch (IllegalArgumentException ex) {
      System.out.println(ex);
    }
    System.out.println("Number of objects created: " + getNumberOfObjects());
  }
}
