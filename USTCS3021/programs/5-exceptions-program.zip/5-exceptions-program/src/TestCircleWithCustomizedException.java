public class TestCircleWithCustomizedException {
  public static void main(String[] args) {
    try {
      new CircleWithCustomizedException(5);
      new CircleWithCustomizedException(-5);
      new CircleWithCustomizedException(0);
    } catch (InvalidRadiusException ex) {
      System.out.println(ex);
    }

    System.out.println("Number of objects created: " +
        CircleWithCustomizedException.getNumberOfObjects());
  }
}

class CircleWithCustomizedException {
  /**
   * The radius of the circle
   */
  private double radius;

  /**
   * The number of the objects created
   */
  private static int numberOfObjects = 0;

  /**
   * Construct a circle with radius 1
   */
  public CircleWithCustomizedException() throws InvalidRadiusException {
    this(1.0);
  }

  /**
   * Construct a circle with a specified radius
   */
  public CircleWithCustomizedException(double newRadius)
      throws InvalidRadiusException {
    setRadius(newRadius);
    numberOfObjects++;
  }

  /**
   * Return radius
   */
  public double getRadius() {
    return radius;
  }

  /**
   * Set a new radius
   */
  public void setRadius(double newRadius)
      throws InvalidRadiusException {
    if (newRadius >= 0)
      radius = newRadius;
    else
      throw new InvalidRadiusException(newRadius);
  }

  /**
   * Return numberOfObjects
   */
  public static int getNumberOfObjects() {
    return numberOfObjects;
  }

  /**
   * Return the area of this circle
   */
  public double findArea() {
    return radius * radius * 3.14159;
  }
}
