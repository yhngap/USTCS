// WriteDataDemo.java
import java.io.File;
import java.io.PrintWriter;

public class WriteDataDemoOld {
  public void saveTeachingTeamMemberNames() throws Exception {
    var outputFile = new File("COMP3021-teaching-team.txt");
    var writer = new PrintWriter(outputFile);
    String[] members = { "Shing-Chi Cheung", "Richard Hu", "Victor Tian" };
    for (var i=0; i<members.length; i++) {
      writer.print(members[i]);  // print the ith member name
      if (i < members.length - 1) // if it is not the last
        writer.print("\n"); // move to the next line
    }
    writer.close(); // IMPORTANT! close the file to write the content
  }
	
  public static void main(String[] args) {
    var demo = new WriteDataDemoOld();
    try { demo.saveTeachingTeamMemberNames(); }
    catch (Exception e) {}
  }
}