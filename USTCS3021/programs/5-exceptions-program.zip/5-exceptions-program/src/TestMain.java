import java.io.IOException;

// TestMain.java
public class TestMain {
  public static void main(String[] args) {
    System.out.println("args.length: " + args.length);
    for(var i=0; i<args.length; i++)
      System.out.println("args[" + i + "]: " + args[i]);
  }
}

class MyIOException extends IOException {}
class Super {
    void f() throws IOException {}
}

class Sub extends Super {
//    void f() throws Exception {}
//    void f() throws MyIOException {}
//    void f() throws ClassNotFoundException {}
//    void f() throws IOException {}
//    void f() {}
//    void f() throws RuntimeException, Error {}
}