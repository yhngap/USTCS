import java.io.File;
import java.util.Scanner;

public class MotivationRethrowResources {
  String filename;

  public MotivationRethrowResources() {
    // Ask users for the input filename
    System.out.print("Input Filename: ");
    var sc = new Scanner(System.in);
    filename = sc.nextLine();
  }

  public void readMemberNames() throws Exception {
    var inputFile = new File(filename);
    try (var sc = new Scanner(inputFile)) { // try with resources
      var members = new String[3];
      // Read the content using a loop
      for(var i=0; i<members.length; i++) {
        members[i] = sc.nextLine();
        System.out.println(members[i]);
      }
    } catch (Exception e) {
      throw e; // rethrow exception
    }
  }
		
  public static void main(String[] args) {
    MotivationRethrowResources demo = null;
    try {
      demo = new MotivationRethrowResources();
      demo.readMemberNames();
    } catch(Exception e) {
      System.out.println("Please check if " + demo.filename + " is a valid non-empty text file!");
    }
  }
} 