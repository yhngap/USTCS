import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class MotivationMultipleExceptions {
  String filename;

  public MotivationMultipleExceptions() {
    // Ask users for the input filename
    System.out.print("Input Filename: ");
    var sc = new Scanner(System.in);
    filename = sc.nextLine();
  }

  public void readMemberNames() throws FileNotFoundException, NoSuchElementException {

    // Create a File and a Scanner object
    var inputFile = new File(filename);
    var sc = new Scanner(inputFile);
    var members = new String[3];

    // Read the content using a loop
    for(var i=0; i<members.length; i++)
      members[i] = sc.nextLine();

    // close the file and print the results
    sc.close();
    for (var i=0; i<members.length; i++)
      System.out.println(members[i]);
  }
		
  public static void main(String[] args) {
    MotivationMultipleExceptions demo = null;
    try {
      demo = new MotivationMultipleExceptions();
      demo.readMemberNames();
    } catch (FileNotFoundException e) {
      System.out.println("Please check if " + demo.filename + " exists!");
    } catch (NoSuchElementException e) {
      System.out.println("Please check if " + demo.filename + " contains valid records!");
    } catch (Exception e) {
      System.out.println("Please check if " + demo.filename + " is a valid non-empty text file!");
    }
  }
} 