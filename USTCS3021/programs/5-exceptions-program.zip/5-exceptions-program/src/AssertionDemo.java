// AssertionDemo.java
public class AssertionDemo {
  public static void main(String[] args) {
    var sum = 0;
    var i = 0;
    for(; i < 10; i++)
      sum += i;
    assert i == 10;
    assert sum > 10 && sum < 5 * 10 : "sum is " + sum;
  }
}