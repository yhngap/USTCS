// WriteDataDemo.java
import java.nio.file.Files;
import java.nio.file.Paths;

public class WriteDataDemo {
  public void saveTeachingTeamMemberNames() throws Exception {
    var path = Paths.get("COMP3021-teaching-team.txt");
    var members = "Shing-Chi Cheung\n"
            + "Jialun Cao\n"
            + "Wuqi Zhang\n"
            + "David Mak";
    Files.writeString(path, members);
  }
	
  public static void main(String[] args) {
    var demo = new WriteDataDemo();
    try { demo.saveTeachingTeamMemberNames(); }
    catch (Exception e) {}
  }
}