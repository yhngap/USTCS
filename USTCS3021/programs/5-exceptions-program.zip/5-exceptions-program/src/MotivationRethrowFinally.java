import java.io.File;
import java.util.Scanner;

public class MotivationRethrowFinally {
  String filename;

  public MotivationRethrowFinally() {
    // Ask users for the input filename
    System.out.print("Input Filename: ");
    var sc = new Scanner(System.in);
    filename = sc.nextLine();
  }

  public void readMemberNames() throws Exception {
    Scanner sc = null;  // 1: May we declare sc without initialization?
    try {
      // Create a File and a Scanner object
      var inputFile = new File(filename);
      sc = new Scanner(inputFile);
      var members = new String[3];

      // Read the content using a loop
      for(var i=0; i<members.length; i++) {
        members[i] = sc.nextLine();
        System.out.println(members[i]);
      }
      return;
    } catch (Exception e) {
      System.out.println("Catch");
      throw e; // rethrow exception
    } finally {
      System.out.println("Finally");
      sc.close();
    }
  }
		
  public static void main(String[] args) {
    MotivationRethrowFinally demo = null;
    try {
      demo = new MotivationRethrowFinally();
      demo.readMemberNames();
    } catch(Exception e) {
      System.out.println("Please check if " + demo.filename + " is a valid non-empty text file!");
    }
  }
} 