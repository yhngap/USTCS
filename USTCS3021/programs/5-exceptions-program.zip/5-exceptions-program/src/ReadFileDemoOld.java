// ReadFileDemo.java
import java.io.File;
import java.util.Scanner;
public class ReadFileDemoOld {
  public void loadTeachingTeamMemberNames() throws Exception {
// Create a File and a Scanner object
    var inputFile = new File("COMP3021-teaching-team.txt");
    var sc = new Scanner(inputFile);
// Create an array of strings
    var members = new String[3];
// Read the content using a loop
    for (int i=0; i<members.length; i++)
      members[i] = sc.nextLine();
// close the file and print the results
    sc.close();
    for (int i=0; i<members.length; i++)
      System.out.println(members[i]);
  }
  public static void main(String[] args) {
    var demo = new ReadFileDemoOld();
    try { demo.loadTeachingTeamMemberNames(); }
    catch (Exception e) {}
  }
}