public class ComparableCircleWithGeneric extends Circle
    implements Comparable<Circle> {

  public static void main(String[] args) {
//    new ComparableCircleWithGeneric(1).compareTo("RED");
  }

  public ComparableCircleWithGeneric(double radius) {
    super(radius);
  }

  @Override
  // compilation error if o is not passed a circle
  public int compareTo(Circle o) {
    double diff = this.getArea() - o.getArea(); // casting is not needed
    if (diff > 0)
      return 1;
    else if (diff < 0)
      return -1;
    else
      return 0;
  }
}
