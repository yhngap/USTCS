import java.util.ArrayList;

public class OverridingMethod1 {
	public static void main(String[] args) {
		Pair<Number> p = new Interval();
		p.setSecond(3);
		p = new Interval1();
		p.setSecond(3);
	}
}

class Pair<E> {
	public void setFirst(E e) {
		this.first = e;
		System.out.println("setFirst");
	}	
	public void setSecond(E e) {
		this.second = e;
		System.out.println("Pair.setSecond");
	}
	public void print(ArrayList<? extends E> list) {}
	E first, second;
}

class Interval extends Pair {  // Wrong to use raw type
//	 setSecond(Number e) overloads rather than overrides setSecond(E e) 
//	@Override
/*	public void setSecond(Number e) {
		this.second = e;
		System.out.println("Interval.setSecond to "+e);
	}*/
//	 public <T> void setSecond(T t) {}   // same erasure but not overriding
//	 public void setSecond(Object t) {}   // overriding
//	 public void print(ArrayList<Integer> list) {}  // same erasure but not overriding
//	 public <T> void print(ArrayList<? extends T> list) {}  // same erasure but not overriding
//	 public <T> void print(ArrayList<? extends Object> list) {}  // same erasure but not overriding
//  public <T> void print(ArrayList<Object> list) {}  // same erasure but not overriding
}

class Interval1 extends Pair<Number> {  // Bind E to Number before checking overriding
	@Override
	public void setSecond(Number e) {
		this.second = e;
		System.out.println("Interval1.setSecond to "+e);
	}
	@Override
	public void print(ArrayList<? extends Number> list) {}
}