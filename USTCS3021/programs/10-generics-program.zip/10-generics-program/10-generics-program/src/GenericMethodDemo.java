public class GenericMethodDemo {
  public static void main(String[] args) {
    Integer[] integers = {1,2,3,4,5};
    String[] strings = { "London", "Paris", "New York", "Austin" };
    Object[] objects = { "London", "Paris", "New York", "Austin", 1 };

    GenericMethodDemo.<Integer>printOne(integers);
    GenericMethodDemo.<String>printOne(strings);
//    GenericMethodDemo.<String>printOne(objects);  //
    GenericMethodDemo.printOne(objects); // can be used like printTwo
    System.out.println("===");
    GenericMethodDemo.printTwo(integers);
    GenericMethodDemo.printTwo(strings);
    GenericMethodDemo.printTwo(objects);
  }
  public static <E> void printOne(E[] list) {
    for (int i = 0; i < list.length; i++)
      System.out.print(list[i] + " ");
    System.out.println();
  }
  public static void printTwo(Object[] list) {
    for (int i = 0; i < list.length; i++)
      System.out.print(list[i] + " ");
    System.out.println();
  }
}