public class TestPolymorphicType {
    void check() {
        Comparable<?> ca = "welcome";
        Comparable<Object> co = null;
//        co = "hello";
//        co = (Comparable<Object>) "hello";

//        Comparable<? extends Object> f = "hello";
//        ca = f;

//        co = ca;
        co = (Comparable<Object>) ca;
//        ca = co;
//        Comparable c = ca;
//        Comparable<Comparable<?>> cc = co;
//        Comparable<Comparable<?>> cc = (Comparable<Comparable<?>>) co;
    }
}

