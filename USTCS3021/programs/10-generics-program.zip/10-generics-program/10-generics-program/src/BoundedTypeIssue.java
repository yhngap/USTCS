import java.util.ArrayList;

public class BoundedTypeIssue {
	public static void main(String[] args) {
		
		ArrayList<Rectangle> rectangle = new ArrayList<>(2);
		rectangle.add(new Rectangle(2, 2));
		rectangle.add(new Rectangle(4, 4));
		ArrayList<Circle> circle = new ArrayList<>(2);
		circle.add(new Circle(2));
		circle.add(new Circle(4));
//		System.out.println("Total area of rectangles = "+ getTotalArea(rectangle));
//		System.out.println("Total area of rectangles = "+ getTotalArea((ArrayList<GeometricObject>)rectangle));
	}
	public static double getTotalArea(ArrayList<GeometricObject> object) {
		double totalArea = 0;
		for (GeometricObject o : object) totalArea += o.getArea();
		return totalArea;
	}
} 