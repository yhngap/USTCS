import java.util.Date;

public class Compare {

  static void compareWithoutUsingTemplate() {
    Comparable c = new Date();
    System.out.println(c.compareTo("red"));
  }

  static void compareUsingTemplate() {
/*    Comparable<Date> c = new Date();
    System.out.println(c.compareTo("red"));*/
  }
  public static void main(String[] args) {
    compareWithoutUsingTemplate();
    compareUsingTemplate();
  }
}
