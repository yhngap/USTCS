import java.util.ArrayList;
import java.util.List;

public class Motivation {
    public static void main(String[] args) {
        var cities = new ArrayList();
        cities.add(new Object());
        cities.add("Hong Kong");
        cities.add(Integer.valueOf(1));
//        var i =  (String) cities.get(0);
//        ArrayList<String> c = new ArrayList<>(); // 2
//        c.add(new Object());
//        var i =  (Integer) c.get(0);  // 2
//        System.out.println(i.compareTo(i));
    }
}
