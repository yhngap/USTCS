public class SensorDemo {

	static SpeedSensor ss = new SpeedSensor();
	static TemperatureSensor ts = new TemperatureSensor();
	
	public static void main(String[] args) {
		System.out.println(SensorDemo.equalsFixedType(ss, ts));
		System.out.println(SensorDemo.equals(ss, ts));
//		SensorDemo.<SpeedSensor>equals(ss, ts);
	}
	static boolean equalsFixedType (Sensor s1, Sensor s2) {
		return s1.getValue() == s2.getValue();
	}
	static <E extends Sensor> boolean equals(E s1, E s2) {
		return s1.getValue() == s2.getValue();
	}

}

abstract class Sensor {
	double accuracy; 
	abstract double getValue();
}

class SpeedSensor extends Sensor {
	private double speed;
	double getValue() {
		return speed;
	}
}

class TemperatureSensor extends Sensor {
	private double temperature;
	double getValue() {
		return temperature;
	}
}