import java.util.ArrayList;

public class GenericConstructors {
	ArrayList<? extends Number> list;
	<E extends Number> GenericConstructors(E o) {
		var list = new ArrayList<E>();
		list.add(o);
		this.list = list;
	}
	public static void main(String[] args) {
		System.out.println(new <Integer>GenericConstructors(0).list);
		System.out.println(new <Double>GenericConstructors(0.1).list);
	}
}
