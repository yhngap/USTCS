import java.util.ArrayList;

public class BoundedTypeDemo {
	public static void main(String[] args) {
		var rectangle = new Rectangle(2, 2);
		var circle = new Circle(2);
		System.out.println("Same area? "	+ equalArea(rectangle, circle));
	}

/*	public static <E> boolean equalArea(E object1, E object2) {
		return object1.getArea() == object2.getArea(); // compilation error
	}*/
	
	static <E extends GeometricObject> boolean equalArea(E object1, E object2) {
		return object1.getArea() == object2.getArea();
	}
//	<E> void f(ArrayList< E extends Number > e) { }
//	<E extends Comparable<ArrayList< E >>> E f(ArrayList< E > e) { return null; }
}

//abstract class A implements Comparable< > { }
//abstract class A implements Comparable< E extends A > { }
//abstract class A< E > extends Number implements Comparable< E > { }
