public class TestInstanceof<E> {
  public static void main(String [] args) {
	  var intStack = new GenericStack<Integer>();
	  var rawStack = new GenericStack();
	  System.out.println(intStack instanceof GenericStack);
//	  System.out.println(intStack instanceof GenericStack<Object>);
//	  System.out.println(rawStack instanceof GenericStack<Object>);
	  System.out.println(intStack instanceof GenericStack<?>);
	  System.out.println(rawStack instanceof GenericStack<?>);
  }
}