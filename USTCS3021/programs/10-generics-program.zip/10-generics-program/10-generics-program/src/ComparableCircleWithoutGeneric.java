public class ComparableCircleWithoutGeneric extends Circle
    implements Comparable {

  public static void main(String[] args) {
    new ComparableCircleWithoutGeneric(1).compareTo("RED");
  }

  public ComparableCircleWithoutGeneric(double radius) {
    super(radius);
  }

  @Override
  // runtime error if o is not passed a circle
  public int compareTo(Object o) {
    double diff = this.getArea() - ((Circle) o).getArea();
    if (diff > 0)
      return 1;
    else if (diff < 0)
      return -1;
    else
      return 0;
  }
}
