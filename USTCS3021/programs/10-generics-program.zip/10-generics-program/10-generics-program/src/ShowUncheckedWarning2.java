import java.util.ArrayList;
public class ShowUncheckedWarning2 {
  public static void main(String[] args) {
    ArrayList<String> list = new ArrayList<String>();
    list.add("Java Programming");
  }
}