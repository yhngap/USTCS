import java.util.ArrayList;
public class ShowUncheckedWarning {
  public static void main(String[] args) {
    ArrayList list = new ArrayList();
    list.add("Java Programming");
  }
}