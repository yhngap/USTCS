import java.util.ArrayList;

public class BoundedTypeArrayList2 {

	public static void main(String[] args) {
		
		ArrayList<Rectangle> rectangle = new ArrayList<>(2);
		rectangle.add(new Rectangle(2, 2));
		rectangle.add(new Rectangle(4, 4));
		ArrayList<Circle> circle = new ArrayList<>(2);
		circle.add(new Circle(2));
		circle.add(new Circle(4));
		System.out.println("Total area of rectangles = "+ getTotalArea(rectangle));  
		System.out.println("Total area of circles = "+ getTotalArea(circle));  
	}
	public static <E extends GeometricObject> double getTotalArea(ArrayList<E> object) {
		double totalArea = 0;
		for (E o : object) totalArea += o.getArea();
//		for (var o : object) totalArea += o.getArea();
		return totalArea;
	}
}
