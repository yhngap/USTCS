import java.util.ArrayList;

public class GenericClassAsType {
  public static void main(String [] args) {
	    var stack = new GenericStack<Integer>();
//	    func1(stack);
		func2(stack);
		func3(stack);
  }

	public static void func1(GenericStack<Object> o) {	}

	public static void func2(GenericStack o) {}

	// GenericStack raw type can be thought of GenericStack<?>
	public static void func3(GenericStack<?> o) {	}
}