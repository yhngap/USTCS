public class TestPolymorphicType {
    public static void main(String[] args) {
        Comparable<?> ca = "welcome";
        Comparable<Object> co = null;
        co = "hello";
        co = (Comparable<Object>) "hello";

        Comparable<? extends String> f = "hello";
//        ca = f;
//        f = ca;
        System.out.println(ca instanceof Comparable<? extends String>);
        System.out.println(f instanceof Comparable<?>);

//        co = ca;
//        co = (Comparable<Object>) ca;
//        ca = co;
//        Comparable c = ca;
//        Comparable<Comparable<?>> cc = co;
//        Comparable<Comparable<?>> cc = (Comparable<Comparable<?>>) co;
    }
}

