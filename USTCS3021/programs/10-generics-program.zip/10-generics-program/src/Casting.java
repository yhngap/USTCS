import java.util.ArrayList;

public class Casting {

  static void castingWithoutTemplate() {
    var list = new ArrayList();
    list.add("Red");
    list.add(1);
//    String s = list.get(0); // 1: Casting is needed
//    String s = (String) list.get(0);  // 1: Casting is needed
  }

  static void castingWithTemplate() {
    var list = new ArrayList<String>();
    list.add("Red");
    list.add("White");
    var s = list.get(0); // 1: No casting is needed
  }

  static void autounboxing() {
    var list = new ArrayList<Double>();
    list.add(5.5); // 5.5 is automatically converted to new Double(5.5)
//    list.add(3); //  0: 3 cannot be automatically converted to new Double(3.0)
    list.add((double) 3);
    var doubleObject = list.get(0); // No casting is needed
    double d = list.get(1); // automatically converted to double
  }

  public static void main(String[] args) {
    castingWithoutTemplate();  // 1
    castingWithTemplate();
    autounboxing();
  }
}
