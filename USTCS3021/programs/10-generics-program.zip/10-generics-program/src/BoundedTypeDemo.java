import java.util.ArrayList;

public class BoundedTypeDemo {
	public static void main(String[] args) {
		var rectangle = new Rectangle(2, 2);
		var circle = new Circle(2);
		System.out.println("Same area? "	+ equalArea(rectangle, circle));
	}

/*	public static <E> boolean equalArea(E object1, E object2) {
		return object1.getArea() == object2.getArea(); // 1: compilation error
	}*/
	
	static <E extends GeometricObject> boolean equalArea(E object1, E object2) {
		return object1.getArea() == object2.getArea();
	}
}

// Define a Comparable abstract class so that its subclass implements the compareTo
//abstract class A implements Comparable { // 2:
//abstract class A < E > implements Comparable < E > { // 3:
//abstract class A< E extends A > implements Comparable< E > { // 4:
//	int bal;
//}

/*class SubA extends A { // 3
	@Override
	public int compareTo(Object o) {
		return Integer.valueOf(bal).compareTo(((A) o).bal); // unsafe
	}
}*/

/*class SubA extends A<SubA> {
	@Override
	public int compareTo(SubA o) {
		return Integer.valueOf(bal).compareTo(o.bal); // 4: safe
	}
}*/
