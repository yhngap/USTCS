package junit;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

class RectangleWithJUnit5ExceptionTest {
    /*
        @Test
        public void testGetArea() {
            Rectangle r1 = new Rectangle(4,4);
            double expected = 16;
            double actual = r1.getArea();
            assertEquals(expected, actual, tolerance);
        }
    */
    //@Test(expected = IllegalArgumentException.class) // JUnit 4 Exception Checking
    @Test
    public void testResize() throws Exception {
        Rectangle r1 = new Rectangle(4,4); // change this to -4 and comment out throws in resize
        double expectedHeight = 1;
        double expectedWidth = 8;
        // want to check if resize is properly implemented to throw exception
        assertThrows(IllegalArgumentException.class, () -> r1.resize(-0.25, 2));
//		assertEquals(expectedHeight, r1.getHeight(), tolerance,"resize - height fails");
//		assertEquals(expectedWidth, r1.getWidth(), tolerance,"resize - width fails");
    }
    /*
        @Test
        public void testGetPerimeter() {
            Rectangle r1 = new Rectangle();
            r1.setWidth(2);
            r1.setHeight(4);
            double expectedPerimeter = 12;
            double actualPerimeter = r1.getPerimeter();
            assertEquals(expectedPerimeter, actualPerimeter,tolerance);
            // assertEquals(actualObject.equals(expectedObject));
        }
    */
    final static double tolerance = 0.0001;

}
