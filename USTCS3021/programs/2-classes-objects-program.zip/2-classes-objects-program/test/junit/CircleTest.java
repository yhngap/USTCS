package junit;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CircleTest {
    static final double delta = 0.00001;
    @BeforeEach
    void setUp() {
        // create objects and common variables for your tests here
        // setUp() is called before EACH test case is run
    }

    @AfterEach
    void tearDown() {
        // put code here to reset or release objects, e.g., p1=null;
        // to garbage collect unused objects or resources
        // tearDown() is called after EACH test case is run
    }

    @Test
    void getArea() {
        var c = new Circle(10);
        Assertions.assertEquals(100*Math.PI, c.getArea(), delta, "getArea() fails");
    }

    @Test
    void getRadius() {
        var c = new Circle(10);
        Assertions.assertEquals(10, c.getRadius(), delta, "getRadius() fails");
    }
}