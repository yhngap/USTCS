package junit;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

//import org.junit.jupiter.api.Test;

@DisplayName("Parameterized Unit Tests")
class RectangleJUnit5PUTest {
    @ParameterizedTest
    @ValueSource(doubles = {0, 2, 4, -1})  // support single parameter for strings, ints, longs, doubles
    public void testConstructor(double width) throws Exception {
        if (width < 0)
            assertThrows(IllegalArgumentException.class, () -> new Rectangle(width, 2*width));
        else {
            Rectangle r = new Rectangle(width, 2*width);
            assertTrue(r != null && r instanceof Rectangle, "Construction error");
        }
    }

    @ParameterizedTest(name = "run #{index} with args [{arguments}]")
    @CsvSource( {
            "0, 0, 0, 'getArea fails for 0x0'",
            "2, 4, 8, 'getArea fails for 2x4'",
            "4, 8, 32, 'getArea fails for 4x8'"
    })
    // @CsVFileSource(resources = "parameters.csv")
    public void testGetArea(double width, double height, double expectedArea, String msg) {
        Rectangle r1 = new Rectangle(width, height);
        assertEquals(expectedArea, r1.getArea(), tolerance, msg);
    }

    final static double tolerance = 0.0001;
}
