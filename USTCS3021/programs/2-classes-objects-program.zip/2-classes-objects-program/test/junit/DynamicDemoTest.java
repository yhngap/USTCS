package junit;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import java.util.stream.IntStream;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertTrue;

//import org.junit.jupiter.api.Test;

class DynamicDemoTest {
    @TestFactory
    Stream<DynamicTest> test() {
        // Generates tests for the first 10 even integers; each generated test is a stream.
        return IntStream
                .iterate(0, n->n+2)
                .limit(20)
                .mapToObj(n -> DynamicTest.dynamicTest("test"+n, () -> assertTrue(n%2 ==0)));
    }
}
