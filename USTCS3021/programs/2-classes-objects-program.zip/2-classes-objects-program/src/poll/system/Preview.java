package poll.system;

abstract class Prototype {
    public static final int HASHKEY = 99881;
}

public class Preview extends Prototype {
    // preview functionalities
}

