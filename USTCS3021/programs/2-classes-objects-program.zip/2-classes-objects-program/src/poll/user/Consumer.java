package poll.user;
import poll.system.Preview;

public class Consumer {
    public static void main(String[] args) {
        System.out.printf("%d\n", Preview.HASHKEY);
    }
}
