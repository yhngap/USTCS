// Test.java                
public class AccessPrivateTest {
  public static void main(String[] args) {
    DefConstr a = new DefConstr();
/*    System.out.println(a.x);
    System.out.println(a.convert(a.x));*/
  }
}