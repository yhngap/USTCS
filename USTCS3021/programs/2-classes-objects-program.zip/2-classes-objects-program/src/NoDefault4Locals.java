public class NoDefault4Locals {
    public static void main(String[] args) {
      int x;    // x does not have a default value
      String y; // y does not have a default value
/*      System.out.println("x is " + x);
      System.out.println("y is " + y);*/
    }
}
