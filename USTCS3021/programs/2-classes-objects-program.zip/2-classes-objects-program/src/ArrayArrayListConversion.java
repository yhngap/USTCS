import java.util.ArrayList;
import java.util.Arrays;

public class ArrayArrayListConversion {
  public static void main(String args[]) {
    // Could copy it to JShell and demonstrate
    // Create an ArrayList from an array
    String[] sarray = {"red", "green", "blue"};
    var slist = new ArrayList<String>(Arrays.asList(sarray));

    // Create an array of objects from an ArrayList
    var array1 = new String[slist.size()];
    slist.toArray(array1);

    // Shuffling an ArrayList
    Integer[] array = {3, 5, 95, 4, 15, 34, 3, 6, 5};
    var list = new ArrayList<Integer>(Arrays.asList(array));
    java.util.Collections.shuffle(list);
    System.out.println(list);
  }
}
