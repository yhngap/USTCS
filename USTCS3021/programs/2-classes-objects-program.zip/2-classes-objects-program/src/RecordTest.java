import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RecordTest {
    public static void main(String args[]) {
        String[] authors = {"Mary", "Peter"};
        var b1 = new Book("Java Tutorial", Arrays.asList(authors));
        var b2 = new Book("Java Tutorial", Arrays.asList(authors));
        System.out.println(b1.title() + " " + b1.authors());    // check getters
        System.out.println(b1);                     // check toString
        System.out.println(b1 == b2);
        System.out.println(b1.equals(b2));  // check equals
        System.out.println(b1.hashCode() + " " + b2.hashCode());
        var b3 = new Book("Old Java Tutorial");
        System.out.println(b3);
    }
}

// Preview feature of Java 14
record Book(String title, List<String> authors) {
    public Book(String title) {
        this(title, new ArrayList<String>());
    }
    public Book {
        if (title == null || title.length() == 0)
            throw new IllegalArgumentException();
        if (authors.isEmpty())
            authors.add("Anonymous");
    }
}

// class Magazine extends Book;
