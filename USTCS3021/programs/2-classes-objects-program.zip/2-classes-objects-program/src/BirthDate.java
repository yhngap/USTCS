// BirthDate.java
public class BirthDate {
  private int year;
  private int month;
  private int day;
  
  public BirthDate(int newYear, int newMonth, int newDay) {
    year = newYear;
    month = newMonth;
    day = newDay;
  }
  
  public void setYear(int newYear) {
    year = newYear;
  }

  @Override
  public String toString() {
    return new String(day +"/" + month + "/" + year);
  }
}