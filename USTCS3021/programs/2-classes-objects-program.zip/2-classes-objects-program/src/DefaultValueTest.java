public class DefaultValueTest {

  static private class Student {
    String name; // name has default value null
    int age; // age has default value 0
    boolean isScienceMajor; // isScienceMajor has default value false
    char gender; // c has default value '\u0000'
  }

  public static void main(String[] args) {
    var student = new Student();
    System.out.println("name? " + student.name);
    System.out.println("age? " + student.age);
    System.out.println("gender? " + (student.gender=='\u0000'?"\\u0000":""));
    System.out.println("isScienceMajor? " + student.isScienceMajor);
  }
}