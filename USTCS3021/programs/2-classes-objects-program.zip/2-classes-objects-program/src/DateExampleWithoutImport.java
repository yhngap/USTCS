// DateExampleWithoutImport.java
// Without import statement	
public class DateExampleWithoutImport {
  public static void main(String[] args) {
    var date = new java.util.Date();
    System.out.println(date.toString());

    System.out.println("New usages:");
    var localDateNow = java.time.LocalDateTime.now();
    System.out.println(localDateNow);
    var localDate = java.time.LocalDate.now();
    System.out.println(localDate);
    var localNow = java.time.LocalTime.now();
    System.out.println(localNow);
    var utcNow = java.time.Instant.now(); // coordinated universal time
    System.out.println(utcNow);
  }
}