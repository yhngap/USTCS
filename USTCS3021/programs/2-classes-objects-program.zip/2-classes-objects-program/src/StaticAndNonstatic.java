// StaticAndNonstatic.java
public class StaticAndNonstatic {
  private int i = 5;
  private static double k = 0;

  void setI(int i) {
     this.i = i;
  }

  static void setK(double k) {
    StaticAndNonstatic.k = k;
  }
}