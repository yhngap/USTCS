// StaticInstanceExample.java
public class StaticInstanceExample
{
  private int instanceVar;
  private static int staticVar;
  static final int ZERO = 0;
  static final double PI = 3.14126;

  public void instanceMethod() {
    instanceVar = 30; // valid
    staticVar = 40;   // valid
  }

  public static void staticMethod() {
//     instanceVar = 10; // invalid
    staticVar = 20;   // valid
  }
}