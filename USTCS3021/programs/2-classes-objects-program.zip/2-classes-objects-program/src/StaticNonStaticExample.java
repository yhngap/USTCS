// StaticNonStaticExample.java		
public class StaticNonStaticExample
{
  private int instanceVar;
  private static int staticVar;
  
  public static void staticMethod() {
//    instanceVar = 10; // invalid
    staticVar = 20;   // valid
  }
  public void nonStaticMethod() {
    instanceVar = 30; // valid
    staticVar = 40;   // valid
  }
}