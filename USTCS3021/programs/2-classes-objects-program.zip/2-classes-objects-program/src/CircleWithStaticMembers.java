// CircleWithStaticMembers.java	
public class CircleWithStaticMembers {
  double radius;                  // instance variable
  static int numberOfObjects = 0; // static / class variable

  CircleWithStaticMembers() {
    radius = 1.0;
    numberOfObjects++;
  }

  CircleWithStaticMembers(double newRadius) {
    radius = newRadius;
    numberOfObjects++;
  }

  // Static / Class method
  static int getNumberOfObjects() { return numberOfObjects; }

  // Method
  double getArea() { return radius * radius * Math.PI; }
}	