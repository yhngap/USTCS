// TotalArea.java      
public class TotalArea {

  public static Circle [] createCircleArray() {
    var circleArr = new Circle[10];
    for (var i = 0; i < circleArr.length; i++)
      circleArr[i] = new Circle(Math.random()*100);
    return circleArr;
  }

  public static double sum(Circle[] circleArr) {
    var sum = 0.0;
/*
    for (int i = 0; i < circleArr.length; i++)
      sum += circleArr[i].getArea();
*/
    for (var c: circleArr)  // enhanced for loop
      sum += c.getArea();
    return sum;
  }  
  
  public static void printCircleArray(Circle[] circleArr) {
    System.out.printf("%-30s%-15s\n", "Radius", "Area");
/*
    for (int i = 0; i < circleArr.length; i++)
      System.out.printf("%-30f%-15f\n", circleArr[i].getRadius(), circleArr[i].getArea());
*/
    for (var c: circleArr)
      System.out.printf("%-30f%-15f\n", c.getRadius(), c.getArea());

    System.out.printf("%-30s%-15f\n", "The total areas of circles is", sum(circleArr));
  }
  
  public static void main(String[] args) {
    var circleArr = createCircleArray();
    printCircleArray(circleArr);
  }  
}