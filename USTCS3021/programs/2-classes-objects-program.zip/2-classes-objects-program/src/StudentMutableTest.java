// StudentMutableTest.java
public class StudentMutableTest {
  public static void main(String[] args) {
    Student student = new Student(1980, 5, 3);
    BirthDate date = student.getBirthDate();
    System.out.println("Student's birthday before setYear: " + date);
    date.setYear(2010); // Now the student birth year is changed!
    System.out.println("Student's birthday after setYear: " + student.getBirthDate());
  }
}