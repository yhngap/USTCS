// Note: In this example, all the instance variables are declared
//       with default visability
public class Person {
  String name;            // name has default value null
  int age;                // age has default value 0
  char gender;            // gender has default value '\u0000'
  boolean isScienceMajor; // isScienceMajor has default value false  
}