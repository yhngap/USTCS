// TestCircle.java
public class TestCircle {
  /** Main method */
  public static void main(String[] args) {
    // Create a circle with radius 1
    var circle1 = new Circle();
    System.out.println("The area of a circle of radius "
        + circle1.getRadius() + " is " + circle1.getArea());

    // Creat a circle with radius 25
    var circle2 = new Circle(25);
    System.out.printf("The area of a circle of radius %.0f is %.2f\n",
        circle2.getRadius(), circle2.getArea());

    // Create a circle with radius 125
    var circle3 = new Circle(125);
    System.out.printf("The area of a circle of radius %.0f is %,.2f\n",
        + circle3.getRadius(), circle3.getArea());

    System.out.println(Circle.numOfObjects + " circles were created.");
//    System.out.println(circle1.numOfObjects + " circles were created.");
//    Circle.main(null);
  }
}