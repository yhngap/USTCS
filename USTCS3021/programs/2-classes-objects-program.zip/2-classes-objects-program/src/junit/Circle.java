package junit;

// DefConstr simple Circle1 class
public class Circle {
  private double radius; // instance variable
  public static int numOfObjects; // static variable

  public Circle(double radius) { // constructor
    this.radius = radius;
    ++numOfObjects;
  }

  public Circle() { // no-arg constructor
    this(1.0);
  }

  public double getArea() { // instance method
    return this.radius * this.radius * Math.PI;
  }

  /** Return the radius of this circle */
  double getRadius() { // instance method
    return radius;
  }

  public static void main(String[] args) { // static method
    var c = new Circle();
    System.out.println("Area of a unit circle is: " + c.getArea());
    new Circle().getArea();
//    c.radius = 1;
  }
}  