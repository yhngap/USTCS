// Student.java
public class Student {
  private BirthDate birthDate;

  public Student(int year, int month, int day) {
    birthDate = new BirthDate(year, month, day);
  }

  public BirthDate getBirthDate() {
    return birthDate;
  }

  public static void main(String[] args) {
    var student = new Student(1980, 5, 3);
    var date = student.getBirthDate();
    System.out.println(student.birthDate);
    date.setYear(2010); // Now the student birth year is changed!
    System.out.println(student.birthDate);
  }
}