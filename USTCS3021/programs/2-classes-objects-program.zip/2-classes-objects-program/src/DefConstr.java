// DefConstr.java
public class DefConstr {
  private boolean x = true;
  public DefConstr() {
    int i = 0;
  }
  DefConstr(int x) {}

  public static void main(String[] args) {
    var a = new DefConstr();
    System.out.println(a.x);
    System.out.println(a.convert(a.x));
  }

  private int convert(boolean b) {
    return x ? 2 : -2;
  }
} 