// DateExampleWithImport.java
// With import statement

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Date;

public class DateExampleWithImport {
  public static void main(String[] args) {
    var date = new Date();
    System.out.println(date);

    System.out.println("New usages:");
    var localDateNow = LocalDateTime.now();
    System.out.println(localDateNow);
    var localDate = LocalDate.now();
    System.out.println(localDate);
    var localNow = LocalTime.now();
    System.out.println(localNow);
    var utcNow = Instant.now(); // coordinated universal time
    System.out.println(utcNow);
  }  
}