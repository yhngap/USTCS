// TestGeometricObject.java

import org.jetbrains.annotations.NotNull;

public class TestGeometricObject {
  public static void main(String[] args) {
    GeometricObject geo = new Circle(5);
    var geoArray = new GeometricObject[10];
    
    for (int i=0; i<5; i++)
      geoArray[i] = new Circle(i+1);
    for (int i=5; i<10; i++)
      geoArray[i] = new Rectangle(i+1, i+2);
    
    for(GeometricObject g : geoArray) {
      if (g instanceof Circle)
        System.out.println("Circle (Radius = " + 
                           ((Circle)g).getRadius() + "): " +
                           "Area = " + g.getArea() + 
                           ", Perimeter = " + g.getPerimeter());
      if (g instanceof Rectangle)
        System.out.println("Rectangle (Width = " + 
                           ((Rectangle)g).getWidth() + 
                           ", Height = " + 
                           ((Rectangle)g).getHeight() + 
                           "): " + "Area = " + g.getArea() + 
                           ", Perimeter = " + g.getPerimeter());
    }
    System.out.println("Total area of these geometric objects are: " + getTotalArea(geoArray));
  }
  public static double getTotalArea(@NotNull GeometricObject [] geoArray) {
    var area = 0.0;
    for (var o: geoArray) area += o.getArea();
    return area;
  }
}