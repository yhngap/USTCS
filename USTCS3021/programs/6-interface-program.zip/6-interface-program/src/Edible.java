// Edible.java                
public interface Edible { public abstract String howToEat(); }