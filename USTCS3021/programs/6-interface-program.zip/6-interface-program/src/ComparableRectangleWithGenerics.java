import org.jetbrains.annotations.NotNull;

// ComparableRectangle.java
public class ComparableRectangleWithGenerics extends Rectangle
        implements Comparable<Rectangle> {
  /** Construct a ComparableRectangle with specified properties */
  public ComparableRectangleWithGenerics(double width, double height) {
    super(width, height);  }

    @Override // make sure that we are comparing with a rectangle
    public int compareTo(@NotNull Rectangle o) {
      return Double.valueOf(getArea()).compareTo(o.getArea());
    }
  
    @Override // Implement the toString method in GeometricObject
    public String toString() {
      return "Width: " + getWidth() + " Height: " + getHeight() + 
             " Area: " + getArea();
    }

    public static void main(String[] args) {
      ComparableRectangleWithGenerics rectangle1 = new ComparableRectangleWithGenerics(4, 5);
//      ComparableRectangleWithGenerics rectangle2 = new ComparableRectangleWithGenerics(3, 6);
      ComparableRectangle rectangle2 = new ComparableRectangle(3, 6);  // 1: legal?
      System.out.println(Max.max1(rectangle1, rectangle2) + " specifies a larger rectangle.");
      System.out.println("Return value of compareTo is: " + rectangle1.compareTo(rectangle2));
    }
}