import org.jetbrains.annotations.NotNull;

public class House implements Cloneable, Comparable<House> {

  private int id;
  private double area;
  private java.util.Date whenBuilt;

  public static void main(String args[]) throws CloneNotSupportedException {
	  var house1 = new House(1, 1750.50);
	  var house2 = (House) house1.clone();
	  System.out.println(house1);
	  System.out.println(house2);
	  System.out.println("Making shallow copy? " + (house1.whenBuilt == house2.whenBuilt));
	  System.out.println(house1.whenBuilt.equals(house2.whenBuilt));
  }
  
  public House(int id, double area) {
    this.id = id;
    this.area = area;
    whenBuilt = new java.util.Date();
  }

  public double getId() {
    return id;
  }

  public double getArea() {
    return area;
  }

  public java.util.Date getWhenBuilt() {
    return whenBuilt;
  }

  /** Override the protected clone method defined in the Object
    class, and strengthen its accessibility */

  @Override
  public House clone() {
    try {
      var h = (House) super.clone();
      h.whenBuilt = (java.util.Date) this.whenBuilt.clone(); // uncomment for deep copy
      return h;
    } catch (CloneNotSupportedException ex) {
      return null;
    }
  } 

  /** Implement the compareTo method defined in Comparable */
  @Override
  public int compareTo(@NotNull House h) {
    return Double.valueOf(area).compareTo(h.area);
  }
}