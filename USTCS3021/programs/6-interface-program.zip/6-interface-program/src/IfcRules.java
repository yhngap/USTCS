public interface IfcRules {
    public static final int i = 0;
    public abstract void compute();
}

class Demo implements IfcRules {
    public static void main(String[] arg) {
        System.out.println(IfcRules.i);
    }
    @Override
     public  void compute () {}
}