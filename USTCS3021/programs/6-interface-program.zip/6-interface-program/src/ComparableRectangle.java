import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

// ComparableRectangle.java
public class ComparableRectangle  extends Rectangle
        implements Comparable {
  /** Construct a ComparableRectangle with specified properties */
  public ComparableRectangle(double width, double height) {
    super(width, height);  }

    @Override // Implement the compareTo method defined in Comparable 
    public int compareTo(@NotNull Object o) {
      return Double.valueOf(getArea()).
          compareTo(((Rectangle) o).getArea());
    }

/*    @Override // 1: Is it an overriding method?
    public int compareTo(@NotNull Rectangle o) {
      return Double.valueOf(getArea()).compareTo((o.getArea());
    }*/
  
    @Override // Implement the toString method in GeometricObject
    public String toString() {
      return "Width: " + getWidth() + " Height: " + getHeight() + 
             " Area: " + getArea();
    }

    public static void main(String[] args) {
      ComparableRectangle rectangle1 = new ComparableRectangle(4, 5);
      ComparableRectangle rectangle2 = new ComparableRectangle(3, 6);
      System.out.println(Max.max1(rectangle1, rectangle2) + " specifies a larger rectangle.");
      System.out.println("Return value of compareTo is: " + rectangle1.compareTo(rectangle2));
    }
}