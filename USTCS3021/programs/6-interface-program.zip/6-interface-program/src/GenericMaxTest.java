public class GenericMaxTest {
	public static void main(String[] arg) {
		var s = (String) Max.max2("abc", "abd");
//	    s = (String) Max.max1(new Object(), new Object()); // 1
//		s = (String) Max.max2(new Object(), new Object()); // 2
		System.out.println(s);
	}
}

class Max {

	public static Comparable max1 (Comparable o1, Comparable o2) {
		if (o1.compareTo(o2) > 0)
			return o1;
		else
			return o2;
	}
	public static Object max2 (Object o1, Object o2) {
		if (((Comparable)o1).compareTo(o2) > 0)
			return o1;
		else
			return o2;
	}
}