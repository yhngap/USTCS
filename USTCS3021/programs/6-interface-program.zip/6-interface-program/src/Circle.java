import org.jetbrains.annotations.NotNull;

import java.io.IOException;

// Circle.java
public class Circle extends GeometricObject {
  private double radius;

  public Circle() {}
  public Circle(double radius) {
    this.radius = radius;
  }

  public Circle(double radius, String color, boolean filled) {
    this.radius = radius;
    setColor(color);
    setFilled(filled);
  }

  public double getRadius() { return radius; }
  public void setRadius(double radius) { this.radius = radius; }
  
  public double getArea() { return radius * radius * Math.PI; }
  public double getPerimeter() { return 2 * radius * Math.PI; }
  public boolean equals(Object o) {
    return radius == ((Circle) o).radius;
  }
}

interface MyInterface {
  public double value = 0.06;
  static double f() {return 0;}
}
