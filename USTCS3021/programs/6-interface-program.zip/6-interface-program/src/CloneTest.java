public class CloneTest {
  public static void main(String[] args) throws CloneNotSupportedException {
    var d = new Duck().clone(); // 6: Object.clone() makes a binary copy, including fields inherited from Bird
//    ((Bird) d).clone(); // 4: Can a duck be cloned as a bird?
//    ((Bird) new Duck()).clone();  // 6: Duck extends Bird and implements Cloneable; Duck and Bird override clone; Bird does not implement Cloneable; Can we still clone a Duck as if a Bird? // Java checks if the class of the dynamically binded clone implements Cloneable
    System.out.println("A clone of duck was created.");
  }
}

class Duck
//    extends Bird // 3: allow non-cloneable superclass?
//    implements Cloneable // 1: need to implements Cloneable? 5:
{
  @Override // 2: need to override Object.clone()?
  public Duck clone() throws CloneNotSupportedException {
    return (Duck) super.clone();
//    return new Duck(); // 5: needs to declare Cloneable?
  }
}

abstract class Bird {
  private boolean canFly = true; // 5
  public Bird() { this(true); }
  public Bird(boolean canfly) {this.canFly = canFly;}
/*  public Bird clone() throws CloneNotSupportedException { // 4.1 allows bird to be cloned
    return (Bird) super.clone();
  }*/

  // other methods ...
//  protected Object clone() throws CloneNotSupportedException { throw new CloneNotSupportedException(); } // 7: disallows bird to be cloned
//  abstract protected Object clone() throws CloneNotSupportedException; // 7: alternative
}