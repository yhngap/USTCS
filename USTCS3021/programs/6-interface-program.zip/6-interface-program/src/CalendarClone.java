import java.util.Calendar;
import java.util.GregorianCalendar;

public class CalendarClone {
  public static void main(String[] args) {
    var calendar = new GregorianCalendar(2003, 2, 1);
    var calendarCopy = (Calendar) calendar.clone();
    System.out.println("calendar == calendarCopy is " + (calendar == calendarCopy));
    System.out.println("calendar.equals(calendarCopy) is " + calendar.equals(calendarCopy));
  }
}
