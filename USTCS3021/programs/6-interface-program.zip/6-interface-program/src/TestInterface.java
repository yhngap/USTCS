public class TestInterface extends ImplA {
  public static void main(String[] args) {
    (new TestInterface()).n();
  }
}

interface IfcA {
  int i = 0;  // public static final int i = 0;
  IfcA n();  // public abstract void n();
//  void e() {} // 1: can e have implementation?
  public default void f() {} // 5: default method
}

interface IfcB {
  int i = 1;  // public static final int i = 0; // 3: cause ambiguities?
  IfcB n();  // public abstract void n(); // 2: cause ambiguities?
}

class ImplA implements IfcA, IfcB  // 2: cause ambiguities?
{
  public ImplA n() {
//    System.out.println(i); // 4: cause ambiguities now?
//    super.f();  // 5: call f() using super? applicable only to default method
    return new ImplA();
  }
  @Override  // 6: overriding default method
   public void f() {}

}

class AnotherClass extends ImplA {

}