import java.util.Arrays;
public class SortingNumbersStrings {
  public static void main(String[] args) {
    int[] numbers = { 3, 5, 19, 2, 6, 8, 9, 1 };
    String[] strings = { "Desmond", "Alex", "Brian", "SC" };
    
    Arrays.sort(numbers);
    System.out.println("Sorted numbers");
    for (int i : numbers)
      System.out.print(i + " ");      
    System.out.printf("%n%n");
    
    Arrays.sort(strings);
    System.out.println("Sorted strings");
    for (String str : strings)
      System.out.print(str + " ");
  }
}