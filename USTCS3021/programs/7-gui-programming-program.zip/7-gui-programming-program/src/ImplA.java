interface A extends Cloneable { Object clone(); }
public class ImplA implements A {
    @Override
//    public Object clone() { return super.clone(); }
//    public Object clone() throws CloneNotSupportedException { return super.clone(); }
//    public Object clone() { try{return super.clone();} catch(Exception e){ } }
//    public Object clone() {try{return super.clone();} catch(Exception e){ } return new Object(); }
    public Object clone() throws RuntimeException { try{return super.clone();} catch(Exception e) {return new Object();} }
}




