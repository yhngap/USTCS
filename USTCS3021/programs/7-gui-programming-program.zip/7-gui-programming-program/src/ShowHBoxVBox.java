import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ShowHBoxVBox extends Application {
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {    
    var pane = new BorderPane(); // Create a border pane
    pane.setTop(getHBox()); // Place nodes in the pane
    pane.setLeft(getVBox());
    Scene scene = new Scene(pane); // Create a scene
    primaryStage.setTitle("ShowHBoxVBox"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
  }
  // Define a method to return an HBox with two buttons and an image
  private HBox getHBox() {
    var hBox = new HBox(15);
    hBox.setPadding(new Insets(15, 15, 15, 15));
    hBox.setStyle("-fx-background-color: gold");
    hBox.getChildren().add(new Button("Computer Science"));
    hBox.getChildren().add(new Button("Mathematics"));
    ImageView imageView = new ImageView(new Image("james.jpg"));
    hBox.getChildren().add(imageView);
    return hBox;
  }
  // Define a method to return a VBox with five labels
  private VBox getVBox() {
    var vBox = new VBox(15);
    vBox.setPadding(new Insets(15, 5, 5, 5));
    vBox.getChildren().add(new Label("Courses"));
    Label[] courses = {new Label("COMP 1022P"),
                       new Label("COMP 2011"),
                       new Label("COMP 2012"),
                       new Label("COMP 3021")};

    for (var course: courses) {
      VBox.setMargin(course, new Insets(0, 0, 0, 15));
      vBox.getChildren().add(course);
    }
    return vBox;
  }

  public static void main(String[] args) {
    launch(args);
  }
}