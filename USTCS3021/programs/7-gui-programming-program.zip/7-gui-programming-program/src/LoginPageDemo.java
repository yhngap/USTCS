import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.control.Label;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Button;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.text.FontWeight;

// Assume all import statements are here
public class LoginPageDemo extends Application {
  @Override
  public void start(Stage stage) {
    var grid = new GridPane(); // Prepare a Scene Graph, user grid as root
    grid.setAlignment(Pos.CENTER);
    grid.setHgap(10);
    grid.setVgap(10);
    grid.setPadding(new Insets(25, 25, 25, 25));
    
    var sceneTitle = new Text("Welcome");
    sceneTitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
    grid.add(sceneTitle, 0, 0, 2, 1);
    
    var userName = new Label("User name:");
    grid.add(userName, 0, 1);
    var userTextField = new TextField();
    grid.add(userTextField, 1, 1);
    
    var password = new Label("Password:");
    grid.add(password, 0, 2);
    var passwordField = new PasswordField();
    grid.add(passwordField, 1, 2);
    
    var button = new Button("Sign in");
    var hBox = new HBox(10);
    hBox.setAlignment(Pos.BOTTOM_RIGHT);
    hBox.getChildren().add(button);
    grid.add(hBox, 1, 4);
    
    var scene = new Scene(grid, 300, 275);
    stage.setTitle("Login Demo");
    stage.setScene(scene);
    stage.show();
  }
  
  public static void main(String[] args) {
    launch(args);
  }
}