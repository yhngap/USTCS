import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.FlowPane;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;

public class TwoSceneDemo extends Application {
  Button buttonScene1, buttonScene2;
  Label labelScene1, labelScene2;
  FlowPane pane1, pane2;
  Scene scene1, scene2;
  Stage theStage;
    
  @Override
  public void start(Stage primaryStage) {
    theStage = primaryStage;
    
    buttonScene1 = new Button("To the second scene");
    buttonScene2 = new Button("To the first scene");
    buttonScene1.setOnAction(e-> buttonClicked(e));
    buttonScene2.setOnAction(e-> buttonClicked(e));
    labelScene1 = new Label("First scene");
    labelScene2=new Label("Second scene");
    
    pane1=new FlowPane();
    pane2=new FlowPane();
    pane1.setVgap(10);
    pane2.setVgap(10);
 
    pane1.setStyle("-fx-background-color: LightPink; -fx-padding: 10px;");
    pane2.setStyle("-fx-background-color: ghostWhite; -fx-padding: 10px;");
        
    pane1.getChildren().addAll(labelScene1, buttonScene1);
    pane2.getChildren().addAll(labelScene2, buttonScene2);
          
    scene1 = new Scene(pane1, 180, 100);
    scene2 = new Scene(pane2, 180, 100);
        
    primaryStage.setTitle("Two Scene Demo");
    primaryStage.setScene(scene1);
    primaryStage.show();
  }
 
  public void buttonClicked(ActionEvent e) {
    theStage.setScene( (e.getSource() == buttonScene1) ? scene2 : scene1 );
  }
  
  public static void main(String[] args) {
    launch(args);
  }  
}