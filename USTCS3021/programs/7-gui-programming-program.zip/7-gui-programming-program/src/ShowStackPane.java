import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class ShowStackPane extends Application {
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {    
    var stackPane = new StackPane(); // Create a scene
    stackPane.getChildren().add(new Button("Can you see me?"));
    stackPane.getChildren().add(new Button("No"));
    var scene = new Scene(stackPane, 200, 50);
    primaryStage.setTitle("Buttons in a stackpane"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
  }

  public static void main(String[] args) {
    launch(args);
  }
}	