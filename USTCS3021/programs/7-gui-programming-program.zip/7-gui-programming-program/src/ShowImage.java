import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ShowImage extends Application {
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {  
    var pane = new HBox(10); // Create a pane to hold the image views
    pane.setPadding(new Insets(5, 5, 5, 5));
    var image = new Image("james.jpg");
    pane.getChildren().add(new ImageView(image));
    var imageView1 = new ImageView(image);
    imageView1.setFitHeight(100);
    imageView1.setFitWidth(100);
    pane.getChildren().add(imageView1);
    var imageView2 = new ImageView(image);
    imageView2.setRotate(90);
    pane.getChildren().add(imageView2);
    var scene = new Scene(pane); // Create a scene and place it in the stage
    primaryStage.setTitle("ShowImage"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
  }
  public static void main(String[] args) { launch(args); }
}