import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;

public class MultiplePanesDemo extends Application {
  public void start(Stage stage) {
    var r1 = new Rectangle(150, 150, Color.GRAY);
    var r2 = new Rectangle(150, 150, Color.rgb(255, 0, 0));
    var r3 = new Rectangle(150, 150, Color.hsb(239, 0.68, 0.66));
    var r4 = new Rectangle(150, 150, Color.web("e7b00b"));

    var grid = new GridPane();
    grid.setHgap(0);
    grid.setVgap(0);        
    grid.add(r1, 0, 0);
    grid.add(r2, 0, 1);
    grid.add(r3, 1, 0);
    grid.add(r4, 1, 1);
    
    var label = new Label("Multiple Panes Demo");
    label.setFont(new Font("Calibri", 20));
    label.setTextFill(Color.BLACK);
    	
    var button = new Button("Cool!");
    button.setFont(new Font("Calibri", 20));

    var borderPane = new BorderPane();
    borderPane.setBottom(label);
    borderPane.setAlignment(label, Pos.CENTER);
    borderPane.setCenter(button);

    var stackPane = new StackPane();
    stackPane.getChildren().add(grid);
    stackPane.getChildren().add(borderPane);
    stage.setTitle("Multiple Panes Demo");
    stage.setScene(new Scene(stackPane, 300, 300));
    stage.show();
  }
   
  public static void main(String[] args) {
	 launch();
  }
}