import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import javafx.scene.control.Label;
public class JavaFXSceneGraphDemo extends Application {
  @Override
  public void start(Stage stage) {
    var label1 = new Label("Hello! ");
    var label2 = new Label("COMP3021 ");
    var label3 = new Label("Students");
    var root = new HBox();
    root.getChildren().add(label1);
    root.getChildren().add(label2);
    root.getChildren().add(label3);    
    var scene = new Scene(root, 300, 100, Color.BLACK);
    stage.setTitle("JavaFX Scene Graph Demo");
    stage.setScene(scene);
    stage.show();
  }
  public static void main(String[] args) { launch(args); }
}