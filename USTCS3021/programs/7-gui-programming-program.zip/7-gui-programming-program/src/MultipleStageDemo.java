// Multiple stages can be added beside the primaryStage
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
// Step 1: extend Application
public class MultipleStageDemo extends Application {
  @Override
  public void start(Stage primaryStage) { // Step 2: override start
    // Step 3a: construct the root of a scene graph
    var button1 = new Button("First Button");
    // Step 3b: construct a scene
    var scene = new Scene(button1, 200, 250);
    // Step 3c: set up a stage
    primaryStage.setTitle("First Stage");
    primaryStage.setScene(scene);
    primaryStage.show();
    
    Stage secondaryStage = new Stage();
    secondaryStage.setTitle("Second Stage");
    secondaryStage.setScene(new Scene(
        new Button("Second Button"), 100, 100));
    secondaryStage.show();
  }
  // Define main method that launches the application
  public static void main(String[] args) {
    launch(args);
  }
}