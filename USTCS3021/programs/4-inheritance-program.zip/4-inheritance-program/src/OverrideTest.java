public class OverrideTest { // OverrideTest.java
}
class Parent {
  int x = 1;
  public void pubM() {
    System.out.println("Call Parent");
  }
  private void privM() {
    System.out.println("Call Parent");
  }
  public static void main(String[] args) {
    var c = new Child();
    Parent p = c;  // implicit casting
//    c.pubM();
//    p.pubM();
//    p.privM();
    System.out.print(p.x);
  }
}
class Child extends Parent {
  int x = 2;
  @Override
  public void pubM() {
    System.out.println("Call Child");
  }
  void privM() {
    System.out.println("Call Child");
  }
}

