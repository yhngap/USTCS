import java.util.*;

public class Account {
  private String name;
  private double balance;
  static int nextID;
  private int acctID;

  public Account(String n, double bal) {
//    foo();
    System.out.printf("Call constructor Account(%s, %8.2f)\n", n, bal);
    this.name = n;
    this.balance = bal;
    print();
  }

  public Account () {
//    foo();
    var in = new Scanner(System.in);
    System.out.print("Account name? ");
    this.name = in.nextLine();
    System.out.print("Initial balance? ");
    this.balance = in.nextDouble();
    print();
  }

  /**
   * Common code for each constructor
   */
//  void foo() {
//    this.acctID = nextID++;
//  }

  // Print the balance of this account
  public void print() {
    System.out.printf("Account %d - %s has a balance of $ %8.2f \n", acctID, name, balance);
  }

  {
    this.acctID = nextID++;
  }

/*
    static {
		nextID = 100;
	}
*/
}