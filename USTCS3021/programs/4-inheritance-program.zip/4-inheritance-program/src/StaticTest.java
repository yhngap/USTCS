public class StaticTest {
  public static void main(String[] args) {
    var child = new Subclass(); // same as Subclass child = ...
    Superclass parent = child;  // implicit casting
    child.g();  // inherited
//    parent.staticM(); // not overridden
//    System.out.println(parent.staticV);
//    child.staticM();  // hide inherited
  }
}
class Superclass { // Superclass.java
  public int pubV = 1;
  public static int staticV = 2;
  public static void staticM() {  // static
    System.out.println("Superclass's static method");
  }
  public static void g() {  // static
    staticM();
  }
}
class Subclass extends Superclass { // Subclass.java
  public int pubV = 3;
  public static int staticV = 4;
  public static void staticM() {  // static
    System.out.println("Subclass's static method");
  }
}