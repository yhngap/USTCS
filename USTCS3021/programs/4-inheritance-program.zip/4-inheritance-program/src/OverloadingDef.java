class BaseClass {
  public Object m(DerivedClass o) {
    System.out.println("call m of BaseClass");
    return null;
  }
}

class DerivedClass extends BaseClass {
  public Object m(BaseClass o) {
    System.out.println("call m of DerivedClass");
    return null;
  }
}

class ExDerivedClass extends DerivedClass {
}
