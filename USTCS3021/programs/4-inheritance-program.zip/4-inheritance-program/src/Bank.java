public class Bank {
  public static void main(String args[]) {
    new Account("Jino Lee", 123456.78);
    new Account("Felix Lai", 23456);
    new SavingsAccount("Linda Lo", 10000, 10);
  }
}
