public class SavingsAccount extends Account {
  private double interest;

  public SavingsAccount(String n, double bal, double interest) {
    super(n, bal);
    System.out.printf("Call constructor SavingsAccount(%s, %8.2f, %4.2f)\n", n, bal, interest);
    this.interest = interest;
  }

  void foo() {
    // System.out.println("The foo of SavingsAccount was called");
  }
}