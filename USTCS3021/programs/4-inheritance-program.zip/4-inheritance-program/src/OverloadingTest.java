public class OverloadingTest {

  public static void main(String args[]) {
    var derived = new DerivedClass();
    BaseClass base = derived;

//    base.m(base);
//    base.m(derived);
//    derived.m(base);
//    derived.m(derived);
//
//    derived.m(null);
    derived.m(new ExDerivedClass());
  }
}
