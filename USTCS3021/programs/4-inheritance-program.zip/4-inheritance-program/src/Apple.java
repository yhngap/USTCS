/*
public class Apple extends Fruit {
}
*/

class Fruit {
  public Fruit(String name) {
    System.out.println("Fruit's constructor is invoked");
  }
}