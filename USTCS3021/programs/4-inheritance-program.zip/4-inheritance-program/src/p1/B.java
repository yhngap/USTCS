package p1;

public class B {
    protected int i;
    protected static int j;
}


