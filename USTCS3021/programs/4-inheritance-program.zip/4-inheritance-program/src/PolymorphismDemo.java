class Human extends Object {
  public String toString() { return "Human"; }
}

class Student extends Human {
  public String toString() { return "Student"; }
}

class GraduateStudent extends Student { }

public class PolymorphismDemo {
  // The argument x's toSring() method is invoked implicitly in
  // the line System.out.println(x)
  public static void m(Object x) { System.out.println(x); }  
  public static void main(String[] args) {
    m(new GraduateStudent());
    m(new Student());
    m(new Human());
    m(new Object());
  } 
}