public class InstanceFieldInitialization extends Superclass {

  {
    pubV = 3;
    System.out.println("Execute an empty instance initializer block");
  }

  int i = 3;
  public static void main(String [] args){
    var obj = new InstanceFieldInitialization();
    System.out.println("After obj creation: " + obj.i);
    obj.i = 7;
    System.out.println("Leaving main(): " + obj.i);
  }

  InstanceFieldInitialization() {
    System.out.println("Entering constructor: " + i);
    i = 9;
    System.out.println("Leaving constructor: " + i);
  }

  {   // object initialization block
    System.out.println("Entering instance initializer block: " + i);
    i = 5;
    System.out.println("Leaving instance initializer block: " + i);
  }
}

