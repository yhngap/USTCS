public class ConstructorInheritanceTest {
  public static void main(String [] args) {
//    var d = new Derived(0);
//    Base b = new Derived(0);
    var d = new Derived();
  }
}

class Base {
  Base() {
    System.out.println("No-arg constructor is called");
  }
  Base(int i) {
    System.out.println("Constructor of int is called");
  }
}

class Derived extends Base {
  Derived() { super(); }
}
