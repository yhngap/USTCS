public class CastingDemo {
  public static void displayObject(Object object) {
    if (object instanceof Circle) {
      var c = (Circle) object;
      System.out.println("The circle area is " + c.getArea());
      System.out.println("The circle diameter is " + c.getDiameter());}
    else if (object instanceof Rectangle) {
      var r = (Rectangle) object;
      System.out.println("The rectangle area is " + r.getArea());}
  }

  public static void displayObjectwithPattern(Object object) {
    if (object instanceof Circle c) {
      System.out.println("The circle area is " + c.getArea());
      System.out.println("The circle diameter is " + c.getDiameter());}
    else if (object instanceof Rectangle r) {
      System.out.println("The rectangle area is " + r.getArea());}
  }

  public static void main(String[] args) {
// Create and initialize two objects
    Object object1 = new Circle(1);
    Object object2 = new Rectangle(1, 1);

// Display circle and rectangle
    displayObject(object1);
    displayObject(object2);
    displayObjectwithPattern(object1);
    displayObjectwithPattern(object2);
  }
}
