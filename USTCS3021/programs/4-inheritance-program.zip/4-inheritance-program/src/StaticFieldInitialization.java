public class StaticFieldInitialization {
  static int i = 3;
  public static void main(String [] args) {
    System.out.println("Entering main(): " + i);
    i = 7;
    System.out.println("Leaving main(): " + i);
  }

  static { // static initialization block
    System.out.println("Entering static field initializer: " + i);
    i = 5;
    System.out.println("Leaving static field initializer: " + i);
  }
}
