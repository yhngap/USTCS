package p2;
import p1.B;
class C extends B {
}
class D extends B {
    void f(D o) {
        o.i = 1;
//        B b = o;  // 3
//        b.i = 1;  // 3
    }
    void g(C o) {
//        o.i = 1;  // 1
//        o.j = 1;  // 4
    }
    void h(B o) {
//        o.i = 1;  // 2
//        o.j = 1;  // 5
    }
}


