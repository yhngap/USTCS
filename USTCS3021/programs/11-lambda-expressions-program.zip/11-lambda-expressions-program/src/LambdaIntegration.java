interface Integrable { double eval(double x); }
interface IntegrableCplx { double eval(double r, double i); }

public class LambdaIntegration {
  // f is a (functional) object that implements Integrable, which supports eval(double)
  public static double integrate(Integrable f, double a, double b, int numSlices) {
    if(numSlices < 1) numSlices = 1;
    double delta = (b-a)/numSlices, start = a + delta / 2, sum = 0;
    for(var i=0; i<numSlices; i++)
      sum += delta * f.eval(start + delta * i);
    return sum;
  }
  
  public static void integrationTest(Integrable f, double a, double b) {
    for(var i=1; i<7; i++) {
      int numSlices = (int)Math.pow(10, i);
      var result = integrate(f, a, b, numSlices);
      System.out.printf("For numSlices = %,10d result = %,.8f%n", 
                        numSlices, result);
    }
  }
  
  public static void main(String[] args) {
    System.out.println("Estimate integral of x^2 from 10 to 100");
    integrationTest(x->x*x, 10, 100);
    System.out.println("Estimate integral of sin(x) from 0 to PI");
//    integrationTest(x->Math.sin(x), 0, Math.PI);
    integrationTest(Math::sin, 0, Math.PI);  // the same as integrationTest(x->Math.sin(x), 0, Math.PI);
  }

  public static double integrate(IntegrableCplx f, double a, double b, int numSlices) {
    if(numSlices < 1) numSlices = 1;
    double delta = (b-a)/numSlices, start = a + delta / 2, sum = 0;
    for(var i=0; i<numSlices; i++)
      sum += delta * f.eval(start + delta * i, 0);
    return sum;
  }

  public static void integrationTest(IntegrableCplx f, double a, double b) {
    for (var i = 1; i < 7; i++) {
      int numSlices = (int) Math.pow(10, i);
      var result = integrate(f, a, b, numSlices);
      System.out.printf("For numSlices = %,10d result = %,.8f%n",
              numSlices, result);
    }
  }
}

