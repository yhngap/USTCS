interface Vehicle {
  default void print() {
    System.out.println("I am a vehicle.");
  }
	
  static void blowHorn() {
    System.out.println("Blowing horn!");
  }
}

interface FourWheeler {
  default void print() {
	 helperFunction();
  }
  private void helperFunction() {System.out.println("I am a four wheeler.");}
}

class Car implements Vehicle {
  void foo() {
    print();
  }  // default methods can be inherited
}

class Car1 implements Vehicle {
  public void print() {  // default methods can be overridden
	 System.out.print("I am a car and ");
	 Vehicle.super.print();  // can be called by <interface name>.super
  }
}

class Car2 implements Vehicle, FourWheeler {
  public void print() {
    System.out.print("I am a four wheeler car vehicle.\n"); // override two interface methods
  }
}

public class LambdaDefaultMethod {
  public static void main(String args[]) {
	 new Car().foo();
	 new Car1().print();
	 new Car2().print();
	 Vehicle.blowHorn();
  }
}