/*interface Integrable {
  double eval(double x);
}*/

public class LambdaMethodReference {
  public static double integrate(Integrable f, double a, double b, int numSlices) {
	 if (numSlices < 1)
      numSlices = 1;
	 var delta = (b-a)/numSlices;
	 var start = a + delta/2;
	 var sum = 0.0;
	 for (var i=0; i<numSlices; i++)
		sum += delta*f.eval(start+delta*i);
	 return sum;
  }
	
  public static void integrationTest(Integrable f, double a, double b) {
	 for (var i=1; i<7; i++) {
		var numSlices = (int)Math.pow(10, i);
		var result = integrate(f, a, b, numSlices);
		System.out.printf("  For numSlices =%,10d result = %,.8f%n", numSlices, result);
	 }
  }
	
  public double square(double x) {
	 return x*x;
  }
	
  public double square(double x, double y) {
	 return x*x + y*y;
  }
	
  public static void main(String args[]) {
	 System.out.println("Estimate integral of x^2 from 10 to 100");
	 LambdaMethodReference r = new LambdaMethodReference();
	 integrationTest(r::square, 10, 100);
	 System.out.println("Estimate integral of sin(x) from 0 to PI");
	 integrationTest(Math::sin, 0, Math.PI);
  }
}
