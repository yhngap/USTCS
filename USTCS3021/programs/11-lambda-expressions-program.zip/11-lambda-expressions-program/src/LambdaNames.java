interface Names {
  void sayName(String name);
}

public class LambdaNames {
  public static void main(String[] args) {
	 myName(n -> System.out.println("My Name is "+ n), "John");
  }
  /*
  public static void main(String [] args) {
    Names nameInstance = new Names() {
		@Override
		public void sayName(String n) {
		  System.out.println("My Name is " + n);
		}
	 };
	 myName(nameInstance, "John");
  }
  */
	
  private static void myName(Names nameInstance, String name) {
	 nameInstance.sayName(name);
  }
}
