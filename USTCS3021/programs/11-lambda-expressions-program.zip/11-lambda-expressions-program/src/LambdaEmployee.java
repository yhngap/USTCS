import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Consumer;

class USTEmployee {
  public USTEmployee(Integer id, Integer age, Double salary, String gender, String fName, String lName){
    this.id = id;
    this.age = age;
    this.salary = salary;
    this.gender = gender;
    this.firstName = fName;
    this.lastName = lName;
  } 
     
  private Integer id;
  private Integer age;
  private Double salary;
  private String gender;
  private String firstName;
  private String lastName;
 
  public String getFirstName() {
    return this.firstName;
  }
   
  public String getLastName() {
	 return this.lastName;
  }
   
  public double getAge() {
	 return this.age;
  }
   
  public double getSalary() {
	 return this.salary;
  }
   
  public void setSalary(Double s) {
    this.salary = s;
  }
   
  public String getGender() {
	 return this.gender;
  }
 
  @Override
  public String toString() {
    return "ID=" + this.id+" name="+firstName+" age="+this.age+" salary="+this.salary; //To change body of generated methods, choose Tools | Templates.
  }
    
  public static List<USTEmployee> populate() {
    USTEmployee e1 = new USTEmployee(1, 23, 10000.0, "M", "Ricky", "Beethovan");
    USTEmployee e2 = new USTEmployee(2, 13, 15000.0, "F", "Martina", "Hengis");
    USTEmployee e3 = new USTEmployee(3, 43, 20000.0, "M", "Ricky", "Martin");
    USTEmployee e4 = new USTEmployee(4, 26, 25000.0, "M", "Jon", "Lowman");
    USTEmployee e5 = new USTEmployee(5, 19, 30000.0, "F", "Cristine", "Maria");
    USTEmployee e6 = new USTEmployee(6, 15, 35000.0, "M", "David", "Feezor");
    USTEmployee e7 = new USTEmployee(7, 68, 40000.0, "F", "Melissa", "Roy");
    USTEmployee e8 = new USTEmployee(8, 79, 45000.0, "M", "David", "Gussin");
    USTEmployee e9 = new USTEmployee(9, 15, 50000.0, "F", "Neetu", "Singh");
    USTEmployee e10 = new USTEmployee(10, 45, 55000.0,"M","Naveen", "Jain");
         
    var employees = new ArrayList<USTEmployee>();
    employees.addAll(Arrays.asList(new USTEmployee[]{e1,e2,e3,e4,e5,e6,e7,e8,e9,e10}));
    return employees;   	
  }
    
  public static USTEmployee findEmployeebyFirstName(List<USTEmployee> employees, String firstName) {
    for (USTEmployee e: employees) {
      if (e.getFirstName().equals(firstName)) {
    	  return e;
    	}
    }
    return null;
  }
    
  public static USTEmployee findEmployeebyAge(List<USTEmployee> employees, int ageCutoff) {
    for (USTEmployee e: employees) {
    	if (e.getAge() >= ageCutoff) {
        return e;
    	}
    }
    return null;
  }
}

class Util {
  // A generic function to find an element in a List
  public static <T> T find(List<T> dataset, Predicate<T> predicate) {
	 for (var e: dataset)
		if (predicate.test(e))
		  return e;
	 return null;
  }
	
  // A generic function to find all elements in a List
  public static <T> List<T> findAll(List<T> dataset, Predicate<T> predicate) {
    //System.out.println("Use findAll - 1");
	 List<T> matches = new ArrayList<>();
	 for (T e: dataset)
		if (predicate.test(e))
		  matches.add(e);
	 return matches;
  } 
  // A generic function that sums the mapped value of each element in a list of any type
  public static <T> double mapSum(List<T> list, Function<T, Double> mapper) {
     var sum = 0.0;
	   for (var entry : list) {
		   sum += mapper.apply(entry);
	   }
	   return sum;
  }
  // A generic function to conjunct all predicate in the arguments
  public static <T> Predicate<T> conjunct(Predicate<T>... predicates) {
	 Predicate<T> result = e->true; // a trivial tautology if no input arguments
	 for (var e: predicates)
		result = result.and(e);
	 return result;
  }
  // A generic function to find all elements in a List satisfying all input predicates
  public static <T> List<T> findAll(List<T> dataset, Predicate<T>... predicates) {
	 //System.out.println("Use findAll - 2");
	 Predicate<T> compositePredicate = conjunct(predicates);
	 return findAll(dataset, compositePredicate);
  }
  // A generic function to compose all functions
  public static<T> Function<T,T> composeAll(Function<T,T>... functions) {
	 Function<T,T> result = Function.identity();
	 for (var f: functions)
		result = result.compose(f);
	 return result;
  }
}

public class LambdaEmployee {
  static List<USTEmployee> employees = USTEmployee.populate();
	
  public static void main(String[] args) {
    System.out.println("** The employee database is initialized to: **");
    System.out.println(employees); System.out.flush();
//    findWithoutLambda(); // 1
//    findWithLambda(); // 2
//    findAllWithLambda(); // 3 also demo another data list
//    raiseSalaryUsingFunction(); // 4
//    mapSumTest(); // 5
//    raiseSalaryUsingConsumerWithoutForEach(); // 6
//    raiseSalaryUsingConsumerWithForEach(); // 7
//    TypeCasting.testTypeCasting(); // 8
//    composeFunctions(); // 9
//    Word.findAllExample(); // 10 - exercise 4
//    Function<Double,Double> f = Util.composeAll(Math::rint, Math::sqrt); // 11

//	   tryStreamOperation(); // 12
//       tryParallelStreamOperation(); // 13
//       LambdaTimeOp.measure(()->trySeqStreamOperation());
//       LambdaTimeOp.measure(()->tryParallelStreamOperation());
  }

  static void findWithoutLambda() {
     System.out.println("\n** Find without using lambda ... **");
	   System.out.println("Employee with firstname David is: " + USTEmployee.findEmployeebyFirstName(employees, "David"));
	   System.out.println("Employee with cutoff age 42 is: " + USTEmployee.findEmployeebyAge(employees, 42));
  }

  static void findWithLambda() {
    System.out.println("\n** Find using generic method with lambda ... **");
    System.out.println("Employees with firstname David are: " + Util.find(employees, e->e.getFirstName().equals("David")));
    System.out.println("Employees with cutoff age 42 are: " + Util.find(employees, e->e.getAge() >= 42));
    System.out.println("Female employees are: " + Util.find(employees, e->e.getGender() == "F"));
  }

  static void findAllWithLambda() {
    System.out.println("\n** Find ALL using generic method with lambda ... **");
    System.out.println("Employee with firstname David is: " + Util.findAll(employees, e -> e.getFirstName().equals("David")));
    System.out.println("Employee with cutoff age 42 is: " + Util.findAll(employees, e -> e.getAge() >= 42));
    System.out.println("Female employees are: " + Util.findAll(employees, e -> e.getGender() == "F"));
    Word.findAllExample();
  }

  static void raiseSalaryUsingFunction() {
    Function<USTEmployee, Double> raise = e -> e.getSalary()*1.1;
    for (var e: employees)
      e.setSalary(raise.apply(e));
    System.out.println("\n** Raise employees' salary without using forEach **");
    System.out.println(employees);
  }

  static void mapSumTest() {
    System.out.println("\n** Demonstration of mapSum **");
    System.out.println("The total of salary is: " + Util.mapSum(employees, e -> e.getSalary()));
    System.out.println("The projected total of salary after 10% raise is: " + Util.mapSum(employees, e -> e.getSalary()*1.1));
    System.out.printf("The total number of characters in the Word list is: %.0f\n", Util.mapSum(Word.words, e->Double.valueOf(e.length())));
  }

  static void raiseSalaryUsingConsumerWithoutForEach() {
    System.out.println(("\n** Demonstration of Consumer without using forEach **"));
    System.out.println("Before raising: " + employees);
    Consumer<USTEmployee> raise = e -> e.setSalary(e.getSalary()*1.1);
    for (var e: employees) raise.accept(e);
    System.out.println("After raising: " + employees);
  }

  static void raiseSalaryUsingConsumerWithForEach() {
    System.out.println(("\n** Demonstration of Consumer using forEach **"));
    System.out.println("Before raising: " + employees);
    // forEach assumes a Consumer function object as parameter
    employees.forEach(e -> e.setSalary(e.getSalary()*1.1));
    System.out.println("After raising: " + employees);
  }

  static void composeFunctions() {
    Predicate<USTEmployee> isYoung = e -> e.getAge()<30;
    Predicate<USTEmployee> isRich = e -> e.getSalary()>20000;
    System.out.println("\n** Find both young and rich employees **");
    System.out.println("An employee who is both young and rich: " + Util.find(employees, isRich.and(isYoung)));
    System.out.println("Employees who are both young and rich: " + Util.findAll(employees, isRich.and(isYoung)));
    System.out.println("Employees who are young or rich: " + Util.findAll(employees, isRich.or(isYoung)));
  }

  static void tryLambda() {
//  Word.findAllExample();
//	 Function<Double,Double> f = Util.composeAll(Math::rint, Math::sqrt);
//  tryStreamOperation();
  }
	
  static void tryStreamOperation() {
    employees.stream()
		.filter(e -> e.getAge() >= 42)
	    .forEach(System.out::println);
    employees.stream()
		.filter(e -> e.getAge() >= 42)
	    .map(e -> e.getFirstName() + " ")
		.forEach(System.out::println);
// double totalSalary = employees.stream().map(e->e.getSalary()).reduce((s1, s2)->s1+s2).orElse(0.0);
	 double totalSalary = employees.stream()
		.map(e -> e.getSalary())
		.reduce(0.0, (s1, s2) -> s1 + s2);
	 System.out.println("Total salary = "+totalSalary);

	 List<Integer> numbers = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
	 int sum = numbers.stream().reduce(0, (i, j)->i+j);
	 System.out.println(sum);
		
	 List<String> names = Arrays.asList("Bob", "Tom", "Jeff", "Jennifer", "Steve");
	 String longestName = names.stream()
		.reduce("", (name1, name2) -> name1.length()>=name2.length()?name1:name2);
	 System.out.println("The longest name is:"+longestName);
		
	 boolean anyMatch = employees.stream().anyMatch(e -> e.getAge()>42);
	 System.out.println("Is there an employee older than 42? "+anyMatch);
		
	 boolean allMatch = employees.stream().allMatch(e -> e.getAge()>42);
	 System.out.println("Are all employees older than 42? "+allMatch);
		
	 long n = employees.stream().filter(e -> e.getAge()>42).count();
	 System.out.printf("There are %d employees older than 42.\n", n);
  }
	
  static void tryParallelStreamOperation() {
	 List<Integer> numbers = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
	 numbers.parallelStream().forEach(System.out::println);
	 employees.parallelStream().filter(e->e.getAge() >= 42).map(e->e.getFirstName()+" ").forEach(System.out::println);
  }

  static void trySeqStreamOperation() {
        List<Integer> numbers = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
        numbers.stream().forEach(System.out::println);
        employees.stream().filter(e->e.getAge() >= 42).map(e->e.getFirstName()+" ").forEach(System.out::println);
  }

}

class Word {
  static List<String> words = Arrays.asList("hi", "hello", "hola", "bye", "goodbye", "adios");
  public static void findAllExample() {
   System.out.println("\n** findAll from a word list **");
	 List<String> hWords = Util.findAll(words, w->w.contains("h"));
	 System.out.println("Words with h: " + hWords);
	 List<String> hlWords = Util.findAll(words, w->w.contains("h"), w->w.contains("l"));
	 System.out.println("Words with h and l: " + hlWords);
	 List<String> hlShortWords = Util.findAll(words, w->w.contains("h"), w->w.contains("l"), w->w.length()<=4);
	 System.out.println("Words with h and l and length <= 4: " + hlShortWords);
  }
}

class TypeCasting {
  interface MyInterface {
	 void accept(USTEmployee e);
  }
  static void effectivelyFinal() {
	 double d = 1.1;
//  Consumer<USTEmployee> raise = e -> e.setSalary(e.getSalary()*d);
//	 d += 0.1;
  }

  static void testTypeCasting() {
	 Consumer<USTEmployee> raise = e -> e.setSalary(e.getSalary()*1.1);
	 MyInterface mi = e -> e.setSalary(e.getSalary()*1.2);
//     mi = raise; // 8.1
//     raise = mi;
//     raise = (Consumer<USTEmployee>) mi; // 8.2  runtime error?
//     mi = (MyInterface) raise; // 8.3  runtime error?
//     var o1 = e -> e.setSalary(e.getSalary()*1.1); // 8.4 legal?
//     var o2 = (MyInterface) e -> e.setSalary(e.getSalary()*1.1); // 8.5 legal?
//	 var o3 = (Consumer) e -> e.setSalary(e.getSalary()*1.1); // 8.6 legal?
//	 var o4 = (Consumer<USTEmployee>) e -> e.setSalary(e.getSalary()*1.1); // 8.7 legal?
  }
}

