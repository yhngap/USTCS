interface Fn {
  double eval(double x);
}

public class LambdaScope {
  private double x = 99;
  private double y = 1000;
/*  LambdaScope() { // 5: What is the output? What does this refer to? the functional object?
    f(x->x*this.x + y, 10);
  }*/

/*  LambdaScope(int i) {
    System.out.println(this); // 7: demonstrate this
    Fn o = x->{
      System.out.println(this);
      return x*this.x + y;
    };
    synchronized (o) {  // 7: can function object be synchronized? the same as synchronized(this)?
      f(o, 10);
    }
  }*/
  double f(Fn func, double x) {
	 var d = func.eval(x);
     System.out.println(d);
	 return d;
  }
  public static void main (String[] args) {
       double x = 3;
       var o = new LambdaScope(); // 5: uncomment constructor
//		o.f(x->x+x, 10); // 1: conflict with local var x? same as anonymous inner class?
//		o.f(y->{double x=3.4; return x+y;}, 10); // 2: conflict with local var x?
//		o.f(y->{ return x+y;}, 10); // 3: Can we use local var x in lambda? What is the output?
//		o.f(y->{x=3.4; return x+y;}, 10); // 4: can we modify local var x in lambda?
//        o.f(y->{return this.x+y;}, 10);  // 6: What does this refer to?
//       new LambdaScope(0);  // 7:

/*    o.f( new Fn() {  // 1:
      public double eval(double x) {
        return x+x;
      }
    }, 10);*/
  }
}
