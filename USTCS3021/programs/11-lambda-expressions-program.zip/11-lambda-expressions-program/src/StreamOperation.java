import java.util.Arrays;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.Predicate;

public class StreamOperation {

    public static void main(String[] args) {
        var employees = USTEmployee.populate();
        var numbers = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
//        applyMap(numbers, v->v*2);
//        applyFilter(numbers, v->v%2==0);

        var names = Arrays.asList("Bob", "Tom", "Jeff", "Jennifer","Steve");
//        applyFilter(names, name->name.startsWith("J"));

//        applyReduce(numbers, 0, (i,j)->i+j, "The sum is: ");
/*        BinaryOperator<String> binOp = (n1,n2)->n1.length()>=n2.length()?n1:n2;
        applyReduce(names, "", binOp,"The longest name is: ");*/

/*
        boolean anyMatch = employees.stream().anyMatch(e -> e.getAge()>42);
        System.out.println("Is there an employee older than 42? "+anyMatch);

        boolean allMatch = employees.stream().allMatch(e -> e.getAge()>42);
        System.out.println("Are all employees older than 42? "+allMatch);

        long n = employees.stream().filter(e -> e.getAge()>42).count();
        System.out.printf("There are %d employees older than 42.\n", n);
*/
    }

    public static <T, R> void applyMap(List<T> list, Function<T, R> f) {
        list.stream()
                .map(f)
                .forEach(System.out::println);
    }

    public static <T> void applyFilter(List<T> list, Predicate<T> f) {
        list.stream()
                .filter(f)
                .forEach(System.out::println);
    }

    public static <T> void applyReduce(List<T> list, T base, BinaryOperator<T> f, String msg) {
        var result = list.stream()
                                    .reduce(base, f);
        System.out.println(msg + result);
    }
}
