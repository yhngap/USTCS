@FunctionalInterface
interface Func {
  double eval(double x);
}

public class LambdaTest {
  static double calc(Func f, double x) {
    return f.eval(x);
  }
  
  public static void main(String[] args) {
	 System.out.println(calc(x->x+x, 3));
	 System.out.println(calc(x->x*x, 3));
	 System.out.println(calc(x->x/x, 3));
	 System.out.println(calc(x->5, 3));  // 1:
	 System.out.println(calc(x->calc(y->y*y, x), 3)); // 2: What is the result?
  }
}