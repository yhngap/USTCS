interface Op { void runOp(); }

public class LambdaTimeOp {
  private static final double ONE_BILLION = 1_000_000_000;  
  public static void measure(Op operation) {
    long startTime = System.nanoTime();
    operation.runOp();
    long endTime = System.nanoTime();
    double elapsedSeconds = (endTime - startTime) / ONE_BILLION;
    System.out.printf("Elapsed time: %.3f seconds.%n", elapsedSeconds);
  }
  public static void main(String[] args) {
    measure(()->LambdaIntegration.integrationTest(x->x*x, 10, 100));
    measure(()->LambdaIntegration.integrationTest(x->Math.sin(x), 
                                                0, Math.PI));
    measure(()->LambdaIntegration.main(null));
  }
}