@FunctionalInterface
public interface Action {
  void run(String param);
//  void stop(String param);
}