// ShowInnerClass.java
public class ShowInnerClass {
  private int data; // 3: shared by InnerClass instances created under the same ShowInnerClass instance
  private void n() {
    System.out.println("n is executed and data = " + data);
  }
  public void m(InnerClass x) { /** A method in the outer class */  // 5.1
    InnerClass instance = new InnerClass(); // 5: Innerclass as type
    instance.mi();
    var i = instance.j; // 1: bidirectional access of private members
  }
  // 2: An inner class (a.k.a. instance class whose access needs to be made through an instance)
 class InnerClass {
//    static int i = 0;  // 4: allowed? make sense? changed to final?
    private int j;
    public void mi() { /** A method in the inner class */
        // 1: Directly reference data and method defined in its outer class
        data++;
        n();
    }
//    interface A {}  // 6: interface is implicitly static
//    class InnerInner { // 6.1: Inner class inside an inner class
//    }
  }
//  static class StaticNestedClass {static int i;} // 6: static nested class
//  interface NestedInterface {} // 7: implicitly static

  public static void main(String[] args) {
     var s = new ShowInnerClass();
//     s.new InnerClass().mi(); // 2
//     new ShowInnerClass().new InnerClass().mi(); // 3: use inner class directly
//     s.m(null);  // 3: use inner class through an instance method m()
//     new ShowInnerClass.StaticNestedClass(); // 6.1  create an instance from static nested class
//     ShowInnerClass.NestedInterface v = null; // 7
//     ShowInnerClass.StaticNestedClass x = null; // 6.2: use static nested class as a type
//     ShowInnerClass.InnerClass w = null; // 5.2 Inner class as a type
//     var j = ShowInnerClass.InnerClass.i; // 4.1  add final to i
  }
}