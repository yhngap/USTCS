import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;

public class MyFXApplication extends Application {
    private int data;
    private void method() {}
    @Override
    public void start(Stage primaryStage) {
        int j = new MyListener().i;
    }
    // Inner class
    static class MyListener implements EventHandler<ActionEvent> {
        private int i;
        @Override
        public void handle(ActionEvent event) {
            i = new MyFXApplication().data;
        }
    }
}
