public class TestAnonymousInnerClass {
    private int j=99;

  public static void main(String[] args) {
    var x = new TestAnonymousInnerClass().foo();
      System.out.println("The foo method has ended.");
    x.f(); // 3.1
  }

  Super foo() {
    int i = 1;

    var o = new Super(i) { // anonymous inner class call overloaded superclass constructor
//            static // 2: May we have static fields in anonymous inner class? Make sense?
      int k;
      void f() { System.out.println("Executing the f method: "+ i + j); }
//      { k=1; System.out.println("Anonymous class instance initializer"); } // 1: Is instance initializer block allowed?
    };

    o.f();
//    i++; // 3: local var used in anonymous innerclass method cannot be modified; effectively final
//      var m = new Cloneable() {} [10]; // 4: use anonymous inner class as a type to create array?
      return o;
  }
}

abstract class Super {
  Super(int x) {
    System.out.println("Execute superclass constructor " + x);
  }
  void f() {}
}
