import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.web.WebView;

public class WebViewDemo extends Application {    
  @Override public void start(Stage primaryStage) {
    WebView webview = new WebView();
    webview.getEngine().load("https://youtu.be/Tu3O5qvVVHo");
    webview.setPrefSize(640, 480);
    primaryStage.setTitle("WebView");
    primaryStage.setScene(new Scene(webview));
    primaryStage.show();
  }
  public static void main(String[] args) { launch(args); }  
}