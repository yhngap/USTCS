public class Main {

    /**
     * The main function that implements QuickSort
     *
     * @param arr  array to be sorted
     * @param low  starting index
     * @param high ending index
     */
    public static void quickSort(int[] arr, int low, int high) {
        // TODO student implementation
    }

    public static void printArray(int[] arr) {
        // TODO student implementation
    }

    public static void main(String[] args) {
        // TODO student implementation
    }
}
