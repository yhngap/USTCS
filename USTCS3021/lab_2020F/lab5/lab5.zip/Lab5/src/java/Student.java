public class Student extends Person {
    private int id;
    private String major;

    // TODO
}
