public class Main {
    public static int add(int a, int b){
        return a + b;
    }
    public static void main(String[] args) {
        System.out.print("This is a demo project.");
    }
}
