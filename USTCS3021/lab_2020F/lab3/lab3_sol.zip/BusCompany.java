import java.util.Arrays;
import java.util.Objects;

public class BusCompany {
    private String name;
    private int numBusses;
    private static int numCompanies = 0;
    private int arraySize = 5;
    private Bus[] busses = new Bus[arraySize];

    BusCompany(String name) {
        this.name = name;
        numCompanies++;
    }

    public String getName() {
        return name;
    }

    public boolean createAndAddBus(int id, String model) {

        //each bus has an unique id, now the id of the bus exists we can't add
        if (Arrays.stream(busses).filter(Objects::nonNull).anyMatch(b -> b.getID() == id))
            return false;

        // still have space in the busses[] array to hold a new bus reference
        if (numBusses < busses.length) {
            busses[numBusses] = new Bus(id, model);
            numBusses++;
            return true;
        }

        return false;
    }

    public void removeAllBusses() {
        numBusses = 0;
        busses = new Bus[arraySize];
    }

    public static int getNumCompanies() {
        return numCompanies;
    }

}