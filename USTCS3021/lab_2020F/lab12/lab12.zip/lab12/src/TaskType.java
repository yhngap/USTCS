public enum TaskType {
    READING, CODING, WRITING;

}
