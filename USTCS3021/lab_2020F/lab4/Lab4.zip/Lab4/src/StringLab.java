public class StringLab {

    /**
     * @param str The input string
     * @return The reversed string
     */
    public String reverseString(String str) {
        //TODO
    }

    /**
     * Makes all characters before the index value uppercase, makes all characters on the index and afterwards
     * lowercase. See test cases for a better understanding.
     *
     * @param str   The input string
     * @param index All character positions smaller than index must be uppercase. All character positions greater
     *              than index must be lowercase.
     * @return The new string
     */
    public String capitalizeAndMakeLowercase(String str, int index) {
        //TODO
    }

    /**
     * Counts the number of vowels in a string.
     *
     * @param str The input string
     * @return The number of vowels
     */
    public long countVowels(String str) {
        //TODO
    }

    /**
     * Removes a certain letter from a string
     *
     * @param str The input string
     * @param a   The letter to remove
     * @return The input string without the specified letter
     */
    public String removeLetter(String str, char a) {
        //TODO
    }

    /**
     * Checks if a string is a palindrome
     *
     * @param str The string to check
     * @return Whether or not the string is a palindrome
     */
    public boolean isPalindrome(String str) {
        //TODO
    }
}
