package lab7;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.net.URISyntaxException;

public class Main extends Application {
    public static final int CELL_SIZE = 32;

    /**
     * boardSize: size of board, customized.
     */
    private final int boardSize = 9;

    private static Image lightBoardTile = null;
    private static Image darkBoardTile = null;


    //TODO
    /**
     * load "assets/images/lightBoard.png" and assign it to {@link Main#lightBoardTile}
     * load "assets/images/darkBoard.png" and assign it to {@link Main#darkBoardTile}
     */
    static {
        // Method 1
        try {
            lightBoardTile = new Image(Main.class.getResource("/assets/images/lightBoard.png").toURI().toString());
            darkBoardTile = new Image(Main.class.getResource("/assets/images/darkBoard.png").toURI().toString());


        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        // Method 2
        // lightBoardTile = new Image("file:src/assets/images/lightBoard.png");
        // darkBoardTile = new Image("file:src/assets/images/darkBoard.png");
    }


    public static void main(String[] args) {
        launch(args);
    }

    /**
     * set the primaryStage title to "Lab 7"
     * set the scene as {@link Main#setboardScene(int)}
     * show the stage
     *
     * @param primaryStage
     */
    @Override
    public void start(Stage primaryStage) {
        //TODO
        primaryStage.setTitle("Lab 7");
        primaryStage.setScene(setboardScene(boardSize));
        primaryStage.show();
    }


    /**
     * Generate the canvas with the height and width both are {@link Main#boardSize} * {@link Main#CELL_SIZE}
     * Draw {@link Main#lightBoardTile} and {@link Main#darkBoardTile} take turns
     *  - odd: lightBoardTile
     *  - even: darkBoardTile
     * Place the canvas inside a VBox before returning it in a scene
     * Similar implementation logic can be used in PA2 gui/controllers/Render# renderChessBoard method.
     *
     * @param boardSize Size of board
     * @return The created scene
     */
    public Scene setboardScene(int boardSize) {
        //TODO
        Canvas canvas = new Canvas();
        canvas.setHeight(boardSize * CELL_SIZE);
        canvas.setWidth(boardSize * CELL_SIZE);

        var gc = canvas.getGraphicsContext2D();

        for (int r = 0; r < boardSize; r++) {
            for (int c = 0; c < boardSize; c++) {
                if ((r + c) % 2 == 0)
                    gc.drawImage(darkBoardTile, c * CELL_SIZE, r * CELL_SIZE);
                else
                    gc.drawImage(lightBoardTile, c * CELL_SIZE, r * CELL_SIZE);
            }
        }

        return new Scene(new VBox(canvas));
//        return null;
    }
}
