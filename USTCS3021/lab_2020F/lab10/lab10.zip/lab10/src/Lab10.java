import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

public class Lab10 {
    /**
     * The list of char which should stores the string merge results of all threads after all threads exit.
     * The content of this list will be cleared before the thread is started.
     */
    public static List<Character> mergedResult = new ArrayList<>();

    /**
     * The number of workers.
     * The value of this atomic integer object will be set before the workers/threads is created.
     * Therefore, this value can be safely used inside threads.
     */
    public static final AtomicInteger numWorkers = new AtomicInteger();

    /**
     * The mapping structure from each worker object to its thread object.
     * The content of the mapping will be set after the thread is created and before the thread is started.
     * Therefore, the contents can be safely used inside threads.
     */
    public static final Map<Worker, Thread> workerThreadMap = new HashMap<>();

    // TODO feel free to add static fields to help you synchronize threads.

    /**
     * The worker class which is {@link Runnable}.
     * Each worker has an {@link Worker#id}, which is unique to each worker object and is continuous integer from 0,
     * e.g. worker0, worker1, worker2, ...
     * All worker objects will work together to merge their own char array into {@link Lab10#mergedResult}.
     * <p>
     * The merge rule is at follows:
     * <p>
     * 1. each worker thread take turns to add one char into {@link Lab10#mergedResult}
     * <p>
     * 2. the order of their turns is the same as their id, i.e. given 3 workers, the order is: worker0, worker1,
     * worker2, worker0, worker1, ...
     * <p>
     * 3. For example if we have two workers, worker0, worker1, with char array "hlo" and "el!" respectively.
     * Then after the merge, {@link Lab10#mergedResult} should contain: "hello!".
     * <p>
     * TODO complete this class to implement the above functionality.
     * This class should implement {@link Runnable} so that it can be run in a thread.
     */
    public static class Worker {
        /**
         * The local char list of this worker to merge in to {@link Lab10#mergedResult}.
         */
        private final char[] chars;

        /**
         * Id of this worker.
         * Id is unique to each worker object and is continuous integer from 0,
         * e.g. worker0, worker1, worker2, ...
         */
        private final int id;

        public Worker(int id, String chars) {
            this(id, chars.toCharArray());
        }

        public Worker(int id, char[] chars) {
            this.chars = chars;
            this.id = id;
        }

        @Override
        public void run() {
            // TODO
        }
    }

    /**
     * This main method shows a typical procedure of the test:
     * <p>
     * 1. clear the content of the {@link Lab10#mergedResult} list.
     * <p>
     * 2. set the total number of workers in {@link Lab10#numWorkers}.
     * <p>
     * 3. create workers and their threads and put into {@link Lab10#workerThreadMap}.
     * <p>
     * 4. start all threads.
     * <p>
     * 5. wait all threads to exit.
     * <p>
     * 6. check the merged result.
     */
    public static void main(String[] args) throws InterruptedException {
        mergedResult.clear();
        numWorkers.set(3);
        Lab10.workerThreadMap.clear();
        var worker0 = new Lab10.Worker(0, "hlwl");
        var worker1 = new Lab10.Worker(1, "eood");
        var worker2 = new Lab10.Worker(2, "l r!");
        Lab10.workerThreadMap.put(worker0, new Thread(worker0));
        Lab10.workerThreadMap.put(worker1, new Thread(worker1));
        Lab10.workerThreadMap.put(worker2, new Thread(worker2));
        for (var thread : workerThreadMap.values()) {
            thread.start();
        }
        for (var thread : workerThreadMap.values()) {
            thread.join();
        }
        // if your implementation is correct, this should output "hello world!"
        System.out.println(mergedResult.stream().map(String::valueOf).collect(Collectors.joining()));
    }
}