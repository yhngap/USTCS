import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;


public class Lab10Tests {
    @Test
    public void testTwoThreads() {
        assertTimeoutPreemptively(Duration.ofSeconds(1), () -> {
            Lab10.numWorkers.set(2);
            for (int i = 0; i < 5; i++) {
                Lab10.mergedResult.clear();
                Lab10.workerThreadMap.clear();
                var worker0 = new Lab10.Worker(0, "hlowrd");
                var worker1 = new Lab10.Worker(1, "el ol!");
                Lab10.workerThreadMap.put(worker0, new Thread(worker0));
                Lab10.workerThreadMap.put(worker1, new Thread(worker1));
                var threads = Lab10.workerThreadMap.values();
                threads.forEach(Thread::start);
                for (Thread thread : threads) {
                    thread.join();
                }
                assertEquals("hello world!",
                        Lab10.mergedResult.stream().map(String::valueOf).collect(Collectors.joining()));
            }
        });
    }

    @Test
    public void testThreeThreads() {
        assertTimeoutPreemptively(Duration.ofSeconds(1), () -> {
            Lab10.numWorkers.set(3);
            for (int i = 0; i < 5; i++) {
                Lab10.mergedResult.clear();
                Lab10.workerThreadMap.clear();
                var worker0 = new Lab10.Worker(0, "hlwl");
                var worker1 = new Lab10.Worker(1, "eood");
                var worker2 = new Lab10.Worker(2, "l r!");
                Lab10.workerThreadMap.put(worker0, new Thread(worker0));
                Lab10.workerThreadMap.put(worker1, new Thread(worker1));
                Lab10.workerThreadMap.put(worker2, new Thread(worker2));
                var threads = Lab10.workerThreadMap.values();
                threads.forEach(Thread::start);
                for (Thread thread : threads) {
                    thread.join();
                }
                assertEquals("hello world!",
                        Lab10.mergedResult.stream().map(String::valueOf).collect(Collectors.joining()));
            }
        });
    }
}
