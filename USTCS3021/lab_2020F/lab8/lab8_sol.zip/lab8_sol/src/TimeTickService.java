import java.util.*;

/**
 * TimeTickServer support event emitting and listening.
 */
public class TimeTickService {
    /**
     * The event that is emitted by {@link TimeTickService}
     */
    public static class TimeTickEvent extends EventObject {

        /**
         * Constructs an Event.
         *
         * @param now the current time when the event is emitted
         * @throws IllegalArgumentException if now is null
         */
        public TimeTickEvent(Date now) {
            super(now);
        }
    }

    /**
     * The listener to listen to {@link TimeTickEvent} that is emitted by {@link TimeTickService}
     */
    @FunctionalInterface
    public static interface TimeTickListener extends EventListener {
        void onTimeTickEvent(TimeTickEvent event);
    }

    /**
     * A list of listeners registered to listen to events
     */
    private final List<TimeTickListener> listeners;

    public TimeTickService() {
        this.listeners = new ArrayList<>();
    }

    /**
     * Register a new listener
     *
     * @param listener the event listener
     */
    public void addListener(TimeTickListener listener) {
        this.listeners.add(listener);
    }

    /**
     * Unregister a listener
     *
     * @param listener event listener
     */
    public void removeListener(TimeTickListener listener) {
        this.listeners.remove(listener);
    }

    /**
     * Emit the {@link TimeTickEvent} to every registered listeners
     *
     * @param event the event to emit
     */
    public void emitEvent(TimeTickEvent event) {
        for (var listener : this.listeners) {
            listener.onTimeTickEvent(event);
        }
    }
}
