import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Lab8 {
    /**
     * TimeTickService object
     */
    public static final TimeTickService service = new TimeTickService();

    /**
     * The timer used to emit events in TimeTickService
     */
    private static final Timer timer = new Timer();

    /**
     * Emit Event every 1 second
     */
    public static void emitEventEverySecond() {
        var task = new TimerTask() {
            @Override
            public void run() {
                var now = new Date();
                System.out.println("Timer ticks: " + now);
                service.emitEvent(new TimeTickService.TimeTickEvent(now));
            }
        };
        timer.schedule(task, 1000, 1000);
    }

    /**
     * Stop emitting more events
     */
    public static void cancelEmittingEvent() {
        timer.cancel();
    }

    public static void main(String[] args) {
        AtomicInteger counter = new AtomicInteger();
        emitEventEverySecond();
        service.addListener(event -> {
            counter.getAndIncrement();
            if (counter.intValue() > 200) {
                cancelEmittingEvent();
            }
        });
    }
}