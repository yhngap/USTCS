package structure;

import java.math.BigInteger;

/**
 * TODO 1:
 * Create an interface "Expression".
 *
 * It has one public abstract method, eval(), which returns a {@link Value} which
 * represents the calculation result of this expression.
 * Another public abstract method is toString(), which returns a string to print the expression.
 */

public interface Expression {
    Value eval();

    @Override
    String toString();
}
