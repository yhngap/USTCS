package operator;

import structure.Expression;
import structure.Operator;
import structure.Value;
import value.IntNumber;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;


/**
 * TODO 7: Define operator.Exponent operation
 * It should implement {@link Operator}, and will be used to construct {@link structure.Operation} objects.
 * Hint: BigInteger.pow(int)
 */

public class Exponent implements Operator {
    /**
     * TODO 7.1
     *
     * @return The result of the exponentiation
     */
    @Override
    public Value operate(List<Expression> operands) {
        var result = ((IntNumber) operands.get(0).eval()).getVal();
        var value = (IntNumber) operands.get(1).eval();
        result = result.pow(value.getVal().intValue());
        return new IntNumber(result);
    }

    @Override
    public String symbol() {
        return "^";
    }
}