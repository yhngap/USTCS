package operator;

import structure.Expression;
import structure.Operator;
import structure.Value;
import value.IntNumber;

import java.math.BigInteger;
import java.util.List;


/**
 * TODO 4: Define operator.Multiplication operation
 * It should implement {@link Operator}, and will be used to construct {@link structure.Operation} objects.
 * Hint: refer to the operator.Addition class to see how to implement this one. It's pretty similar.
 * Hint: Use the constant BigInteger.ONE and the method BigInteger.multiply(BigInteger) to implement the eval method
 */
public class Multiplication implements Operator {

    /**
     * TODO 4.1
     *
     * @return The BigInteger result after evaluating the multiplication operation
     */
    @Override
    public Value operate(List<Expression> operands) {
        var result = BigInteger.ONE;
        for (var operand : operands) {
            var value = (IntNumber) operand.eval();
            result = result.multiply(value.getVal());
        }
        return new IntNumber(result);
    }

    @Override
    public String symbol() {
        return "*";
    }
}
