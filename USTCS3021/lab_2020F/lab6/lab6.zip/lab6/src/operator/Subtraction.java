package operator;

import structure.Operator;

/**
 * TODO 5: Define operator.Subtraction operation
 * It should implement {@link Operator}, and will be used to construct {@link structure.Operation} objects.
 * Hint: refer to the operator.Addition class to see how to implement this one.
 * Hint: BigInteger.subtract(BigInteger) are useful for implementing eval()
 * Note: If the number of operands is 1, return the negation. Otherwise, subtract the rest of the operands from
 * the first operand
 */

public class Subtraction {
}
