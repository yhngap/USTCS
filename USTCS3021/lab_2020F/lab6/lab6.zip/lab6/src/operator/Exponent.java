package operator;

import structure.Operator;


/**
 * TODO 7: Define operator.Exponent operation
 * It should implement {@link Operator}, and will be used to construct {@link structure.Operation} objects.
 * Hint: BigInteger.pow(int)
 */

public class Exponent {
}