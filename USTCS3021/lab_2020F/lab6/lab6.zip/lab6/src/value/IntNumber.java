package value;

import structure.Value;

import java.math.BigInteger;
import java.util.Objects;


/**
 * TODO 2: Define the IntNumber class
 * This class implement {@link Value} (since a integer number is technically an value in expression).
 * There can be other type of values, e.g. float number, but in this lab we only implement integer numbers.
 * <p>
 * In this class, we use {@link BigInteger} as the internal representation of an integer number, which is
 * {@link IntNumber#val} field.
 */
public class IntNumber {
    private final BigInteger val;

    public IntNumber(BigInteger val) {
        this.val = val;
    }

    public IntNumber(String val) {
        this.val = new BigInteger(val);
    }

    public BigInteger getVal() {
        return val;
    }
}