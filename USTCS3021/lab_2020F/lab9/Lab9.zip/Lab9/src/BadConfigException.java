public class BadConfigException extends Exception {
}
