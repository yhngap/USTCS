import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Board {

    /**
     * This method saves a rectangular block of text (representing a board in PA1) based on the given dimensions
     * to file with the given filename.
     * Before saving the board, print out the number of rows on the first line, the number of columns on the second line,
     * and the actual block of text starting from the third line.
     *
     * Throw IllegalArgumentException if:
     * - The number of rows doesn't equal to the number of columns, with message
     *   "Number of rows should equal to the number of columns!"
     * - The number of rows/columns is smaller than 3, with message
     *   "Number of rows/column should be greater than or equal to 3."
     *
     * Example input board:
     *                     {{'K', 'A', 'K'},
     *                     {'.', '.', '.'},
     *                     {'K', 'A', 'K'}}
     * Output Example:
     * 3
     * 3
     * KAK
     * ...
     * KAK
     *
     * @param filename The filename to save the block of text. Assume it includes the .txt extension.
     * @param board      The grid of chars to save
     * @throws IllegalArgumentException if number of rows/column is invalid
     */
    public void createBoard(String filename, char[][] board) throws IllegalArgumentException {
        //TODO
        var numRows = board.length;
        var numCols = board[0].length;

        if (numRows != numCols)
            throw new IllegalArgumentException("Number of rows should equal to the number of columns!");

        if (numRows < 3)
            throw new IllegalArgumentException("Number of rows/column should be greater than or equal to 3.");

        var outputFile = new File(filename);

        try (var writer = new PrintWriter(outputFile)) {
            writer.println(numRows);
            writer.println(numCols);

            for (char[] chars : board) {
                for (var c = 0; c < numCols; c++) {
                    writer.print(chars[c]);
                }
                writer.println();
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Loads a board into a 2d char array. Note that the format of the text file will be the same
     * format as we saved it: first row  has an integer representing how many rows, second row has an integer
     * representing how many columns, and the rest of the rows is the actual block of text.
     *
     * Throw BadConfigException if:
     * - The number of rows < minRows or The number of columns < minCols
     *
     * Example input string
     * 3
     * 3
     * KAK
     * ...
     * KAK
     *
     * Expected return array:
     *                     {{'K', 'A', 'K'},
     *                     {'.', '.', '.'},
     *                     {'K', 'A', 'K'}}
     *
     * @param filename The filename of the map
     * @param minRows  the minimum number of rows this map must have. If violated, throw BadMapException
     * @param minCols  the minimum number of cols this map must have. If violated, throw BadMapException
     * @return The 2d char representing the map.
     * @throws BadConfigException if the minRows or minCols constraints are violated.
     */
    public char[][] loadBoard(String filename, int minRows, int minCols) throws BadConfigException {
        //TODO
//        return null; //You may also need to change this statement
        char[][] rep = null;
        var f = new File(filename);
        try (var reader = new Scanner(f)) {
            var numRows = reader.nextInt();
            var numCols = reader.nextInt();

            if (numRows < minRows || numCols < minCols) {
                throw new BadConfigException();
            }

            rep = new char[numRows][numCols];
            reader.nextLine();

            rep = new char[numRows][numCols];
            for (var r = 0; r < numRows; r++) {
                var row = reader.nextLine();
                for (var c = 0; c < numCols; c++) {
                    rep[r][c] = row.charAt(c);
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return rep;
    }
}
